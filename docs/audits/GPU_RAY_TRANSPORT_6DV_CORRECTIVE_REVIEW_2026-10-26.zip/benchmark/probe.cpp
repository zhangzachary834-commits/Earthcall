#include "Singularity/OntoMath/CommonScalarFactor.hpp"
// CommonScalarFactor.hpp sha256: abc149b49a9c4683080304a58eab169f64e4ea66848f799b3dcdbb6087011dba
#include <bit>

#include <fstream>
#include <iostream>
#include <memory>
#include <chrono>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <array>
#include <numeric>
#include <stdexcept>
#include <webgpu/wgpu.h>
#include "Singularity/Screen/VolumeZeroProof.hpp"

#include "ConstructedBeing/Singular/Object/Geometry/FieldNode.hpp"
#include "Singularity/Screen/VolumeDensity.hpp"
#include "Singularity/OntoMath/LineRestriction.hpp"
#include "Singularity/Screen/WebGPU/WgpuDevice.hpp"
#include "Singularity/Screen/WebGPU/SdfWgsl.hpp"
#include "json.hpp"

using J = nlohmann::json;

// Dynamic curtain specification extracted from authored MathNode AST
struct alignas(16) GpuCurtainSpec {
    glm::vec4 origin;    // xyz = origin, w = unused
    glm::vec4 half;      // xyz = halfExtent, w = unused
    glm::vec4 limits;    // x = Wx, y = Wy, z = yKnee, w = wz
    glm::vec4 curv;      // x = M2_x, yzw = unused
    glm::vec4 amps;      // x = A1, y = A2, z = A3, w = unused
    glm::vec4 freqs;     // x = w1, y = w2, z = w3, w = unused
    glm::vec4 phases;    // x = p1, y = p2, z = p3, w = unused
};
static_assert(sizeof(GpuCurtainSpec) == 112);

// Extract curtain specifications dynamically from authored zone
inline bool extractCurtainSpecs(const J& zone, std::vector<GpuCurtainSpec>& outSpecs) {
    outSpecs.clear();
    for (const auto& j : zone.at("spatialFields")) {
        auto field = geom::FieldNode::fromJson(j);
        Rendering::VolumeDensityBinding bnd;
        if (!field || !Rendering::readVolumeDensity(*field, 0, 0, bnd)) continue;
        if (!bnd.densityExpr) continue;
        
        auto pb = sdfwgsl::collectVolumeParams(bnd.densityExpr);
        if (pb.values.size() < 34) return false;
        const auto& v = pb.values;
        
        GpuCurtainSpec spec{};
        spec.origin = glm::vec4(bnd.origin, 0.0f);
        spec.half = glm::vec4(glm::abs(bnd.scale), 0.0f);
        
        float Wx = v[2];
        float Wy = v[6];
        float yKnee = -Wy + (v[5] > 0.0f ? 1.0f / v[5] : 4.0f);
        float wz = v[15];
        if(!(Wx>0&&Wy>0&&wz>0&&v[5]>0&&std::isfinite(Wx)&&std::isfinite(Wy)&&std::isfinite(wz)))return false;
        spec.limits = glm::vec4(Wx, Wy, yKnee, wz);
        
        float A1 = v[16], w1 = v[17], p1 = v[18];
        float A2 = v[19], w2 = v[20], p2 = v[21];
        float A3 = v[22], w3 = v[23], p3 = v[24];
        
        spec.amps = glm::vec4(A1, A2, A3, 0.0f);
        spec.freqs = glm::vec4(w1, w2, w3, 0.0f);
        spec.phases = glm::vec4(p1, p2, p3, 0.0f);
        
        float M2 = std::abs(A1) * w1 * w1 + std::abs(A2) * w2 * w2 + std::abs(A3) * w3 * w3;
        spec.curv = glm::vec4(std::nextafter(M2,INFINITY)*1.00002f, std::getenv("EC_GPU_MARGIN")?std::stof(std::getenv("EC_GPU_MARGIN")):.001f,0,0);
        
        outSpecs.push_back(spec);
    }
    return outSpecs.size() == 4;
}

static const char* kGpuProducerWgsl=R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<storage,read> curtains:array<CurtainSpec,4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;
fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}
fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 // Bands describe uncertainty sets, not distinct roots. Merge only
 // intersecting/touching bands; never bridge an unrepresented gap.
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}
// The curvature/endpoint model is explicit. A bin must be monotone before
// bisection can resolve it. Exhaustion never becomes an isolated midpoint.

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}
fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  stack[0] = vec4f(a, b, phi_a0, phi_b0); setDepth(&depthBits, 0u, 0u); top = 1u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if ((va > error && vb < -error) || (va < -error && vb > error)) {
     var l = a; var r = b; var left = va;
     for (var iter = 0u; iter < 32u; iter++) {
      if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
      let mid = l + 0.5 * (r - l);
      if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
      let v = evalPhi(m, o, d, mid) - c;
      if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
      if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
     }
     putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
    }
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

@compute @workgroup_size(64)
fn producerMain(@builtin(global_invocation_id) gid: vec3u) {
 let id = gid.x; if (id >= cfg.rayCount) { return; }
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 4u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   // Reuse exactly the affine-knot arithmetic used when inserting knots above.
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
  var ne = 0u;
 var head = vec4u(0u);
 let totalKnots = (memCount.x + memCount.y + memCount.z + memCount.w) * 2u;
 loop {
  if (ne >= totalKnots) { break; }
  var bestM = 4u;
  var bestVal = 0.0;
  for (var m = 0u; m < 4u; m++) {
   let h = head[m];
   if (h < memCount[m] * 2u) {
    let pIdx = memStart[m] + (h >> 1u);
    let isY = (h & 1u) != 0u;
    let val = select(pieces[pIdx].x, pieces[pIdx].y, isY);
    if (bestM == 4u || val < bestVal) {
     bestVal = val;
     bestM = m;
    }
   }
  }
  knots[ne] = bestVal;
  ne++;
  head[bestM]++;
 }
 var singles = 0u; var overs = 0u;
 var pIdx = vec4u(0u);
 for (var i = 1u; i < ne && reason == 0u; i++) {
  let a = knots[i - 1u]; let b = knots[i]; if (!(b > a)) { continue; }
  let mid = a + 0.5 * (b - a);
  var mask = 0u;
  for (var m = 0u; m < 4u; m++) {
   let start = memStart[m];
   let numPieces = memCount[m];
   var cur = pIdx[m];
   loop {
    if (cur >= numPieces || pieces[start + cur].y >= mid) { break; }
    cur++;
   }
   pIdx[m] = cur;
   if (cur < numPieces) {
    let p = pieces[start + cur];
    if (mid >= p.x && mid <= p.y) {
     mask |= (1u << m);
    }
   }
  }
  if (mask == 0u) { continue; }
  if (countOneBits(mask) == 1u) {
   let n = max(1u, u32(ceil((b - a) / 4.0)));
   if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
   let member = firstTrailingBit(mask);
   for (var k = 0u; k < n; k++) {
    let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
    let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
    subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(member, 0)); singles++;
   }
  } else {
   if (overs >= cfg.maxOverPerRay) { reason |= 32u; break; }
   overlaps[overBase + overs] = Overlap(vec2f(a, b), vec2u(mask, 0)); overs++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, overs); }
}

)WGSL";

using M = OntoMath::MathNode;

static bool containsNoise(const M& n) {
    if (n.op == M::Op::Noise) return true;
    for (const auto& ch : n.children) if (ch && containsNoise(*ch)) return true;
    return false;
}

static std::unique_ptr<M> cloneEnvelope(const M& n) {
    if (n.op == M::Op::Clamp && containsNoise(n)) {
        auto one = std::make_unique<M>();
        one->op = M::Op::ScalarLeaf;
        one->scalarForm = OntoMath::ScalarForm::constant(1.0);
        return one;
    }
    auto copy = std::make_unique<M>();
    copy->op = n.op;
    copy->scalarForm = n.scalarForm;
    copy->variableName = n.variableName;
    copy->stringArg = n.stringArg;
    copy->matrixRows = n.matrixRows;
    copy->matrixCols = n.matrixCols;
    for (const auto& ch : n.children) {
        copy->children.push_back(ch ? cloneEnvelope(*ch) : nullptr);
    }
    return copy;
}

static const M* single(const OntoMath::Piecewise* p) {
    if (!p || p->pieces.size() != 1) return nullptr;
    const auto& x = p->pieces[0];
    return !x.guard && !x.call && !x.fold && !x.hasLo && !x.hasHi && !x.whereLEZero ? x.mathNode.get() : nullptr;
}

struct Medium {
    std::shared_ptr<geom::FieldNode> owner;
    std::string id;
    glm::dvec3 origin;
    glm::dvec3 half;
    const M *density = nullptr, *sigma = nullptr, *emission = nullptr;
    std::unique_ptr<M> envAST;
    OntoMath::LineAlgebraicForm envForm;
    bool hasEnv = false;
    float alpha = 0.0f;
    glm::vec3 color{0.0f};
    float noiseFreq = 0.0f;
    uint32_t paramOffset = 0;
};

struct Piece {
    int mediumIndex;
    double s0, s1;
    std::vector<int8_t> signs;
};

// GPU Data structures
struct GpuRayHeader {
    float ro[3]; float clipA;
    float rd[3]; float clipB;
    uint32_t subpanelOffset; uint32_t subpanelCount;
    uint32_t overlapOffset;  uint32_t overlapCount;
};

struct GpuSubpanel {
    float s0, s1;
    uint32_t mediumIndex;
    float pad;
};

struct GpuOverlap {
    float s0, s1;
    uint32_t activeMask;
    float pad;
};

struct GpuMediumParams {
    float origin[4];   // x, y, z, pad
    float color[4];    // r, g, b, alpha
    float freq[4];     // freq, paramOffset, pad, pad
};

struct GpuResult {
    float rgb_T[4];    // r, g, b, T
};

// WebGPU Map Callback
struct MapContext { bool done = false; bool ok = false; };
static void onMapped(WGPUMapAsyncStatus s, WGPUStringView, void* u, void*) {
    auto* c = static_cast<MapContext*>(u);
    c->ok = (s == WGPUMapAsyncStatus_Success);
    c->done = true;
}

// WebGPU Pop Error Scope Callback
struct PopContext { WGPUErrorType type = WGPUErrorType_NoError; bool done = false; };
static void onPopError(WGPUPopErrorScopeStatus, WGPUErrorType type, WGPUStringView msg, void* u, void*) {
    auto* c = static_cast<PopContext*>(u);
    c->type = type;
    c->done = true;
    if (type != WGPUErrorType_NoError) {
        std::fprintf(stderr, "[WebGPU Error %d]: %.*s\n", (int)type, (int)msg.length, msg.data);
    }
}

// WGSL Header with common math, cnoise3, envelope, and transfer functions
static const char* kCommonWgslHeader = R"WGSL(
struct RayHeader {
    ro_clipA: vec4<f32>,
    rd_clipB: vec4<f32>,
    counts: vec4<u32>, // subpanelOffset, subpanelCount, overlapOffset, overlapCount
};

struct Subpanel {
    span: vec2<f32>, // s0, s1
    info: vec2<u32>, // mediumIndex, pad
};

struct OverlapInterval {
    span: vec2<f32>, // s0, s1
    info: vec2<u32>, // activeMask, pad
};

struct MediumParams {
    origin: vec4<f32>,
    color_alpha: vec4<f32>, // r, g, b, alpha
    freq_offset: vec4<f32>, // freq, paramOffset, pad, pad
};

struct GlobalUniforms {
    clock: f32,
    rayCount: u32,
    pad0: u32,
    pad1: u32,
};

struct ParameterBuffer {
    v: array<f32>,
};

@group(0) @binding(0) var<uniform> u: GlobalUniforms;
@group(0) @binding(1) var<storage, read> media: array<MediumParams>;
@group(0) @binding(2) var<storage, read> params: ParameterBuffer;
@group(0) @binding(3) var<storage, read> rays: array<RayHeader>;
@group(0) @binding(4) var<storage, read> subpanels: array<Subpanel>;
@group(0) @binding(5) var<storage, read> overlaps: array<OverlapInterval>;
@group(0) @binding(6) var<storage, read_write> results: array<vec4<f32>>;

fn mod289(x: vec4<f32>) -> vec4<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn mod289_3(x: vec3<f32>) -> vec3<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn permute4(x: vec4<f32>) -> vec4<f32> {
    return mod289(((x * 34.0) + 1.0) * x);
}
fn taylorInvSqrt(r: vec4<f32>) -> vec4<f32> {
    return 1.79284291400159 - 0.85373472095314 * r;
}

fn cnoise3(P: vec3<f32>) -> f32 {
    let Pi0 = floor(P);
    let Pi1 = Pi0 + vec3<f32>(1.0);
    let Pi0_mod = mod289_3(Pi0);
    let Pi1_mod = mod289_3(Pi1);
    let Pf0 = fract(P);
    let Pf1 = Pf0 - vec3<f32>(1.0);
    let ix = vec4<f32>(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
    let iy = vec4<f32>(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
    let iz0 = vec4<f32>(Pi0_mod.z);
    let iz1 = vec4<f32>(Pi1_mod.z);

    let ixy = permute4(permute4(ix) + iy);
    let ixy0 = permute4(ixy + iz0);
    let ixy1 = permute4(ixy + iz1);

    var gx0 = ixy0 / 7.0;
    var gy0 = fract(floor(gx0) / 7.0) - 0.5;
    gx0 = fract(gx0);
    var gz0 = vec4<f32>(0.5) - abs(gx0) - abs(gy0);
    let sz0 = step(gz0, vec4<f32>(0.0));
    gx0 = gx0 - sz0 * (step(vec4<f32>(0.0), gx0) - 0.5);
    gy0 = gy0 - sz0 * (step(vec4<f32>(0.0), gy0) - 0.5);

    var gx1 = ixy1 / 7.0;
    var gy1 = fract(floor(gx1) / 7.0) - 0.5;
    gx1 = fract(gx1);
    var gz1 = vec4<f32>(0.5) - abs(gx1) - abs(gy1);
    let sz1 = step(gz1, vec4<f32>(0.0));
    gx1 = gx1 - sz1 * (step(vec4<f32>(0.0), gx1) - 0.5);
    gy1 = gy1 - sz1 * (step(vec4<f32>(0.0), gy1) - 0.5);

    var g000 = vec3<f32>(gx0.x,gy0.x,gz0.x);
    var g100 = vec3<f32>(gx0.y,gy0.y,gz0.y);
    var g010 = vec3<f32>(gx0.z,gy0.z,gz0.z);
    var g110 = vec3<f32>(gx0.w,gy0.w,gz0.w);
    var g001 = vec3<f32>(gx1.x,gy1.x,gz1.x);
    var g101 = vec3<f32>(gx1.y,gy1.y,gz1.y);
    var g011 = vec3<f32>(gx1.z,gy1.z,gz1.z);
    var g111 = vec3<f32>(gx1.w,gy1.w,gz1.w);

    let norm0 = taylorInvSqrt(vec4<f32>(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));
    g000 = g000 * norm0.x;
    g010 = g010 * norm0.y;
    g100 = g100 * norm0.z;
    g110 = g110 * norm0.w;
    let norm1 = taylorInvSqrt(vec4<f32>(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));
    g001 = g001 * norm1.x;
    g011 = g011 * norm1.y;
    g101 = g101 * norm1.z;
    g111 = g111 * norm1.w;

    let n000 = dot(g000, Pf0);
    let n100 = dot(g100, vec3<f32>(Pf1.x, Pf0.y, Pf0.z));
    let n010 = dot(g010, vec3<f32>(Pf0.x, Pf1.y, Pf0.z));
    let n110 = dot(g110, vec3<f32>(Pf1.x, Pf1.y, Pf0.z));
    let n001 = dot(g001, vec3<f32>(Pf0.x, Pf0.y, Pf1.z));
    let n101 = dot(g101, vec3<f32>(Pf1.x, Pf0.y, Pf1.z));
    let n011 = dot(g011, vec3<f32>(Pf0.x, Pf1.y, Pf1.z));
    let n111 = dot(g111, Pf1);

    let fade_xyz = Pf0 * Pf0 * Pf0 * (Pf0 * (Pf0 * 6.0 - 15.0) + 10.0);
    let n_z = mix(vec4<f32>(n000, n100, n010, n110), vec4<f32>(n001, n101, n011, n111), fade_xyz.z);
    let n_yz = mix(n_z.xy, n_z.zw, fade_xyz.y);
    let n_xyz = mix(n_yz.x, n_yz.y, fade_xyz.x); 
    return 2.2 * n_xyz;
}

fn evalEnvelope(p: vec3<f32>, paramOffset: u32) -> f32 {
    let f0 = params.v[paramOffset + 0u];
    if (f0 == 0.0) { return 0.0; }
    let f1 = clamp(params.v[paramOffset + 1u] - select(0.0, abs(p.x) / params.v[paramOffset + 2u], abs(params.v[paramOffset + 2u]) >= 1e-06), params.v[paramOffset + 3u], params.v[paramOffset + 4u]);
    if (f1 == 0.0) { return 0.0; }
    let f2 = clamp(params.v[paramOffset + 5u] * (p.y + params.v[paramOffset + 6u]), params.v[paramOffset + 7u], params.v[paramOffset + 8u]);
    if (f2 == 0.0) { return 0.0; }
    let f3 = clamp(params.v[paramOffset + 9u] - select(0.0, (p.y + params.v[paramOffset + 11u]) / params.v[paramOffset + 10u], abs(params.v[paramOffset + 10u]) >= 1e-06), params.v[paramOffset + 12u], params.v[paramOffset + 13u]);
    if (f3 == 0.0) { return 0.0; }
    let z_curve = p.z + params.v[paramOffset + 16u] * sin(params.v[paramOffset + 17u] * p.x + params.v[paramOffset + 18u])
                      + params.v[paramOffset + 19u] * cos(params.v[paramOffset + 20u] * p.x + params.v[paramOffset + 21u])
                      + params.v[paramOffset + 22u] * sin(params.v[paramOffset + 23u] * p.x + params.v[paramOffset + 24u]);
    let f4 = clamp(params.v[paramOffset + 14u] - select(0.0, abs(z_curve) / params.v[paramOffset + 15u], abs(params.v[paramOffset + 15u]) >= 1e-06), params.v[paramOffset + 25u], params.v[paramOffset + 26u]);
    if (f4 == 0.0) { return 0.0; }
    let f5 = params.v[paramOffset + 27u] + params.v[paramOffset + 28u] * cos(params.v[paramOffset + 29u] * p.x + params.v[paramOffset + 30u])
                                         + params.v[paramOffset + 31u] * cos(params.v[paramOffset + 32u] * p.x + params.v[paramOffset + 33u]);
    if (f5 == 0.0) { return 0.0; }
    return f0 * f1 * f2 * f3 * f4 * f5;
}
)WGSL";

static const char* kOverlapWgsl=R"WGSL(
fn phiSafe(tau: f32) -> f32 {
    if (abs(tau) < 0.01) {
        return 1.0 + tau * (-0.5 + tau * (1.0/6.0 - tau/24.0));
    }
    return (1.0 - exp(-tau)) / tau;
}
fn projectedAt(ro: vec3<f32>, rd: vec3<f32>, s: f32, mask: u32) -> vec4<f32> {
    var result=vec4<f32>(0.0);
    for (var member=0u; member<arrayLength(&media); member+=1u) {
        if ((mask & (1u<<member))==0u) {continue;}
        let m=media[member];
        let local=ro+s*rd-m.origin.xyz;
        let env=evalEnvelope(local,u32(m.freq_offset.y));
        if (env<=0.0) {continue;}
        let D=env*clamp(0.7+0.3*cnoise3(m.freq_offset.x*local),0.0,1.0);
        if (D<=0.0) {continue;}
        let raw=m.color_alpha.w*D;
        result+=vec4<f32>(m.color_alpha.xyz*raw,max(raw,1e-6));
    }
    return result;
}
fn advanceFlow(state: vec4<f32>, sourceSigma: vec4<f32>, h: f32) -> vec4<f32> {
    let tau=h*sourceSigma.w;
    return vec4<f32>(state.xyz+state.w*sourceSigma.xyz*(h*phiSafe(tau)),state.w*exp(-tau));
}
fn advanceOverlap(stateIn: vec4<f32>, ro: vec3<f32>, rd: vec3<f32>, o: OverlapInterval) -> vec4<f32> {
    var state=stateIn;
    let h=(o.span.y-o.span.x)*0.5;
    let a=0.25-sqrt(3.0)/6.0;
    let b=0.5-a;
    for (var panel=0u; panel<2u; panel+=1u) {
        let lo=o.span.x+f32(panel)*h;
        let minus=projectedAt(ro,rd,lo+(0.5-sqrt(3.0)/6.0)*h,o.info.x);
        let plus=projectedAt(ro,rd,lo+(0.5+sqrt(3.0)/6.0)*h,o.info.x);
        state=advanceFlow(state,b*minus+a*plus,h);
        state=advanceFlow(state,a*minus+b*plus,h);
    }
    return state;
}
)WGSL";

// Pipeline 1: Unfused A* Shader
static const char* kUnfusedShader = R"WGSL(
@compute @workgroup_size(64)
fn rayMain(@builtin(global_invocation_id) gid: vec3<u32>) {
    let rayIdx = gid.x;
    if (rayIdx >= u.rayCount) { return; }

    let r = rays[rayIdx % arrayLength(&rays)];
    if((r.counts.w & 0x80000000u) != 0u){ return; }
    if((r.counts.w & 0x40000000u) != 0u){ return; }
    let ro = r.ro_clipA.xyz;
    let rd = r.rd_clipB.xyz;
    let subOffset = r.counts.x;
    let subCount = r.counts.y;
    let overOffset = r.counts.z;
    let overCount = r.counts.w;

    let gx0 = 0.5 * (1.0 - 0.5773502691896257);
    let gx1 = 0.5 * (1.0 + 0.5773502691896257);

    var T = 1.0;
    var L = vec3<f32>(0.0);

    // Two sorted streams must be consumed in ray order, including overlap.
    var single=0u;
    var overlap=0u;
    loop {
        if (single>=subCount && overlap>=overCount) {break;}
        var useOverlap=false;
        if (overlap<overCount) {
            if (single>=subCount) {useOverlap=true;}
            else {useOverlap=overlaps[overOffset+overlap].span.x<subpanels[subOffset+single].span.x;}
        }
        if (useOverlap) {
            let state=advanceOverlap(vec4<f32>(L,T),ro,rd,overlaps[overOffset+overlap]);
            L=state.xyz; T=state.w;
            overlap+=1u;
            continue;
        }
        let sub = subpanels[subOffset + single];
        single+=1u;
        let s0 = sub.span.x;
        let s1 = sub.span.y;
        let sub_h = s1 - s0;
        let mid = sub.info.x;
        let m = media[mid];
        let pOffset = u32(m.freq_offset.y);
        let freq = m.freq_offset.x;
        let alpha = m.color_alpha.w;
        let color = m.color_alpha.xyz;

        let s_m = s0 + gx0 * sub_h;
        let s_p = s0 + gx1 * sub_h;
        let w_m = ro + s_m * rd - m.origin.xyz;
        let w_p = ro + s_p * rd - m.origin.xyz;

        let env_m = evalEnvelope(w_m, pOffset);
        let env_p = evalEnvelope(w_p, pOffset);

        var D_m = 0.0;
        if (env_m > 0.0) {
            let nm = cnoise3(freq * w_m);
            D_m = env_m * clamp(0.7 + 0.3 * nm, 0.0, 1.0);
        }
        var D_p = 0.0;
        if (env_p > 0.0) {
            let np = cnoise3(freq * w_p);
            D_p = env_p * clamp(0.7 + 0.3 * np, 0.0, 1.0);
        }

        // Sixth-one Sun: Strict D > 0 gate
        let sig_m = select(0.0, max(alpha * D_m, 1e-6), D_m > 0.0);
        let em_m  = select(vec3<f32>(0.0), color * (alpha * D_m), D_m > 0.0);
        let sig_p = select(0.0, max(alpha * D_p, 1e-6), D_p > 0.0);
        let em_p  = select(vec3<f32>(0.0), color * (alpha * D_p), D_p > 0.0);

        let sig_avg = 0.5 * (sig_m + sig_p);
        let em_avg  = 0.5 * (em_m + em_p);
        let tau = sub_h * sig_avg;
        let atten = exp(-tau);

        // Sixth-one Sun: Numerically safe small-depth gain in f32
        var gain: f32;
        gain=sub_h*phiSafe(tau);

        L = L + T * em_avg * gain;
        T = T * atten;
    }

    results[rayIdx] = vec4<f32>(L, T);
}
)WGSL";

// Pipeline 2: Fused A* Shader (with Same-Cell 90.78% Gradient Sharing)
static const char* kFusedShader = R"WGSL(
fn cnoise3_fused(Pm: vec3<f32>, Pp: vec3<f32>) -> vec2<f32> {
    let Pi0_m = floor(Pm);
    let Pi0_p = floor(Pp);
    if (all(Pi0_m == Pi0_p)) {
        // --- SHARED 8 CORNER GRADIENTS ---
        let Pi0 = Pi0_m;
        let Pi1 = Pi0 + vec3<f32>(1.0);
        let Pi0_mod = mod289_3(Pi0);
        let Pi1_mod = mod289_3(Pi1);
        let ix = vec4<f32>(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
        let iy = vec4<f32>(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
        let iz0 = vec4<f32>(Pi0_mod.z);
        let iz1 = vec4<f32>(Pi1_mod.z);

        let ixy = permute4(permute4(ix) + iy);
        let ixy0 = permute4(ixy + iz0);
        let ixy1 = permute4(ixy + iz1);

        var gx0 = ixy0 / 7.0;
        var gy0 = fract(floor(gx0) / 7.0) - 0.5;
        gx0 = fract(gx0);
        var gz0 = vec4<f32>(0.5) - abs(gx0) - abs(gy0);
        let sz0 = step(gz0, vec4<f32>(0.0));
        gx0 = gx0 - sz0 * (step(vec4<f32>(0.0), gx0) - 0.5);
        gy0 = gy0 - sz0 * (step(vec4<f32>(0.0), gy0) - 0.5);

        var gx1 = ixy1 / 7.0;
        var gy1 = fract(floor(gx1) / 7.0) - 0.5;
        gx1 = fract(gx1);
        var gz1 = vec4<f32>(0.5) - abs(gx1) - abs(gy1);
        let sz1 = step(gz1, vec4<f32>(0.0));
        gx1 = gx1 - sz1 * (step(vec4<f32>(0.0), gx1) - 0.5);
        gy1 = gy1 - sz1 * (step(vec4<f32>(0.0), gy1) - 0.5);

        var g000 = vec3<f32>(gx0.x,gy0.x,gz0.x);
        var g100 = vec3<f32>(gx0.y,gy0.y,gz0.y);
        var g010 = vec3<f32>(gx0.z,gy0.z,gz0.z);
        var g110 = vec3<f32>(gx0.w,gy0.w,gz0.w);
        var g001 = vec3<f32>(gx1.x,gy1.x,gz1.x);
        var g101 = vec3<f32>(gx1.y,gy1.y,gz1.y);
        var g011 = vec3<f32>(gx1.z,gy1.z,gz1.z);
        var g111 = vec3<f32>(gx1.w,gy1.w,gz1.w);

        let norm0 = taylorInvSqrt(vec4<f32>(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));
        g000 = g000 * norm0.x;
        g010 = g010 * norm0.y;
        g100 = g100 * norm0.z;
        g110 = g110 * norm0.w;
        let norm1 = taylorInvSqrt(vec4<f32>(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));
        g001 = g001 * norm1.x;
        g011 = g011 * norm1.y;
        g101 = g101 * norm1.z;
        g111 = g111 * norm1.w;

        // Sample node m (s_-)
        let Pf0_m = fract(Pm);
        let Pf1_m = Pf0_m - vec3<f32>(1.0);
        let n000_m = dot(g000, Pf0_m);
        let n100_m = dot(g100, vec3<f32>(Pf1_m.x, Pf0_m.y, Pf0_m.z));
        let n010_m = dot(g010, vec3<f32>(Pf0_m.x, Pf1_m.y, Pf0_m.z));
        let n110_m = dot(g110, vec3<f32>(Pf1_m.x, Pf1_m.y, Pf0_m.z));
        let n001_m = dot(g001, vec3<f32>(Pf0_m.x, Pf0_m.y, Pf1_m.z));
        let n101_m = dot(g101, vec3<f32>(Pf1_m.x, Pf0_m.y, Pf1_m.z));
        let n011_m = dot(g011, vec3<f32>(Pf0_m.x, Pf1_m.y, Pf1_m.z));
        let n111_m = dot(g111, Pf1_m);
        let fade_m = Pf0_m * Pf0_m * Pf0_m * (Pf0_m * (Pf0_m * 6.0 - 15.0) + 10.0);
        let nz_m = mix(vec4<f32>(n000_m, n100_m, n010_m, n110_m), vec4<f32>(n001_m, n101_m, n011_m, n111_m), fade_m.z);
        let nyz_m = mix(nz_m.xy, nz_m.zw, fade_m.y);
        let val_m = 2.2 * mix(nyz_m.x, nyz_m.y, fade_m.x);

        // Sample node p (s_+)
        let Pf0_p = fract(Pp);
        let Pf1_p = Pf0_p - vec3<f32>(1.0);
        let n000_p = dot(g000, Pf0_p);
        let n100_p = dot(g100, vec3<f32>(Pf1_p.x, Pf0_p.y, Pf0_p.z));
        let n010_p = dot(g010, vec3<f32>(Pf0_p.x, Pf1_p.y, Pf0_p.z));
        let n110_p = dot(g110, vec3<f32>(Pf1_p.x, Pf1_p.y, Pf0_p.z));
        let n001_p = dot(g001, vec3<f32>(Pf0_p.x, Pf0_p.y, Pf1_p.z));
        let n101_p = dot(g101, vec3<f32>(Pf1_p.x, Pf0_p.y, Pf1_p.z));
        let n011_p = dot(g011, vec3<f32>(Pf0_p.x, Pf1_p.y, Pf1_p.z));
        let n111_p = dot(g111, Pf1_p);
        let fade_p = Pf0_p * Pf0_p * Pf0_p * (Pf0_p * (Pf0_p * 6.0 - 15.0) + 10.0);
        let nz_p = mix(vec4<f32>(n000_p, n100_p, n010_p, n110_p), vec4<f32>(n001_p, n101_p, n011_p, n111_p), fade_p.z);
        let nyz_p = mix(nz_p.xy, nz_p.zw, fade_p.y);
        let val_p = 2.2 * mix(nyz_p.x, nyz_p.y, fade_p.x);

        return vec2<f32>(val_m, val_p);
    } else {
        // Fallback for cross-cell (9.22%)
        return vec2<f32>(cnoise3(Pm), cnoise3(Pp));
    }
}

@compute @workgroup_size(64)
fn rayMain(@builtin(global_invocation_id) gid: vec3<u32>) {
    let rayIdx = gid.x;
    if (rayIdx >= u.rayCount) { return; }

    let r = rays[rayIdx % arrayLength(&rays)];
    if((r.counts.w & 0x80000000u) != 0u){ return; }
    if((r.counts.w & 0x40000000u) != 0u){ return; }
    let ro = r.ro_clipA.xyz;
    let rd = r.rd_clipB.xyz;
    let subOffset = r.counts.x;
    let subCount = r.counts.y;
    let overOffset = r.counts.z;
    let overCount = r.counts.w;

    let gx0 = 0.5 * (1.0 - 0.5773502691896257);
    let gx1 = 0.5 * (1.0 + 0.5773502691896257);

    var T = 1.0;
    var L = vec3<f32>(0.0);

    // Two sorted streams must be consumed in ray order, including overlap.
    var single=0u;
    var overlap=0u;
    loop {
        if (single>=subCount && overlap>=overCount) {break;}
        var useOverlap=false;
        if (overlap<overCount) {
            if (single>=subCount) {useOverlap=true;}
            else {useOverlap=overlaps[overOffset+overlap].span.x<subpanels[subOffset+single].span.x;}
        }
        if (useOverlap) {
            let state=advanceOverlap(vec4<f32>(L,T),ro,rd,overlaps[overOffset+overlap]);
            L=state.xyz; T=state.w;
            overlap+=1u;
            continue;
        }
        let sub = subpanels[subOffset + single];
        single+=1u;
        let s0 = sub.span.x;
        let s1 = sub.span.y;
        let sub_h = s1 - s0;
        let mid = sub.info.x;
        let m = media[mid];
        let pOffset = u32(m.freq_offset.y);
        let freq = m.freq_offset.x;
        let alpha = m.color_alpha.w;
        let color = m.color_alpha.xyz;

        let s_m = s0 + gx0 * sub_h;
        let s_p = s0 + gx1 * sub_h;
        let w_m = ro + s_m * rd - m.origin.xyz;
        let w_p = ro + s_p * rd - m.origin.xyz;

        let env_m = evalEnvelope(w_m, pOffset);
        let env_p = evalEnvelope(w_p, pOffset);

        var D_m = 0.0;
        var D_p = 0.0;
        if (env_m > 0.0 || env_p > 0.0) {
            let noises = cnoise3_fused(freq * w_m, freq * w_p);
            if (env_m > 0.0) { D_m = env_m * clamp(0.7 + 0.3 * noises.x, 0.0, 1.0); }
            if (env_p > 0.0) { D_p = env_p * clamp(0.7 + 0.3 * noises.y, 0.0, 1.0); }
        }

        // Sixth-one Sun: Strict D > 0 gate
        let sig_m = select(0.0, max(alpha * D_m, 1e-6), D_m > 0.0);
        let em_m  = select(vec3<f32>(0.0), color * (alpha * D_m), D_m > 0.0);
        let sig_p = select(0.0, max(alpha * D_p, 1e-6), D_p > 0.0);
        let em_p  = select(vec3<f32>(0.0), color * (alpha * D_p), D_p > 0.0);

        let sig_avg = 0.5 * (sig_m + sig_p);
        let em_avg  = 0.5 * (em_m + em_p);
        let tau = sub_h * sig_avg;
        let atten = exp(-tau);

        // Sixth-one Sun: Numerically safe small-depth gain in f32
        var gain: f32;
        gain=sub_h*phiSafe(tau);

        L = L + T * em_avg * gain;
        T = T * atten;
    }

    results[rayIdx] = vec4<f32>(L, T);
}
)WGSL";

static glm::vec4 mod289(glm::vec4 x) { return x - glm::floor(x * (1.0f / 289.0f)) * 289.0f; }
static glm::vec3 mod289(glm::vec3 x) { return x - glm::floor(x * (1.0f / 289.0f)) * 289.0f; }
static glm::vec4 permute4(glm::vec4 x) { return mod289(((x * 34.0f) + 1.0f) * x); }
static glm::vec4 taylorInvSqrt(glm::vec4 r) { return 1.79284291400159f - 0.85373472095314f * r; }

static float cnoise3_cpu(glm::vec3 P) {
    glm::vec3 Pi0 = glm::floor(P);
    glm::vec3 Pi1 = Pi0 + glm::vec3(1.0f);
    glm::vec3 Pi0_mod = mod289(Pi0);
    glm::vec3 Pi1_mod = mod289(Pi1);
    glm::vec3 Pf0 = glm::fract(P);
    glm::vec3 Pf1 = Pf0 - glm::vec3(1.0f);
    glm::vec4 ix(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
    glm::vec4 iy(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
    glm::vec4 iz0(Pi0_mod.z);
    glm::vec4 iz1(Pi1_mod.z);

    glm::vec4 ixy = permute4(permute4(ix) + iy);
    glm::vec4 ixy0 = permute4(ixy + iz0);
    glm::vec4 ixy1 = permute4(ixy + iz1);

    glm::vec4 gx0 = ixy0 * (1.0f / 7.0f);
    glm::vec4 gy0 = glm::fract(glm::floor(gx0) * (1.0f / 7.0f)) - 0.5f;
    gx0 = glm::fract(gx0);
    glm::vec4 gz0 = glm::vec4(0.5f) - glm::abs(gx0) - glm::abs(gy0);
    glm::vec4 sz0 = glm::step(gz0, glm::vec4(0.0f));
    gx0 = gx0 - sz0 * (glm::step(glm::vec4(0.0f), gx0) - 0.5f);
    gy0 = gy0 - sz0 * (glm::step(glm::vec4(0.0f), gy0) - 0.5f);

    glm::vec4 gx1 = ixy1 * (1.0f / 7.0f);
    glm::vec4 gy1 = glm::fract(glm::floor(gx1) * (1.0f / 7.0f)) - 0.5f;
    gx1 = glm::fract(gx1);
    glm::vec4 gz1 = glm::vec4(0.5f) - glm::abs(gx1) - glm::abs(gy1);
    glm::vec4 sz1 = glm::step(gz1, glm::vec4(0.0f));
    gx1 = gx1 - sz1 * (glm::step(glm::vec4(0.0f), gx1) - 0.5f);
    gy1 = gy1 - sz1 * (glm::step(glm::vec4(0.0f), gy1) - 0.5f);

    glm::vec3 g000(gx0.x, gy0.x, gz0.x);
    glm::vec3 g100(gx0.y, gy0.y, gz0.y);
    glm::vec3 g010(gx0.z, gy0.z, gz0.z);
    glm::vec3 g110(gx0.w, gy0.w, gz0.w);
    glm::vec3 g001(gx1.x, gy1.x, gz1.x);
    glm::vec3 g101(gx1.y, gy1.y, gz1.y);
    glm::vec3 g011(gx1.z, gy1.z, gz1.z);
    glm::vec3 g111(gx1.w, gy1.w, gz1.w);

    glm::vec4 norm0 = taylorInvSqrt(glm::vec4(glm::dot(g000, g000), glm::dot(g010, g010), glm::dot(g100, g100), glm::dot(g110, g110)));
    g000 *= norm0.x; g010 *= norm0.y; g100 *= norm0.z; g110 *= norm0.w;
    glm::vec4 norm1 = taylorInvSqrt(glm::vec4(glm::dot(g001, g001), glm::dot(g011, g011), glm::dot(g101, g101), glm::dot(g111, g111)));
    g001 *= norm1.x; g011 *= norm1.y; g101 *= norm1.z; g111 *= norm1.w;

    float n000 = glm::dot(g000, Pf0);
    float n100 = glm::dot(g100, glm::vec3(Pf1.x, Pf0.y, Pf0.z));
    float n010 = glm::dot(g010, glm::vec3(Pf0.x, Pf1.y, Pf0.z));
    float n110 = glm::dot(g110, glm::vec3(Pf1.x, Pf1.y, Pf0.z));
    float n001 = glm::dot(g001, glm::vec3(Pf0.x, Pf0.y, Pf1.z));
    float n101 = glm::dot(g101, glm::vec3(Pf1.x, Pf0.y, Pf1.z));
    float n011 = glm::dot(g011, glm::vec3(Pf0.x, Pf1.y, Pf1.z));
    float n111 = glm::dot(g111, Pf1);

    glm::vec3 fade_xyz = Pf0 * Pf0 * Pf0 * (Pf0 * (Pf0 * 6.0f - 15.0f) + 10.0f);
    glm::vec4 n_z = glm::mix(glm::vec4(n000, n100, n010, n110), glm::vec4(n001, n101, n011, n111), fade_xyz.z);
    glm::vec2 n_yz = glm::mix(glm::vec2(n_z.x, n_z.y), glm::vec2(n_z.z, n_z.w), fade_xyz.y);
    float n_xyz = glm::mix(n_yz.x, n_yz.y, fade_xyz.x);
    return 2.2f * n_xyz;
}

static float evalEnvelope_cpu(glm::vec3 p, const float* v) {
    float f0 = v[0];
    if (f0 == 0.0f) return 0.0f;
    float f1 = std::clamp(v[1] - (std::abs(v[2]) >= 1e-6f ? std::abs(p.x) / v[2] : 0.0f), v[3], v[4]);
    if (f1 == 0.0f) return 0.0f;
    float f2 = std::clamp(v[5] * (p.y + v[6]), v[7], v[8]);
    if (f2 == 0.0f) return 0.0f;
    float f3 = std::clamp(v[9] - (std::abs(v[10]) >= 1e-6f ? (p.y + v[11]) / v[10] : 0.0f), v[12], v[13]);
    if (f3 == 0.0f) return 0.0f;
    float z_curve = p.z + v[16] * std::sin(v[17] * p.x + v[18])
                        + v[19] * std::cos(v[20] * p.x + v[21])
                        + v[22] * std::sin(v[23] * p.x + v[24]);
    float f4 = std::clamp(v[14] - (std::abs(v[15]) >= 1e-6f ? std::abs(z_curve) / v[15] : 0.0f), v[25], v[26]);
    if (f4 == 0.0f) return 0.0f;
    float f5 = v[27] + v[28] * std::cos(v[29] * p.x + v[30])
                     + v[31] * std::cos(v[32] * p.x + v[33]);
    if (f5 == 0.0f) return 0.0f;
    return f0 * f1 * f2 * f3 * f4 * f5;
}

static J stats(std::vector<double> e) {
    if (e.empty()) return J{{"mean", 0.0}, {"rms", 0.0}, {"min", 0.0}, {"p50", 0.0}, {"p90", 0.0}, {"p99", 0.0}, {"max", 0.0}};
    std::sort(e.begin(), e.end());
    double sum = 0, sq = 0;
    for (double x : e) { sum += x; sq += x * x; }
    size_t n = e.size();
    return J{
        {"mean", sum / n},
        {"rms", std::sqrt(sq / n)},
        {"min", e.front()},
        {"p50", e[n * 50 / 100]},
        {"p90", e[n * 90 / 100]},
        {"p99", e[n * 99 / 100]},
        {"max", e.back()}
    };
}


// Scratch admission for an original shared mathematical factor. No spatial
// samples are used to infer proportionality. Future reusable derivation belongs
// to OntoMath; these pinned backend diagnostics grant no omission authority.
static double literalCoefficient(const OntoMath::MathNode& n){
    if(n.op!=OntoMath::MathNode::Op::ScalarLeaf||n.unsupported||!n.children.empty()||n.scalarForm.terms.size()!=1)
        throw std::runtime_error("coefficient is not a literal scalar");
    const auto& term=n.scalarForm.terms[0];
    if(!term.factors.empty()||!term.trans.empty()||!std::isfinite(term.coefficient)||!(term.coefficient>0))
        throw std::runtime_error("coefficient requires a positive finite literal");
    return term.coefficient;
}
static void legacyBindOriginalCoefficients(Medium& m,double clock){
    for(auto n:{m.density,m.sigma,m.emission})
        if(!n||n->op!=OntoMath::MathNode::Op::Scale||n->unsupported||n->children.size()!=2||!n->children[0]||!n->children[1])
            throw std::runtime_error("transport common-factor shape refused");
    const double cD=literalCoefficient(*m.density->children[0]);
    const double cX=literalCoefficient(*m.sigma->children[0]);
    const auto B=m.density->children[1]->toJson();
    if(B!=m.sigma->children[1]->toJson()||B!=m.emission->children[0]->toJson())
        throw std::runtime_error("original common-factor subtrees differ");
    const auto& V=*m.emission->children[1];std::set<std::string> deps;V.collectDependencies(deps);
    for(const auto& dep:deps)if(dep!=OntoMath::kTimeVar)
        throw std::runtime_error("emission coefficient is not time-only");
    const auto value=V.evaluate({{OntoMath::kTimeVar,PropertyValue(clock)}});
    if(!value||!std::holds_alternative<glm::vec3>(*value))throw std::runtime_error("time-only vector evaluation refused");
    const auto v=std::get<glm::vec3>(*value);
    for(int k=0;k<3;++k)if(!std::isfinite(v[k])||v[k]<0)throw std::runtime_error("emission coefficient invalid");
    m.alpha=float(cX/cD);m.color=v/float(cX);
}


static OntoMath::CommonScalarFactor deriveOriginalCoefficients(const Medium& m){
    if(!m.density||!m.sigma||!m.emission)throw std::runtime_error("missing original channels");
    // Screen owns this diagnostic consumer's positive-literal policy, not the
    // generic factor office. No computed divisor/exponent admission is added.
    if(m.density->op!=M::Op::Scale||m.sigma->op!=M::Op::Scale||m.emission->op!=M::Op::Scale||
       m.density->children.size()!=2||m.sigma->children.size()!=2||m.emission->children.size()!=2||
       !m.density->children[0]||!m.sigma->children[0])throw std::runtime_error("transport source shape refused");
    literalCoefficient(*m.density->children[0]);literalCoefficient(*m.sigma->children[0]);
    OntoMath::TypeEnv env={{"p",OntoMath::ValueKind::Vector},{"x",OntoMath::ValueKind::Scalar},
        {"y",OntoMath::ValueKind::Scalar},{"z",OntoMath::ValueKind::Scalar},{OntoMath::kTimeVar,OntoMath::ValueKind::Scalar}};
    std::string why;auto recipe=OntoMath::factorCommonScalar({m.density,m.sigma,m.emission},env,{OntoMath::kTimeVar},&why);
    if(!recipe||recipe->factorChild!=std::vector<unsigned>({1,1,0}))
        throw std::runtime_error("transport factor recipe refused: "+why);
    if(recipe->coefficients[2].typeOf(env).kind!=OntoMath::ValueKind::Vector)
        throw std::runtime_error("transport coefficient must be vector");
    return std::move(*recipe);
}
static void prepareOriginalCoefficients(Medium& m,const OntoMath::CommonScalarFactor& recipe,double clock){
    if(!std::isfinite(clock))throw std::runtime_error("nonfinite explicit clock");
    std::string why;const auto values=OntoMath::evaluateFactorCoefficients(recipe,{{OntoMath::kTimeVar,PropertyValue(clock)}},&why);
    if(!values||values->size()!=3||!std::holds_alternative<glm::vec3>((*values)[2]))
        throw std::runtime_error("coefficient preparation refused: "+why);
    const auto cD=literalCoefficient(recipe.coefficients[0]);const auto cX=literalCoefficient(recipe.coefficients[1]);
    const auto v=std::get<glm::vec3>((*values)[2]);
    const float alpha=float(cX/cD),sigma=float(cX);const auto color=v/sigma;
    if(!(alpha>0)||!std::isfinite(alpha)||!(sigma>0)||!std::isfinite(sigma))throw std::runtime_error("backend scalar conversion refused");
    for(int k=0;k<3;++k)if(!std::isfinite(color[k])||color[k]<0)throw std::runtime_error("backend color conversion refused");
    m.alpha=alpha;m.color=color;
}
// Compatibility entry for the existing refusal witness: fresh admission each
// call. Actual main below keeps owned recipes for separate clock preparation.
static void bindOriginalCoefficients(Medium& m,double clock){
    auto recipe=deriveOriginalCoefficients(m);prepareOriginalCoefficients(m,recipe,clock);
}


static const char* kResetCountersWgsl = R"WGSL(
struct DispatchCounters {
    s1Count: atomic<u32>,
    s2Count: atomic<u32>,
    fallbackCount: atomic<u32>,
    pad0: u32,
};

@group(0) @binding(0) var<storage, read_write> counters: DispatchCounters;

@compute @workgroup_size(1, 1, 1)
fn resetCountersMain(@builtin(global_invocation_id) gid: vec3u) {
    atomicStore(&counters.s1Count, 0u);
    atomicStore(&counters.s2Count, 0u);
    atomicStore(&counters.fallbackCount, 0u);
}
)WGSL";
static const char* kClassifyWgsl = R"WGSL(
struct CurtainSpec {
    origin: vec4f,
    half: vec4f,
    limits: vec4f,
    curv: vec4f,
    amps: vec4f,
    freqs: vec4f,
    phases: vec4f,
};

struct Ray {
    ro_clipA: vec4f,
    rd_clipB: vec4f,
    counts: vec4u,
};

struct DispatchCounters {
    s1Count: atomic<u32>,
    s2Count: atomic<u32>,
    fallbackCount: atomic<u32>,
    pad0: u32,
};

@group(0) @binding(0) var<storage, read> curtains: array<CurtainSpec, 4>;
@group(0) @binding(1) var<storage, read> rays: array<Ray>;
@group(0) @binding(2) var<storage, read> tileOffsets: array<u32, 2305>;
@group(0) @binding(3) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(4) var<storage, read_write> s1TileList: array<u32>;
@group(0) @binding(5) var<storage, read_write> s2TileList: array<u32>;
@group(0) @binding(6) var<storage, read_write> fallbackTileList: array<u32>;
@group(0) @binding(7) var<storage, read_write> counters: DispatchCounters;

fn evalWave(cur: CurtainSpec, x: f32) -> f32 {
    return cur.amps.x * sin(cur.freqs.x * x + cur.phases.x) +
           cur.amps.y * cos(cur.freqs.y * x + cur.phases.y) +
           cur.amps.z * sin(cur.freqs.z * x + cur.phases.z);
}

@compute @workgroup_size(64, 1, 1)
fn classifyTilesMain(@builtin(global_invocation_id) gid: vec3u) {
    let tileId = gid.x;
    if (tileId >= 2304u) { return; }

    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;

    var activeMemberMask = 0u;
    var tileCanOverlap = false;
    var enterArr: array<f32, 4>;
    var exitArr: array<f32, 4>;
    var memberHit: array<bool, 4>;

    for (var m = 0u; m < 4u; m++) {
        let cur = curtains[m];
        var uxMin = 1e9f;
        var uxMax = -1e9f;
        var anyRayHit = false;
        var rA: array<f32, 16>;
        var rB: array<f32, 16>;
        var rHit: array<bool, 16>;

        for (var i = 0u; i < rayCount && i < 16u; i++) {
            let rIdx = tileRayIndices[rayStart + i];
            let ray = rays[rIdx];
            let oRel = ray.ro_clipA.xyz - cur.origin.xyz;
            var a = ray.ro_clipA.w;
            var b = ray.rd_clipB.w;
            var hit = true;

            for (var axis = 0; axis < 3; axis++) {
                var half = cur.half[axis];
                if (axis == 0) { half = min(half, cur.limits.x); }
                if (axis == 1) { half = min(half, cur.limits.y); }
                let d = ray.rd_clipB[axis];
                let o = oRel[axis];
                if (d == 0.0) {
                    if (abs(o) > half + cur.curv.y) { hit = false; break; }
                } else {
                    let q0 = (-half - cur.curv.y - o) / d;
                    let q1 = (half + cur.curv.y - o) / d;
                    a = max(a, min(q0, q1));
                    b = min(b, max(q0, q1));
                }
            }

            rA[i] = a;
            rB[i] = b;
            rHit[i] = (hit && b > a);

            if (hit && b > a) {
                anyRayHit = true;
                let u0 = oRel.x + a * ray.rd_clipB.x;
                let u1 = oRel.x + b * ray.rd_clipB.x;
                uxMin = min(uxMin, min(u0, u1));
                uxMax = max(uxMax, max(u0, u1));
            }
        }

        if (anyRayHit && uxMax > uxMin) {
            var wKnots: array<f32, 9>;
            for (var k = 0u; k < 9u; k++) {
                let ux = uxMin + f32(k) / 8.0 * (uxMax - uxMin);
                wKnots[k] = evalWave(cur, ux);
            }
            let h_ux = (uxMax - uxMin) / 8.0;
            let bow = 0.125 * cur.curv.x * h_ux * h_ux;
            let thresh = bow + cur.limits.w + 0.001;

            var enter = 1e9f;
            var exit = -1e9f;
            var curActive = false;

            for (var i = 0u; i < rayCount && i < 16u; i++) {
                if (!rHit[i]) { continue; }
                let rIdx = tileRayIndices[rayStart + i];
                let ray = rays[rIdx];
                let oRel = ray.ro_clipA.xyz - cur.origin.xyz;
                let dx = ray.rd_clipB.x;
                if (abs(dx) < 1e-6) { curActive = true; enter = min(enter, rA[i]); exit = max(exit, rB[i]); break; }

                let a = rA[i];
                let b = rB[i];

                for (var bin = 0u; bin < 8u; bin++) {
                    let u0 = uxMin + f32(bin) / 8.0 * (uxMax - uxMin);
                    let u1 = uxMin + f32(bin + 1u) / 8.0 * (uxMax - uxMin);
                    let su0 = (u0 - oRel.x) / dx;
                    let su1 = (u1 - oRel.x) / dx;
                    let phi0 = oRel.z + su0 * ray.rd_clipB.z + wKnots[bin];
                    let phi1 = oRel.z + su1 * ray.rd_clipB.z + wKnots[bin + 1u];

                    let sMin = min(su0, su1);
                    let sMax = max(su0, su1);
                    let cLo = max(a, sMin);
                    let cHi = min(b, sMax);

                    if (cHi > cLo) {
                        let tA = (cLo - su0) / (su1 - su0);
                        let tB = (cHi - su0) / (su1 - su0);
                        let pA = phi0 + tA * (phi1 - phi0);
                        let pB = phi0 + tB * (phi1 - phi0);

                        if (!(min(pA, pB) > thresh || max(pA, pB) < -thresh)) {
                            curActive = true;
                            enter = min(enter, cLo);
                            exit = max(exit, cHi);
                        }
                    }
                }
            }

            if (curActive) {
                activeMemberMask |= (1u << m);
                memberHit[m] = true;
                enterArr[m] = enter;
                exitArr[m] = exit;
            }
        } else if (anyRayHit) {
            // No intrinsic interval was established (e.g. exactly dx=0).
            // Unknown support remains active; never infer empty from zero width.
            activeMemberMask |= (1u << m);
            memberHit[m] = true;
            var enter = 1e9f; var exit = -1e9f;
            for (var i = 0u; i < rayCount && i < 16u; i++) {
                if (rHit[i]) { enter = min(enter, rA[i]); exit = max(exit, rB[i]); }
            }
            enterArr[m] = enter; exitArr[m] = exit;
        }
    }

    let activeCount = countOneBits(activeMemberMask);
    if (activeCount > 1u) {
        for (var m1 = 0u; m1 < 4u; m1++) {
            if (!memberHit[m1]) { continue; }
            for (var m2 = m1 + 1u; m2 < 4u; m2++) {
                if (!memberHit[m2]) { continue; }
                let lo = max(enterArr[m1], enterArr[m2]);
                let hi = min(exitArr[m1], exitArr[m2]);
                if (hi > lo) { tileCanOverlap = true; }
            }
        }
    }

    if (activeMemberMask == 1u && !tileCanOverlap) {
        let slot = atomicAdd(&counters.s1Count, 1u);
        s1TileList[slot] = tileId;
    } else if (activeMemberMask == 3u && !tileCanOverlap && exitArr[0u] <= enterArr[1u]) {
        let slot = atomicAdd(&counters.s2Count, 1u);
        s2TileList[slot] = tileId;
    } else {
        let slot = atomicAdd(&counters.fallbackCount, 1u);
        fallbackTileList[slot] = tileId;
    }
}
)WGSL";
static const char* kRouteArgsWgsl = R"WGSL(
@group(0) @binding(0) var<storage, read> counts: array<u32>;
@group(0) @binding(1) var<storage, read_write> args: array<u32>;
@compute @workgroup_size(1) fn routeArgs(@builtin(global_invocation_id) id: vec3u) {
    if (id.x >= 3u) { return; }
    let n = min(counts[id.x], 2304u);
    args[3u * id.x] = (n + 3u) / 4u;
    args[3u * id.x + 1u] = 1u;
    args[3u * id.x + 2u] = 1u;
}
)WGSL";
static const char* kS1UnfusedProducerWgsl = R"WGSL(

struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32, 2305>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> s1TileList: array<u32>;
@group(0) @binding(8) var<storage, read> routeCounts: array<u32>;

@compute @workgroup_size(64, 1, 1)
fn s1ProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts[0u], 2304u)) { return; }
    let tileId = s1TileList[tileSlot];
    if (tileId >= 2304u) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 1u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  var allPositiveH = true;
  let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
  let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
  let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
  if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
   if (work + 24u > cfg.budget) { reason |= 1u; break; }
   work += 24u;
   memCount[member] = 0u;
   continue;
  }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); return; }
 var singles = 0u;
 for (var p = 0u; p < count; p++) {
  let a = pieces[p].x; let b = pieces[p].y;
  let n = max(1u, u32(ceil((b - a) / 4.0)));
  if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
  for (var k = 0u; k < n; k++) {
   let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
   let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
   subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(0u, 0u)); singles++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, 0u); }
}
)WGSL";
static const char* kS1TerminalProducerWgsl = R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
struct MediumParams {
    origin: vec4<f32>,
    color_alpha: vec4<f32>,
    freq_offset: vec4<f32>,
};
struct ParameterBuffer {
    v: array<f32>,
};
@group(0) @binding(4) var<storage, read_write> results: array<vec4<f32>>;
@group(0) @binding(9) var<storage, read> media: array<MediumParams>;
@group(0) @binding(10) var<storage, read> params: ParameterBuffer;

fn mod289(x: vec4<f32>) -> vec4<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn mod289_3(x: vec3<f32>) -> vec3<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn permute4(x: vec4<f32>) -> vec4<f32> {
    return mod289(((x * 34.0) + 1.0) * x);
}
fn taylorInvSqrt(r: vec4<f32>) -> vec4<f32> {
    return 1.79284291400159 - 0.85373472095314 * r;
}

fn cnoise3(P: vec3<f32>) -> f32 {
    let Pi0 = floor(P);
    let Pi1 = Pi0 + vec3<f32>(1.0);
    let Pi0_mod = mod289_3(Pi0);
    let Pi1_mod = mod289_3(Pi1);
    let Pf0 = fract(P);
    let Pf1 = Pf0 - vec3<f32>(1.0);
    let ix = vec4<f32>(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
    let iy = vec4<f32>(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
    let iz0 = vec4<f32>(Pi0_mod.z);
    let iz1 = vec4<f32>(Pi1_mod.z);

    let ixy = permute4(permute4(ix) + iy);
    let ixy0 = permute4(ixy + iz0);
    let ixy1 = permute4(ixy + iz1);

    var gx0 = ixy0 / 7.0;
    var gy0 = fract(floor(gx0) / 7.0) - 0.5;
    gx0 = fract(gx0);
    var gz0 = vec4<f32>(0.5) - abs(gx0) - abs(gy0);
    let sz0 = step(gz0, vec4<f32>(0.0));
    gx0 = gx0 - sz0 * (step(vec4<f32>(0.0), gx0) - 0.5);
    gy0 = gy0 - sz0 * (step(vec4<f32>(0.0), gy0) - 0.5);

    var gx1 = ixy1 / 7.0;
    var gy1 = fract(floor(gx1) / 7.0) - 0.5;
    gx1 = fract(gx1);
    var gz1 = vec4<f32>(0.5) - abs(gx1) - abs(gy1);
    let sz1 = step(gz1, vec4<f32>(0.0));
    gx1 = gx1 - sz1 * (step(vec4<f32>(0.0), gx1) - 0.5);
    gy1 = gy1 - sz1 * (step(vec4<f32>(0.0), gy1) - 0.5);

    var g000 = vec3<f32>(gx0.x,gy0.x,gz0.x);
    var g100 = vec3<f32>(gx0.y,gy0.y,gz0.y);
    var g010 = vec3<f32>(gx0.z,gy0.z,gz0.z);
    var g110 = vec3<f32>(gx0.w,gy0.w,gz0.w);
    var g001 = vec3<f32>(gx1.x,gy1.x,gz1.x);
    var g101 = vec3<f32>(gx1.y,gy1.y,gz1.y);
    var g011 = vec3<f32>(gx1.z,gy1.z,gz1.z);
    var g111 = vec3<f32>(gx1.w,gy1.w,gz1.w);

    let norm0 = taylorInvSqrt(vec4<f32>(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));
    g000 = g000 * norm0.x;
    g010 = g010 * norm0.y;
    g100 = g100 * norm0.z;
    g110 = g110 * norm0.w;
    let norm1 = taylorInvSqrt(vec4<f32>(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));
    g001 = g001 * norm1.x;
    g011 = g011 * norm1.y;
    g101 = g101 * norm1.z;
    g111 = g111 * norm1.w;

    let n000 = dot(g000, Pf0);
    let n100 = dot(g100, vec3<f32>(Pf1.x, Pf0.y, Pf0.z));
    let n010 = dot(g010, vec3<f32>(Pf0.x, Pf1.y, Pf0.z));
    let n110 = dot(g110, vec3<f32>(Pf1.x, Pf1.y, Pf0.z));
    let n001 = dot(g001, vec3<f32>(Pf0.x, Pf0.y, Pf1.z));
    let n101 = dot(g101, vec3<f32>(Pf1.x, Pf0.y, Pf1.z));
    let n011 = dot(g011, vec3<f32>(Pf0.x, Pf1.y, Pf1.z));
    let n111 = dot(g111, Pf1);

    let fade_xyz = Pf0 * Pf0 * Pf0 * (Pf0 * (Pf0 * 6.0 - 15.0) + 10.0);
    let n_z = mix(vec4<f32>(n000, n100, n010, n110), vec4<f32>(n001, n101, n011, n111), fade_xyz.z);
    let n_yz = mix(n_z.xy, n_z.zw, fade_xyz.y);
    let n_xyz = mix(n_yz.x, n_yz.y, fade_xyz.x); 
    return 2.2 * n_xyz;
}

fn evalEnvelope(p: vec3<f32>, paramOffset: u32) -> f32 {
    let f0 = params.v[paramOffset + 0u];
    if (f0 == 0.0) { return 0.0; }
    let f1 = clamp(params.v[paramOffset + 1u] - select(0.0, abs(p.x) / params.v[paramOffset + 2u], abs(params.v[paramOffset + 2u]) >= 1e-06), params.v[paramOffset + 3u], params.v[paramOffset + 4u]);
    if (f1 == 0.0) { return 0.0; }
    let f2 = clamp(params.v[paramOffset + 5u] * (p.y + params.v[paramOffset + 6u]), params.v[paramOffset + 7u], params.v[paramOffset + 8u]);
    if (f2 == 0.0) { return 0.0; }
    let f3 = clamp(params.v[paramOffset + 9u] - select(0.0, (p.y + params.v[paramOffset + 11u]) / params.v[paramOffset + 10u], abs(params.v[paramOffset + 10u]) >= 1e-06), params.v[paramOffset + 12u], params.v[paramOffset + 13u]);
    if (f3 == 0.0) { return 0.0; }
    let z_curve = p.z + params.v[paramOffset + 16u] * sin(params.v[paramOffset + 17u] * p.x + params.v[paramOffset + 18u])
                      + params.v[paramOffset + 19u] * cos(params.v[paramOffset + 20u] * p.x + params.v[paramOffset + 21u])
                      + params.v[paramOffset + 22u] * sin(params.v[paramOffset + 23u] * p.x + params.v[paramOffset + 24u]);
    let f4 = clamp(params.v[paramOffset + 14u] - select(0.0, abs(z_curve) / params.v[paramOffset + 15u], abs(params.v[paramOffset + 15u]) >= 1e-06), params.v[paramOffset + 25u], params.v[paramOffset + 26u]);
    if (f4 == 0.0) { return 0.0; }
    let f5 = params.v[paramOffset + 27u] + params.v[paramOffset + 28u] * cos(params.v[paramOffset + 29u] * p.x + params.v[paramOffset + 30u])
                                         + params.v[paramOffset + 31u] * cos(params.v[paramOffset + 32u] * p.x + params.v[paramOffset + 33u]);
    if (f5 == 0.0) { return 0.0; }
    return f0 * f1 * f2 * f3 * f4 * f5;
}

fn phiSafe(tau: f32) -> f32 {
    if (abs(tau) < 0.01) {
        return 1.0 + tau * (-0.5 + tau * (1.0/6.0 - tau/24.0));
    }
    return (1.0 - exp(-tau)) / tau;
}

const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32, 2305>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> s1TileList: array<u32>;
@group(0) @binding(8) var<uniform> routeCounts: vec4u;

@compute @workgroup_size(64, 1, 1)
fn s1ProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts.x, 2304u)) { return; }
    let tileId = s1TileList[tileSlot];
    if (tileId >= 2304u) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
    let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
    var reason = 0u; var work = 0u; var count = 0u;
    var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
    var knots: array<f32, 96>;
    var memStart = vec4u(0u); var memCount = vec4u(0u);
    if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
    let gx0 = 0.5 * (1.0 - 0.5773502691896257);
    let gx1 = 0.5 * (1.0 + 0.5773502691896257);
    var T = 1.0;
    var L = vec3<f32>(0.0);

    for (var member = 0u; member < 1u; member++) {
        memStart[member] = count;
        let m = curtains[member]; let o = ro - m.origin.xyz;
        var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
        for (var axis = 0u; axis < 3u; axis++) {
            var half = m.half[axis];
            if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
            if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
            else {
                let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
                a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
            }
        }
        if (!hit || !(b > a)) { continue; }
        var phi_knots: array<f32, 9>;
        for (var k = 0u; k < 9u; k++) {
            var s = a + (b - a) * f32(k) / 8.0;
            if (k == 0u) { s = a; } if (k == 8u) { s = b; }
            phi_knots[k] = evalPhi(m, o, d, s);
        }
        var allPositiveH = true;
        let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
        let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
        let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
        if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
            if (work + 24u > cfg.budget) { reason |= 1u; break; }
            work += 24u;
            memCount[member] = 0u;
            continue;
        }
        var nb = 1u; knots[0] = a;
        var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
        roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
        if (reason != 0u) { break; }
        if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
        if (d.y != 0.0) {
            let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
            let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
        }
        knots[nb] = b; nb++;
        for (var i = 1u; i < nb; i++) {
            let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
            knots[j] = v;
        }
        let memberStart = count; var previousShortBand = false; var previousPositive = false;
        for (var i = 1u; i < nb; i++) {
            let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
            let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
            if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
            if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
            for (var k = 0u; k < nr; k++) {
                uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
                if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
            }
            if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
                if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
                     previousShortBand, previousPositive, uncertain, protectedBoundary)) {
                    pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
                } else {
                    if (count >= 48u) { reason |= 8u; break; }
                    pieces[count] = vec2f(l, r);
                    setMember(&pieceMembers, count, member);
                    count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
                }
            }
        }
        memCount[member] = count - memStart[member];
        if (reason != 0u) { break; }
    }
    if (reason != 0u) {
        rays[id].counts = vec4u(subBase, 0u, overBase, FALLBACK | reason);
        return;
    }
    // 1. Pre-check total subpanel count across finalized pieces[0..count-1] BEFORE any quadrature:
    var singles = 0u;
    for (var p = 0u; p < count; p++) {
        let pa = pieces[p].x;
        let pb = pieces[p].y;
        let n = max(1u, u32(ceil((pb - pa) / 4.0)));
        if (singles + n > cfg.maxSubPerRay) {
            reason |= 16u;
            break;
        }
        singles += n;
    }
    if (reason != 0u) {
        rays[id].counts = vec4u(subBase, 0u, overBase, FALLBACK | reason);
        return;
    }

    // 2. Subdivide pieces[0..count-1] directly in scalar registers and integrate (ZERO global sBuf writes/reads!):
    let rd = d;
    let m = media[0u];
    let pOffset = u32(m.freq_offset.y);
    let freq = m.freq_offset.x;
    let alpha = m.color_alpha.w;
    let color = m.color_alpha.xyz;

    for (var p = 0u; p < count; p++) {
        let pa = pieces[p].x;
        let pb = pieces[p].y;
        let n = max(1u, u32(ceil((pb - pa) / 4.0)));
        for (var k = 0u; k < n; k++) {
            let s0 = select(pa + f32(k) * (pb - pa) / f32(n), pa, k == 0u);
            let s1 = select(pa + f32(k + 1u) * (pb - pa) / f32(n), pb, k + 1u == n);
            let sub_h = s1 - s0;

            let s_m = s0 + gx0 * sub_h;
            let s_p = s0 + gx1 * sub_h;
            let w_m = ro + s_m * rd - m.origin.xyz;
            let w_p = ro + s_p * rd - m.origin.xyz;

            let env_m = evalEnvelope(w_m, pOffset);
            let env_p = evalEnvelope(w_p, pOffset);

            var D_m = 0.0;
            if (env_m > 0.0) {
                let nm = cnoise3(freq * w_m);
                D_m = env_m * clamp(0.7 + 0.3 * nm, 0.0, 1.0);
            }
            var D_p = 0.0;
            if (env_p > 0.0) {
                let np = cnoise3(freq * w_p);
                D_p = env_p * clamp(0.7 + 0.3 * np, 0.0, 1.0);
            }

            let sig_m = select(0.0, max(alpha * D_m, 1e-6), D_m > 0.0);
            let em_m  = select(vec3<f32>(0.0), color * (alpha * D_m), D_m > 0.0);
            let sig_p = select(0.0, max(alpha * D_p, 1e-6), D_p > 0.0);
            let em_p  = select(vec3<f32>(0.0), color * (alpha * D_p), D_p > 0.0);

            let sig_avg = 0.5 * (sig_m + sig_p);
            let em_avg  = 0.5 * (em_m + em_p);
            let tau = sub_h * sig_avg;
            let atten = exp(-tau);

            var gain: f32;
            gain = sub_h * phiSafe(tau);

            L = L + T * em_avg * gain;
            T = T * atten;
        }
    }
    results[id] = vec4<f32>(L, T);
    rays[id].counts = vec4u(subBase, singles, overBase, 0x40000000u);
}
)WGSL";
static const char* kS2ProducerWgsl = R"WGSL(

struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32, 2305>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> s2TileList: array<u32>;
@group(0) @binding(8) var<storage, read> routeCounts: array<u32>;

@compute @workgroup_size(64, 1, 1)
fn s2ProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts[1u], 2304u)) { return; }
    let tileId = s2TileList[tileSlot];
    if (tileId >= 2304u) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    
    let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
    let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
    var reason = 0u; var work = 0u; var count = 0u;
    var pieces: array<vec2f, 48>;
    var knots: array<f32, 96>;
    if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }

    var singles = 0u;
    for (var member = 0u; member < 2u; member++) {
        let m = curtains[member]; let o = ro - m.origin.xyz;
        var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
        for (var axis = 0u; axis < 3u; axis++) {
            var half = m.half[axis];
            if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
            if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
            else {
                let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
                a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
            }
        }
        if (!hit || !(b > a)) { continue; }
        var phi_knots: array<f32, 9>;
        for (var k = 0u; k < 9u; k++) {
            var s = a + (b - a) * f32(k) / 8.0;
            if (k == 0u) { s = a; } if (k == 8u) { s = b; }
            phi_knots[k] = evalPhi(m, o, d, s);
        }
        var allPositiveH = true;
        let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
        let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
        let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
        if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
            if (work + 24u > cfg.budget) { reason |= 1u; break; }
            work += 24u;
            continue;
        }
        var nb = 1u; knots[0] = a;
        var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
        roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
        if (reason != 0u) { break; }
        if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
        if (d.y != 0.0) {
            let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
            let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
        }
        knots[nb] = b; nb++;
        for (var i = 1u; i < nb; i++) {
            let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
            knots[j] = v;
        }
        var memPieces = 0u;
        var previousShortBand = false; var previousPositive = false;
        for (var i = 1u; i < nb; i++) {
            let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
            let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
            if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
            if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
            for (var k = 0u; k < nr; k++) {
                uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
                if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
            }
            if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
                if (memPieces > 0u && mayAbsorb(pieces[memPieces - 1u], vec2f(l, r),
                     previousShortBand, previousPositive, uncertain, protectedBoundary)) {
                    pieces[memPieces - 1u].y = r; previousShortBand = false; previousPositive = true;
                } else {
                    // Capacity is shared across both members in the bulk producer.
                    if (count >= 48u) { reason |= 8u; break; }
                    pieces[memPieces] = vec2f(l, r);
                    memPieces++; count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
                }
            }
        }
        if (reason != 0u) { break; }

        for (var p = 0u; p < memPieces; p++) {
            let pa = pieces[p].x; let pb = pieces[p].y;
            let n = max(1u, u32(ceil((pb - pa) / 4.0)));
            if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
            for (var k = 0u; k < n; k++) {
                let sl = select(pa + f32(k) * (pb - pa) / f32(n), pa, k == 0u);
                let sr = select(pa + f32(k + 1u) * (pb - pa) / f32(n), pb, k + 1u == n);
                subpanels[subBase + singles] = Subpanel(vec2f(sl, sr), vec2u(member, 0u));
                singles++;
            }
        }
    }
    if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
    else { rays[id].counts = vec4u(subBase, singles, overBase, 0u); }
}
)WGSL";
static const char* kFallbackProducerWgsl = R"WGSL(

struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32, 2305>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> fallbackTileList: array<u32>;
@group(0) @binding(8) var<storage, read> routeCounts: array<u32>;

@compute @workgroup_size(64, 1, 1)
fn fallbackProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts[2u], 2304u)) { return; }
    let tileId = fallbackTileList[tileSlot];
    if (tileId >= 2304u) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 4u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  var allPositiveH = true;
  let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
  let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
  let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
  if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
   if (work + 24u > cfg.budget) { reason |= 1u; break; }
   work += 24u;
   memCount[member] = 0u;
   continue;
  }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); return; }
 var ne = 0u;
 var head = vec4u(0u);
 let totalKnots = (memCount.x + memCount.y + memCount.z + memCount.w) * 2u;
 loop {
  if (ne >= totalKnots) { break; }
  var bestM = 4u;
  var bestVal = 0.0;
  for (var m = 0u; m < 4u; m++) {
   let h = head[m];
   if (h < memCount[m] * 2u) {
    let pIdx = memStart[m] + (h >> 1u);
    let isY = (h & 1u) != 0u;
    let val = select(pieces[pIdx].x, pieces[pIdx].y, isY);
    if (bestM == 4u || val < bestVal) {
     bestVal = val;
     bestM = m;
    }
   }
  }
  knots[ne] = bestVal;
  ne++;
  head[bestM]++;
 }
 var singles = 0u; var overs = 0u;
 var pIdx = vec4u(0u);
 for (var i = 1u; i < ne && reason == 0u; i++) {
  let a = knots[i - 1u]; let b = knots[i]; if (!(b > a)) { continue; }
  let mid = a + 0.5 * (b - a);
  var mask = 0u;
  for (var m = 0u; m < 4u; m++) {
   let start = memStart[m];
   let numPieces = memCount[m];
   var cur = pIdx[m];
   loop {
    if (cur >= numPieces || pieces[start + cur].y >= mid) { break; }
    cur++;
   }
   pIdx[m] = cur;
   if (cur < numPieces) {
    let p = pieces[start + cur];
    if (mid >= p.x && mid <= p.y) {
     mask |= (1u << m);
    }
   }
  }
  if (mask == 0u) { continue; }
  if (countOneBits(mask) == 1u) {
   let n = max(1u, u32(ceil((b - a) / 4.0)));
   if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
   let member = firstTrailingBit(mask);
   for (var k = 0u; k < n; k++) {
    let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
    let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
    subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(member, 0)); singles++;
   }
  } else {
   if (overs >= cfg.maxOverPerRay) { reason |= 32u; break; }
   overlaps[overBase + overs] = Overlap(vec2f(a, b), vec2u(mask, 0)); overs++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, overs); }
}
)WGSL";

int main(int argc, char** argv) {
    std::string outputPath = argc > 1 ? argv[1] : "";

    std::ifstream in("saves/zones/Northern Veil/zone.ecform", std::ios::binary);
    std::vector<uint8_t> b((std::istreambuf_iterator<char>(in)), {});
    J zone = J::parse(J::from_msgpack(b).at("MigrationRoot").get<std::string>());

    double clock = std::stod(std::getenv("EC_POSE_CLOCK"));
    std::vector<Medium> media;
    const float alphas[4] = {2.0f/15.0f, 9.0f/65.0f, 8.0f/55.0f, 4.0f/25.0f};
    const glm::vec3 colors[4] = {
        {0.0747842f, 0.688014f, 0.239309f},
        {0.0391309f, 0.547833f, 0.641747f},
        {0.680411f,  0.103093f, 0.701029f},
        {0.612595f,  0.108105f, 0.198192f}
    };
    const float freqs[4] = {0.08f, 0.09f, 0.07f, 0.10f};

    double coefficientBindingMs=0,coefficientPreparationMs=0;
    std::vector<OntoMath::CommonScalarFactor> coefficientRecipes;
    std::vector<float> globalParamPool;
    int idx = 0;
    for (auto& j : zone.at("spatialFields")) {
        auto field = geom::FieldNode::fromJson(j);
        Rendering::VolumeDensityBinding bnd;
        if (!field || !Rendering::readVolumeDensity(*field, 0, 0, bnd)) continue;
        Medium m;
        m.owner = field;
        m.id = bnd.producerId;
        m.origin = glm::dvec3(bnd.origin);
        m.half = glm::abs(glm::dvec3(bnd.scale));
        m.density = single(bnd.densityExpr);
        m.sigma = single(bnd.extinctionExpr);
        m.emission = single(bnd.emissionExpr);
        {auto begin=std::chrono::steady_clock::now();coefficientRecipes.push_back(deriveOriginalCoefficients(m));coefficientBindingMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();begin=std::chrono::steady_clock::now();prepareOriginalCoefficients(m,coefficientRecipes.back(),clock);coefficientPreparationMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();}
        m.noiseFreq = freqs[idx];
        m.envAST = cloneEnvelope(*m.density);

        auto res = OntoMath::restrictAlgebraicToLine(*m.envAST, false, "p");
        if (res) {
            m.envForm = std::move(*res.form);
            m.hasEnv = true;
        }

        auto pb = sdfwgsl::collectVolumeParams(bnd.densityExpr);
        m.paramOffset = static_cast<uint32_t>(globalParamPool.size());
        globalParamPool.insert(globalParamPool.end(), pb.values.begin(), pb.values.end());

        media.push_back(std::move(m));
        ++idx;
    }

    J rays, ref;
    { std::ifstream rin(std::getenv("EC_POSE_RAYS")); rin >> rays; }
    { std::ifstream rref(std::getenv("EC_POSE_REFERENCE")); rref >> ref; }

    const auto& R = rays.at("rays");
    const auto& Rows = ref.at("rows");
    const glm::dvec3 ro(rays["origin"][0], rays["origin"][1], rays["origin"][2]);
    size_t count = std::getenv("EC_GPU_GEOMETRY_CASE")?16:R.size();
    std::map<uint32_t, std::vector<uint32_t>> groups4x4;
    for (size_t i = 0; i < count; ++i) {
        int px = R[i][0].get<int>(), py = R[i][1].get<int>();
        int gx = px / 10, gy = py / 10;
        uint32_t tx = gx / 4, ty = gy / 4;
        uint32_t key = (ty << 16) | tx;
        groups4x4[key].push_back(uint32_t(i));
    }
    if (groups4x4.size() != 2304u) throw std::runtime_error("pinned tile layout requires exactly 2304 tiles");
    for (const auto& [key, indices] : groups4x4) {
        if (indices.empty() || indices.size() > 16u) throw std::runtime_error("pinned tile capacity exceeded");
    }
    std::vector<uint32_t> tileOffsets(2305, 0);
    std::vector<uint32_t> tileRayIndices;
    tileRayIndices.reserve(count);
    size_t tIdx = 0;
    for (const auto& [k, rVec] : groups4x4) {
        tileOffsets[tIdx] = uint32_t(tileRayIndices.size());
        tileRayIndices.insert(tileRayIndices.end(), rVec.begin(), rVec.end());
        tIdx++;
    }
    tileOffsets[2304] = uint32_t(tileRayIndices.size());

    // Schedule buffers
    std::vector<GpuRayHeader> gpuRays(count);
    std::vector<GpuSubpanel> gpuSubpanels;
    std::vector<GpuOverlap> gpuOverlaps;

    uint32_t maxSubpanelsPerRay = 0;


    std::vector<uint32_t> producerFlags(count,0);
    for(size_t i=0;i<count;++i){
        const auto& row=R[i];auto& ray=gpuRays[i];
        for(int k=0;k<3;++k){ray.ro[k]=float(ro[k]);ray.rd[k]=row[2+k];}
        ray.clipA=row[5];ray.clipB=row[6];
    }
    std::vector<GpuMediumParams> gpuMedia(media.size());
    for (size_t m = 0; m < media.size(); ++m) {
        gpuMedia[m].origin[0] = float(media[m].origin.x);
        gpuMedia[m].origin[1] = float(media[m].origin.y);
        gpuMedia[m].origin[2] = float(media[m].origin.z);
        gpuMedia[m].origin[3] = 0.0f;

        gpuMedia[m].color[0] = media[m].color.r;
        gpuMedia[m].color[1] = media[m].color.g;
        gpuMedia[m].color[2] = media[m].color.b;
        gpuMedia[m].color[3] = media[m].alpha;

        gpuMedia[m].freq[0] = media[m].noiseFreq;
        gpuMedia[m].freq[1] = float(media[m].paramOffset);
        gpuMedia[m].freq[2] = 0.0f;
        gpuMedia[m].freq[3] = 0.0f;
    }

    // Workload accounting
    size_t rayBytes = gpuRays.size() * sizeof(GpuRayHeader);
    
    const uint32_t maxSubPerRay = std::getenv("EC_GPU_SUB_CAP")?std::stoul(std::getenv("EC_GPU_SUB_CAP")):64;
    const uint32_t maxOverPerRay = std::getenv("EC_GPU_OVER_CAP")?std::stoul(std::getenv("EC_GPU_OVER_CAP")):16;
    const size_t totalSub = count * maxSubPerRay;
    const size_t totalOver = count * maxOverPerRay;
    size_t subpanelBytes = totalSub * sizeof(GpuSubpanel);
    size_t overlapBytes = totalOver * sizeof(GpuOverlap);

    // Sized above for GPU producer
    size_t mediaBytes = gpuMedia.size() * sizeof(GpuMediumParams);
    size_t paramBytes = globalParamPool.size() * sizeof(float);
    size_t totalScheduleBytes = rayBytes + subpanelBytes + overlapBytes + mediaBytes + paramBytes;

    std::cout << "Schedule exported:\n"
              << "  Rays: " << count << " (" << rayBytes << " bytes)\n"
              << "  Subpanels: " << gpuSubpanels.size() << " (" << subpanelBytes << " bytes, max " << maxSubpanelsPerRay << "/ray)\n"
              << "  Overlaps: " << gpuOverlaps.size() << " (" << overlapBytes << " bytes)\n"
              << "  Total Schedule Size: " << totalScheduleBytes << " bytes (" << (totalScheduleBytes / 1024.0) << " KB)\n";


    struct alignas(16) CurrentUniforms {
        glm::mat4 viewProj{1},invViewProj{1};
        glm::vec4 eyePos,viewport,incidentSource,incidentColor,sourceTime,volumeControl,volumeOutputError;
    };
    struct alignas(16) CurrentInstance {
        glm::vec4 origin,halfExtent,time;
        uint32_t paramOffset=0,zeroProofOffset=0,zeroProofDims=0,zeroProofPresent=0;
        uint32_t supportCertOffset=0,supportCertCount=0,supportClosedOffset=0,supportClosedCount=0;
    };
    static_assert(sizeof(CurrentUniforms)==240&&sizeof(CurrentInstance)==80);
    const int repeatFactor=std::getenv("EC_MATCH_REPEAT")?std::atoi(std::getenv("EC_MATCH_REPEAT")):1;
    if(repeatFactor<1||repeatFactor>128)throw std::runtime_error("repeat outside 1..128");
    const size_t executionRays=count*size_t(repeatFactor);
    CurrentUniforms currentU{};
    currentU.eyePos=glm::vec4(ro,1);currentU.viewport={2560,1440,float(executionRays),1};
    currentU.incidentSource={0,0,0,1};currentU.incidentColor=glm::vec4(1);currentU.sourceTime={float(clock),0,0,0};
    currentU.volumeControl={24,1,0,96};currentU.volumeOutputError=glm::vec4(0);
    auto rootLight=geom::FieldNode::fromJson(zone.at("spatialRoot"));
    if(!rootLight||!rootLight->field)throw std::runtime_error("missing authored source");
    auto light=single(&rootLight->field->astDefinition);
    if(!light||light->op!=M::Op::ScalarLeaf)throw std::runtime_error("source is not admitted zero literal");
    for(const auto& term:light->scalarForm.terms)if(term.coefficient!=0)throw std::runtime_error("not zero source");
    std::vector<sdfwgsl::VolumeProgramInput> currentInputs;
    std::vector<sdfwgsl::KernelVolumeEvaluator> currentEvaluators;
    std::vector<CurrentInstance> currentInstances(media.size()+1);
    uint32_t offset=0;bool trim=true;
    for(size_t id=0;id<media.size();++id) {
        Rendering::VolumeDensityBinding b;
        if(!Rendering::readVolumeDensity(*media[id].owner,0,0,b))throw std::runtime_error("binding refusal");
        sdfwgsl::VolumeProgramInput in;
        in.densityExpr=b.densityExpr;in.extinctionExpr=b.extinctionExpr;in.scatteringExpr=b.scatteringExpr;
        in.volumeChromaExpr=b.volumeChromaExpr;in.phaseExpr=b.phaseExpr;in.emissionExpr=b.emissionExpr;
        in.occluderSdf=b.occluderSdf;in.lightRadianceExpr=&rootLight->field->astDefinition;
        currentInputs.push_back(in);currentEvaluators.push_back(sdfwgsl::lowerVolumeEvaluator(in));
        if(!currentEvaluators.back().program.ok)throw std::runtime_error(currentEvaluators.back().program.error);
        auto& inst=currentInstances[id+1];inst.origin=glm::vec4(media[id].origin,0);inst.halfExtent=glm::vec4(media[id].half,0);
        inst.time={float(clock),0,0,0};inst.paramOffset=offset;offset+=currentEvaluators.back().program.params.size();
        if(glm::all(glm::lessThanEqual(glm::abs(ro-media[id].origin),media[id].half)))trim=false;
    }
    auto currentProgram=sdfwgsl::composeVolumeSet(currentInputs,currentEvaluators,trim);
    if(!currentProgram.ok)throw std::runtime_error(currentProgram.error);
    auto currentParams=currentProgram.params;
    for(size_t id=0;id<media.size();++id) {
        auto proof=Rendering::buildVolumeZeroProof(*currentInputs[id].densityExpr,glm::vec3(media[id].half));
        if(!proof.any())continue;
        auto& inst=currentInstances[id+1];inst.zeroProofOffset=currentParams.size();
        inst.zeroProofDims=proof.dims.x|(proof.dims.y<<10u)|(proof.dims.z<<20u);
        inst.zeroProofPresent=trim?1u|((proof.supportAxis+1u)<<1u):1u;
        currentParams.insert(currentParams.end(),proof.words.begin(),proof.words.end());
        const auto lo=proof.supportMin,hi=proof.supportMax;
        currentParams.insert(currentParams.end(),{lo.x,lo.y,lo.z,hi.x,hi.y,hi.z});
        if(trim)for(const auto& band:proof.supportBands)currentParams.insert(currentParams.end(),{band.x,band.y,band.z,band.w});
    }
    // Retain the production compiler's generated evaluator and marching body.
    // Only entrypoint/ray inputs and raw output are adapted to compute.
    const auto fs=currentProgram.wgsl.find("@fragment\nfn fs(");
    const auto begin=currentProgram.wgsl.find("    var transmittance = 1.0;",fs);
    const auto end=currentProgram.wgsl.find("    let alpha = 1.0 - transmittance;",begin);
    if(fs==std::string::npos||begin==std::string::npos||end==std::string::npos)throw std::runtime_error("current shader hooks changed");
    const std::string originalMarchingBody=currentProgram.wgsl.substr(begin,end-begin);
    std::string marchingBody=originalMarchingBody;unsigned emptySupportDiscardAdaptations=0;
    const std::string emptySupportDiscard="if (supportEnd <= supportStart) { discard; }";
    auto emptyExit=marchingBody.find(emptySupportDiscard);
    if(emptyExit!=std::string::npos){
        if(marchingBody.find(emptySupportDiscard,emptyExit+1)!=std::string::npos)throw std::runtime_error("duplicate empty support hook");
        marchingBody.replace(emptyExit,emptySupportDiscard.size(),
            "if (supportEnd <= supportStart) { capturedOutput[idx]=vec4<f32>(0.0,0.0,0.0,1.0);return; }");
        emptySupportDiscardAdaptations=1;
    }
    if(marchingBody.find("discard;")!=std::string::npos)throw std::runtime_error("unadmitted fragment-only operation in compute adapter");
    auto adaptBindings=[](std::string text) {
        auto replace=[&](const std::string& a,const std::string& b){auto pos=text.find(a);if(pos==std::string::npos)throw std::runtime_error("current binding hook");text.replace(pos,a.size(),b);};
        replace("@group(0) @binding(2) var sceneDepthTex: texture_depth_2d;","");
        replace("@group(1) @binding(0)","@group(0) @binding(2)");
        return text;
    };
    const std::string extra=R"WGSL(
struct CapturedRay { ro_clipA:vec4<f32>,rd_clipB:vec4<f32>,counts:vec4<u32> };
@group(0) @binding(3) var<storage,read> capturedRays:array<CapturedRay>;
@group(0) @binding(4) var<storage,read_write> capturedOutput:array<vec4<f32>>;
)WGSL";
    std::string currentShader=adaptBindings(currentProgram.wgsl.substr(0,fs))+extra+R"WGSL(
@compute @workgroup_size(64)
fn rayMain(@builtin(global_invocation_id) gid:vec3<u32>) {
 let idx=gid.x;if(idx>=u32(u.viewport.z)){return;}
 let ray=capturedRays[idx%arrayLength(&capturedRays)];
 let ro=ray.ro_clipA.xyz;let rd=ray.rd_clipB.xyz;
 let t0=ray.ro_clipA.w;let t1=ray.rd_clipB.w;g_instIdx=0u;
)WGSL"+marchingBody+R"WGSL(
 capturedOutput[idx]=vec4<f32>(integratedRadiance,transmittance);
}
)WGSL";
    auto prepShader=adaptBindings(currentProgram.kernelVolumePreparationWgsl)+extra;
    if(currentProgram.kernelVolumePreparationWgsl.empty())throw std::runtime_error("expected native clock preparation");
    auto brace=prepShader.find('{',prepShader.find("fn volumeTimePrepare"));
    prepShader.insert(brace+1,"\n if(u.viewport.w<0.0){capturedOutput[0]=vec4<f32>(f32(capturedRays[0].counts.x));return;}\n");
    if(!outputPath.empty()) {
        std::ofstream a(outputPath+"-current.wgsl");a<<currentShader;
        std::ofstream b(outputPath+"-current-march-body.wgsl");b<<marchingBody;
    }

    // --- WebGPU / Metal Initialization ---
    wgpu::Device gpu;
    if (!gpu.init()) {
        std::cerr << "FAILED to initialize WebGPU device on Metal" << std::endl;
        return 1;
    }
    std::cout << "WebGPU device initialized successfully on Metal." << std::endl;

    auto makeBuffer = [&](WGPUBufferUsage usage, uint64_t size, const void* data) -> WGPUBuffer {
        WGPUBufferDescriptor desc = {};
        desc.usage = usage;
        desc.size = size;
        WGPUBuffer b = wgpuDeviceCreateBuffer(gpu.device, &desc);
        if (data) wgpuQueueWriteBuffer(gpu.queue, b, 0, data, size);
        return b;
    };

    struct UniformData { float clock; uint32_t rayCount; uint32_t pad0, pad1; };
    UniformData udata{float(clock), (uint32_t)executionRays, 0, 0};

    WGPUBuffer uBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_CopyDst, sizeof(udata), &udata);
    WGPUBuffer mBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, mediaBytes, gpuMedia.data());
    WGPUBuffer pBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, paramBytes, globalParamPool.data());
    WGPUBuffer rBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst | WGPUBufferUsage_CopySrc, rayBytes, gpuRays.data());
    WGPUBuffer sBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst | WGPUBufferUsage_CopySrc, subpanelBytes, nullptr);
    WGPUBuffer oBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst | WGPUBufferUsage_CopySrc, overlapBytes > 0 ? overlapBytes : 16, nullptr);

    size_t outBytes = executionRays * sizeof(GpuResult);
    WGPUBuffer outBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, outBytes, nullptr);
    WGPUBuffer readBuf = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, outBytes, nullptr);

    // Helper to build pipeline
    auto buildPipeline = [&](const std::string& shaderCode) -> WGPUComputePipeline {
        std::string fullCode = std::string(kCommonWgslHeader) + "\n" + kOverlapWgsl + "\n" + shaderCode;
        wgpuDevicePushErrorScope(gpu.device, WGPUErrorFilter_Validation);

        WGPUShaderSourceWGSL src = {};
        src.chain.sType = WGPUSType_ShaderSourceWGSL;
        src.code = wgpu::Device::str(fullCode.c_str());
        WGPUShaderModuleDescriptor smd = {};
        smd.nextInChain = &src.chain;
        WGPUShaderModule sm = wgpuDeviceCreateShaderModule(gpu.device, &smd);

        WGPUComputePipelineDescriptor cpd = {};
        cpd.compute.module = sm;
        cpd.compute.entryPoint = wgpu::Device::str("rayMain");
        WGPUComputePipeline cp = wgpuDeviceCreateComputePipeline(gpu.device, &cpd);

        PopContext compile;
        WGPUPopErrorScopeCallbackInfo pcb = {};
        pcb.mode = WGPUCallbackMode_AllowProcessEvents;
        pcb.callback = onPopError;
        pcb.userdata1 = &compile;
        wgpuDevicePopErrorScope(gpu.device, pcb);
        while (!compile.done) wgpuDevicePoll(gpu.device, true, nullptr);

        wgpuShaderModuleRelease(sm);
        if (compile.type != WGPUErrorType_NoError) {
            std::cerr << "Failed to compile shader module" << std::endl;
            return nullptr;
        }
        return cp;
    };

    std::cout << "Compiling Unfused A* Metal Compute Pipeline..." << std::endl;
    WGPUComputePipeline cpUnfused = buildPipeline(kUnfusedShader);
    std::cout << "Compiling Fused A* Metal Compute Pipeline..." << std::endl;
    WGPUComputePipeline cpFused = buildPipeline(kFusedShader);

    if (!cpUnfused || !cpFused) {
        std::cerr << "Pipeline creation failed!" << std::endl;
        return 1;
    }

    // Helper to create bind group
    auto makeBindGroup = [&](WGPUComputePipeline cp) -> WGPUBindGroup {
        WGPUBindGroupLayout bgl = wgpuComputePipelineGetBindGroupLayout(cp, 0);
        WGPUBindGroupEntry entries[7] = {};
        entries[0].binding = 0; entries[0].buffer = uBuf; entries[0].size = sizeof(udata);
        entries[1].binding = 1; entries[1].buffer = mBuf; entries[1].size = mediaBytes;
        entries[2].binding = 2; entries[2].buffer = pBuf; entries[2].size = paramBytes;
        entries[3].binding = 3; entries[3].buffer = rBuf; entries[3].size = rayBytes;
        entries[4].binding = 4; entries[4].buffer = sBuf; entries[4].size = subpanelBytes;
        entries[5].binding = 5; entries[5].buffer = oBuf; entries[5].size = overlapBytes > 0 ? overlapBytes : 16;
        entries[6].binding = 6; entries[6].buffer = outBuf; entries[6].size = outBytes;

        WGPUBindGroupDescriptor bgd = {};
        bgd.layout = bgl;
        bgd.entryCount = 7;
        bgd.entries = entries;
        WGPUBindGroup bg = wgpuDeviceCreateBindGroup(gpu.device, &bgd);
        wgpuBindGroupLayoutRelease(bgl);
        return bg;
    };

    WGPUBindGroup bgUnfused = makeBindGroup(cpUnfused);
    WGPUBindGroup bgFused = makeBindGroup(cpFused);

    std::vector<GpuCurtainSpec> curtainSpecs;
    if (!extractCurtainSpecs(zone, curtainSpecs)) {
        throw std::runtime_error("Failed to dynamically extract curtain specs from zone");
    }

    struct GpuProducerConfig {
        uint32_t rayCount;
        uint32_t maxSubPerRay;
        uint32_t maxOverPerRay;
        uint32_t pad;
    } cfg{static_cast<uint32_t>(count), maxSubPerRay, maxOverPerRay, std::getenv("EC_GPU_BUDGET")?uint32_t(std::stoul(std::getenv("EC_GPU_BUDGET"))):1024u};


    const std::string geometryCase=std::getenv("EC_GPU_GEOMETRY_CASE")?std::getenv("EC_GPU_GEOMETRY_CASE"):"";
    if(!geometryCase.empty()){
        for(auto& spec:curtainSpecs){spec.origin=glm::vec4(1000,1000,1000,0);spec.half=glm::vec4(1);}
        auto& spec=curtainSpecs[0];spec.origin=glm::vec4(0);spec.half=glm::vec4(100);
        spec.amps=glm::vec4(0);spec.freqs=glm::vec4(0);spec.phases=glm::vec4(0);
        if(geometryCase=="near-parallel"){
            spec.limits={1,10,0,30};spec.curv={0,.001f,0,0};
            for(auto& ray:gpuRays){ray.ro[0]=1.000001f;ray.ro[1]=ray.ro[2]=0;ray.rd[0]=-1e-7f;ray.rd[1]=0;ray.rd[2]=1;ray.clipA=0;ray.clipB=20;}
        }else{
            spec.limits={2,2,0,geometryCase=="narrow-lobe"?5e-6f:.2f};
            spec.curv={geometryCase=="narrow-lobe"?10000.f:40000.f,.001f,0,0};
            if(geometryCase=="narrow-lobe"){spec.amps.y=1;spec.freqs.y=100;spec.phases.y=-.7f;}
            else {spec.amps.x=1;spec.freqs.x=200;}
            for(auto& ray:gpuRays){ray.ro[0]=ray.ro[1]=0;ray.ro[2]=geometryCase=="narrow-lobe"?-.99999f:0.f;
                ray.rd[0]=1;ray.rd[1]=ray.rd[2]=0;ray.clipA=0;ray.clipB=1;}
        }
        wgpuQueueWriteBuffer(gpu.queue,rBuf,0,gpuRays.data(),rayBytes);
    }

    auto cfgBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_CopyDst, sizeof(cfg), &cfg);
    auto specBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, curtainSpecs.size() * sizeof(GpuCurtainSpec), curtainSpecs.data());

    auto buildCompute = [&](const std::string& text, const char* entry) {
        wgpuDevicePushErrorScope(gpu.device, WGPUErrorFilter_Validation);
        WGPUShaderSourceWGSL code = {}; code.chain.sType = WGPUSType_ShaderSourceWGSL;
        code.code = wgpu::Device::str(text.c_str());
        WGPUShaderModuleDescriptor md = {}; md.nextInChain = &code.chain;
        auto module = wgpuDeviceCreateShaderModule(gpu.device, &md);
        WGPUComputePipelineDescriptor pd = {}; pd.compute.module = module;
        pd.compute.entryPoint = wgpu::Device::str(entry);
        auto pipeline = wgpuDeviceCreateComputePipeline(gpu.device, &pd);
        wgpuShaderModuleRelease(module);
        PopContext error;
        WGPUPopErrorScopeCallbackInfo cb = {}; cb.mode = WGPUCallbackMode_AllowProcessEvents;
        cb.callback = onPopError; cb.userdata1 = &error;
        wgpuDevicePopErrorScope(gpu.device, cb);
        while (!error.done) wgpuDevicePoll(gpu.device, true, nullptr);
        if (error.type != WGPUErrorType_NoError || !pipeline)
            throw std::runtime_error("compute pipeline creation failed");
        return pipeline;
    };

static const char* kFastPathFullShader = R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<storage,read> curtains:array<CurtainSpec,4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;
fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}
fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 // Bands describe uncertainty sets, not distinct roots. Merge only
 // intersecting/touching bands; never bridge an unrepresented gap.
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}
// The curvature/endpoint model is explicit. A bin must be monotone before
// bisection can resolve it. Exhaustion never becomes an isolated midpoint.

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}
fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  stack[0] = vec4f(a, b, phi_a0, phi_b0); setDepth(&depthBits, 0u, 0u); top = 1u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if ((va > error && vb < -error) || (va < -error && vb > error)) {
     var l = a; var r = b; var left = va;
     for (var iter = 0u; iter < 32u; iter++) {
      if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
      let mid = l + 0.5 * (r - l);
      if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
      let v = evalPhi(m, o, d, mid) - c;
      if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
      if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
     }
     putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
    }
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

@compute @workgroup_size(64)
fn producerFastMain(@builtin(global_invocation_id) gid: vec3u) {
 let id = gid.x; if (id >= cfg.rayCount) { return; }
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 4u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   // Reuse exactly the affine-knot arithmetic used when inserting knots above.
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
  var ne = 0u;
 var head = vec4u(0u);
 let totalKnots = (memCount.x + memCount.y + memCount.z + memCount.w) * 2u;
 loop {
  if (ne >= totalKnots) { break; }
  var bestM = 4u;
  var bestVal = 0.0;
  for (var m = 0u; m < 4u; m++) {
   let h = head[m];
   if (h < memCount[m] * 2u) {
    let pIdx = memStart[m] + (h >> 1u);
    let isY = (h & 1u) != 0u;
    let val = select(pieces[pIdx].x, pieces[pIdx].y, isY);
    if (bestM == 4u || val < bestVal) {
     bestVal = val;
     bestM = m;
    }
   }
  }
  knots[ne] = bestVal;
  ne++;
  head[bestM]++;
 }
 var singles = 0u; var overs = 0u;
 var pIdx = vec4u(0u);
 for (var i = 1u; i < ne && reason == 0u; i++) {
  let a = knots[i - 1u]; let b = knots[i]; if (!(b > a)) { continue; }
  let mid = a + 0.5 * (b - a);
  var mask = 0u;
  for (var m = 0u; m < 4u; m++) {
   let start = memStart[m];
   let numPieces = memCount[m];
   var cur = pIdx[m];
   loop {
    if (cur >= numPieces || pieces[start + cur].y >= mid) { break; }
    cur++;
   }
   pIdx[m] = cur;
   if (cur < numPieces) {
    let p = pieces[start + cur];
    if (mid >= p.x && mid <= p.y) {
     mask |= (1u << m);
    }
   }
  }
  if (mask == 0u) { continue; }
  if (countOneBits(mask) == 1u) {
   let n = max(1u, u32(ceil((b - a) / 4.0)));
   if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
   let member = firstTrailingBit(mask);
   for (var k = 0u; k < n; k++) {
    let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
    let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
    subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(member, 0)); singles++;
   }
  } else {
   if (overs >= cfg.maxOverPerRay) { reason |= 32u; break; }
   overlaps[overBase + overs] = Overlap(vec2f(a, b), vec2u(mask, 0)); overs++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, overs); }
}
)WGSL";

static const char* kFastPathCompactShader = R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<storage,read> curtains:array<CurtainSpec,4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;
fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}
fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 // Bands describe uncertainty sets, not distinct roots. Merge only
 // intersecting/touching bands; never bridge an unrepresented gap.
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}
// The curvature/endpoint model is explicit. A bin must be monotone before
// bisection can resolve it. Exhaustion never becomes an isolated midpoint.

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}
fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  // Exact existing level-specific depth0 predicate, before private stack use.
        if (*work >= cfg.budget) { *reason |= 1u; break; }
        let coarseH = b - a;
        if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
        let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
        let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
        let coarseArithmetic = 0.000001 * coarseScale;
        let coarseError = err + coarseArithmetic;
        let coarseBow = 0.125 * M * coarseH * coarseH + coarseError;
        if (min(coarseVa, coarseVb) > coarseBow || max(coarseVa, coarseVb) < -coarseBow) { *work += 1u; continue; }
        stack[0] = vec4f(a, b, phi_a0, phi_b0); setDepth(&depthBits, 0u, 0u); top = 1u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if ((va > error && vb < -error) || (va < -error && vb > error)) {
     var l = a; var r = b; var left = va;
     for (var iter = 0u; iter < 32u; iter++) {
      if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
      let mid = l + 0.5 * (r - l);
      if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
      let v = evalPhi(m, o, d, mid) - c;
      if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
      if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
     }
     putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
    }
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

@compute @workgroup_size(64)
fn producerFastMain(@builtin(global_invocation_id) gid: vec3u) {
 let id = gid.x; if (id >= cfg.rayCount) { return; }
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 4u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   // Reuse exactly the affine-knot arithmetic used when inserting knots above.
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
  var ne = 0u;
 var head = vec4u(0u);
 let totalKnots = (memCount.x + memCount.y + memCount.z + memCount.w) * 2u;
 loop {
  if (ne >= totalKnots) { break; }
  var bestM = 4u;
  var bestVal = 0.0;
  for (var m = 0u; m < 4u; m++) {
   let h = head[m];
   if (h < memCount[m] * 2u) {
    let pIdx = memStart[m] + (h >> 1u);
    let isY = (h & 1u) != 0u;
    let val = select(pieces[pIdx].x, pieces[pIdx].y, isY);
    if (bestM == 4u || val < bestVal) {
     bestVal = val;
     bestM = m;
    }
   }
  }
  knots[ne] = bestVal;
  ne++;
  head[bestM]++;
 }
 var singles = 0u; var overs = 0u;
 var pIdx = vec4u(0u);
 for (var i = 1u; i < ne && reason == 0u; i++) {
  let a = knots[i - 1u]; let b = knots[i]; if (!(b > a)) { continue; }
  let mid = a + 0.5 * (b - a);
  var mask = 0u;
  for (var m = 0u; m < 4u; m++) {
   let start = memStart[m];
   let numPieces = memCount[m];
   var cur = pIdx[m];
   loop {
    if (cur >= numPieces || pieces[start + cur].y >= mid) { break; }
    cur++;
   }
   pIdx[m] = cur;
   if (cur < numPieces) {
    let p = pieces[start + cur];
    if (mid >= p.x && mid <= p.y) {
     mask |= (1u << m);
    }
   }
  }
  if (mask == 0u) { continue; }
  if (countOneBits(mask) == 1u) {
   let n = max(1u, u32(ceil((b - a) / 4.0)));
   if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
   let member = firstTrailingBit(mask);
   for (var k = 0u; k < n; k++) {
    let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
    let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
    subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(member, 0)); singles++;
   }
  } else {
   if (overs >= cfg.maxOverPerRay) { reason |= 32u; break; }
   overlaps[overBase + overs] = Overlap(vec2f(a, b), vec2u(mask, 0)); overs++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, overs); }
}
)WGSL";

    auto cpProducer = buildCompute(kGpuProducerWgsl, "producerMain");
    auto cpFastFull = buildCompute(kFastPathFullShader, "producerFastMain");
    auto cpFastCompact = buildCompute(kFastPathCompactShader, "producerFastMain");
    // §6du True Terminal S1 & Mode 2 Frozen §6dr Routed Unfused Buffers & Pipelines
    auto offBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, tileOffsets.size() * sizeof(uint32_t), tileOffsets.data());
    auto idxBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, tileRayIndices.size() * sizeof(uint32_t), tileRayIndices.data());

    std::vector<uint32_t> initList(2304, 0u);
    auto s1TileBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, 2304 * sizeof(uint32_t), initList.data());
    auto s2TileBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, 2304 * sizeof(uint32_t), initList.data());
    auto fbTileBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, 2304 * sizeof(uint32_t), initList.data());

    struct alignas(16) DispatchCounters { uint32_t s1, s2, fb, pad; };
    DispatchCounters initCnt{0, 0, 0, 0};
    auto cntBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, sizeof(initCnt), &initCnt);
    auto argsBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_Indirect | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, 36, nullptr);

    decltype(cfg) forcedCfg = cfg;
    forcedCfg.pad = 0;
    auto forcedCfgBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_CopyDst, sizeof(forcedCfg), &forcedCfg);

    auto cpReset = buildCompute(kResetCountersWgsl, "resetCountersMain");
    auto cpClassify = buildCompute(kClassifyWgsl, "classifyTilesMain");
    auto cpArgs = buildCompute(kRouteArgsWgsl, "routeArgs");
    auto cpS1Unfused = buildCompute(kS1UnfusedProducerWgsl, "s1ProducerMain");
    auto cpS1Terminal = buildCompute(kS1TerminalProducerWgsl, "s1ProducerMain");
    auto cpS2 = buildCompute(kS2ProducerWgsl, "s2ProducerMain");
    auto cpFallback = buildCompute(kFallbackProducerWgsl, "fallbackProducerMain");

    auto makeEntry = [](uint32_t binding, WGPUBuffer buffer, uint64_t offset, uint64_t size) -> WGPUBindGroupEntry {
        WGPUBindGroupEntry e{};
        e.binding = binding; e.buffer = buffer; e.offset = offset; e.size = size;
        return e;
    };
    auto makeGroup = [&](WGPUComputePipeline cp, const std::vector<WGPUBindGroupEntry>& entries) -> WGPUBindGroup {
        auto layout = wgpuComputePipelineGetBindGroupLayout(cp, 0);
        WGPUBindGroupDescriptor d{};
        d.layout = layout;
        d.entryCount = entries.size();
        d.entries = entries.data();
        auto bg = wgpuDeviceCreateBindGroup(gpu.device, &d);
        wgpuBindGroupLayoutRelease(layout);
        if (!bg) throw std::runtime_error("bind group creation failed");
        return bg;
    };

    auto bgReset = makeGroup(cpReset, { makeEntry(0, cntBuf, 0, sizeof(initCnt)) });
    auto bgClassify = makeGroup(cpClassify, {
        makeEntry(0, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(1, rBuf, 0, rayBytes),
        makeEntry(2, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(3, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(4, s1TileBuf, 0, 2304 * 4),
        makeEntry(5, s2TileBuf, 0, 2304 * 4),
        makeEntry(6, fbTileBuf, 0, 2304 * 4),
        makeEntry(7, cntBuf, 0, sizeof(initCnt))
    });
    auto bgArgs = makeGroup(cpArgs, {
        makeEntry(0, cntBuf, 0, sizeof(initCnt)),
        makeEntry(1, argsBuf, 0, 36)
    });

    // Mode 2: Unfused S1 Producer Bind Groups (writes subpanels to sBuf)
    auto bgS1Unfused = makeGroup(cpS1Unfused, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s1TileBuf, 0, 2304 * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });
    auto bgS1UnfusedForced = makeGroup(cpS1Unfused, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s1TileBuf, 0, 2304 * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });

    // Mode 3: Terminal S1 Producer Bind Groups (evaluates quadrature in-producer, writes results[id])
    auto bgS1Terminal = makeGroup(cpS1Terminal, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(4, outBuf, 0, outBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s1TileBuf, 0, 2304 * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt)),
        makeEntry(9, mBuf, 0, mediaBytes),
        makeEntry(10, pBuf, 0, paramBytes)
    });
    auto bgS1TerminalForced = makeGroup(cpS1Terminal, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(4, outBuf, 0, outBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s1TileBuf, 0, 2304 * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt)),
        makeEntry(9, mBuf, 0, mediaBytes),
        makeEntry(10, pBuf, 0, paramBytes)
    });

    auto bgS2 = makeGroup(cpS2, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s2TileBuf, 0, 2304 * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });
    auto bgS2Forced = makeGroup(cpS2, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s2TileBuf, 0, 2304 * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });

    auto bgFallback = makeGroup(cpFallback, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(4, oBuf, 0, overlapBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, fbTileBuf, 0, 2304 * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });
    auto bgFallbackForced = makeGroup(cpFallback, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(4, oBuf, 0, overlapBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, fbTileBuf, 0, 2304 * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });


    WGPUBindGroupEntry bgpEntries[5] = {};
    bgpEntries[0].binding = 0; bgpEntries[0].buffer = cfgBuf; bgpEntries[0].size = sizeof(cfg);
    bgpEntries[1].binding = 1; bgpEntries[1].buffer = specBuf; bgpEntries[1].size = curtainSpecs.size() * sizeof(GpuCurtainSpec);
    bgpEntries[2].binding = 2; bgpEntries[2].buffer = rBuf; bgpEntries[2].size = rayBytes;
    bgpEntries[3].binding = 3; bgpEntries[3].buffer = sBuf; bgpEntries[3].size = subpanelBytes;
    bgpEntries[4].binding = 4; bgpEntries[4].buffer = oBuf; bgpEntries[4].size = overlapBytes;

    WGPUBindGroupDescriptor bgpd = {};
    bgpd.layout = wgpuComputePipelineGetBindGroupLayout(cpProducer, 0);
    bgpd.entryCount = 5;
    bgpd.entries = bgpEntries;
    WGPUBindGroup bgProducer = wgpuDeviceCreateBindGroup(gpu.device, &bgpd);

    // Initial dispatch of GPU producer to populate sBuf, oBuf, and rBuf
    {
        auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        auto pass = wgpuCommandEncoderBeginComputePass(enc, nullptr);
        wgpuComputePassEncoderSetPipeline(pass, cpProducer);
        wgpuComputePassEncoderSetBindGroup(pass, 0, bgProducer, 0, nullptr);
        wgpuComputePassEncoderDispatchWorkgroups(pass, (count + 63) / 64, 1, 1);
        wgpuComputePassEncoderEnd(pass);
        wgpuComputePassEncoderRelease(pass);
        auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuCommandEncoderRelease(enc);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device, true, nullptr);
    }

    // Read back GPU producer schedule to CPU for independent AST arithmetic comparison
    {
        auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        auto readSub = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, subpanelBytes, nullptr);
        auto readOver = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, overlapBytes, nullptr);
        auto readRay = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, rayBytes, nullptr);
        wgpuCommandEncoderCopyBufferToBuffer(enc, sBuf, 0, readSub, 0, subpanelBytes);
        wgpuCommandEncoderCopyBufferToBuffer(enc, oBuf, 0, readOver, 0, overlapBytes);
        wgpuCommandEncoderCopyBufferToBuffer(enc, rBuf, 0, readRay, 0, rayBytes);
        auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuCommandEncoderRelease(enc);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device, true, nullptr);

        MapContext mc1, mc2, mc3;
        WGPUBufferMapCallbackInfo mci1 = {}, mci2 = {}, mci3 = {};
        mci1.mode = WGPUCallbackMode_AllowProcessEvents; mci1.callback = onMapped; mci1.userdata1 = &mc1;
        mci2.mode = WGPUCallbackMode_AllowProcessEvents; mci2.callback = onMapped; mci2.userdata1 = &mc2;
        mci3.mode = WGPUCallbackMode_AllowProcessEvents; mci3.callback = onMapped; mci3.userdata1 = &mc3;

        wgpuBufferMapAsync(readRay, WGPUMapMode_Read, 0, rayBytes, mci1);
        wgpuBufferMapAsync(readSub, WGPUMapMode_Read, 0, subpanelBytes, mci2);
        wgpuBufferMapAsync(readOver, WGPUMapMode_Read, 0, overlapBytes, mci3);
        while (!mc1.done || !mc2.done || !mc3.done) wgpuDevicePoll(gpu.device, true, nullptr);
        if(!mc1.ok||!mc2.ok||!mc3.ok)throw std::runtime_error("producer readback mapping failed");

        auto* mappedRays = static_cast<const GpuRayHeader*>(wgpuBufferGetConstMappedRange(readRay, 0, rayBytes));
        auto* mappedSubs = static_cast<const GpuSubpanel*>(wgpuBufferGetConstMappedRange(readSub, 0, subpanelBytes));
        auto* mappedOvers = static_cast<const GpuOverlap*>(wgpuBufferGetConstMappedRange(readOver, 0, overlapBytes));

        gpuSubpanels.clear();
        gpuOverlaps.clear();
        maxSubpanelsPerRay = 0;

        for (size_t i = 0; i < count; ++i) {
            gpuRays[i].ro[0] = mappedRays[i].ro[0];
            gpuRays[i].ro[1] = mappedRays[i].ro[1];
            gpuRays[i].ro[2] = mappedRays[i].ro[2];
            gpuRays[i].clipA = mappedRays[i].clipA;
            gpuRays[i].rd[0] = mappedRays[i].rd[0];
            gpuRays[i].rd[1] = mappedRays[i].rd[1];
            gpuRays[i].rd[2] = mappedRays[i].rd[2];
            gpuRays[i].clipB = mappedRays[i].clipB;

            uint32_t sBase = mappedRays[i].subpanelOffset;

            producerFlags[i]=mappedRays[i].overlapCount;
            const bool refused=(producerFlags[i]&0x80000000u)!=0;
            uint32_t sCount = mappedRays[i].subpanelCount;
            if(refused&&sCount!=0)throw std::runtime_error("partial fallback schedule");

            uint32_t oBase = mappedRays[i].overlapOffset;

            uint32_t oCount = refused?0:mappedRays[i].overlapCount;
            if(sCount>maxSubPerRay||oCount>maxOverPerRay||sBase+sCount>totalSub||oBase+oCount>totalOver)
                throw std::runtime_error("producer output exceeds allocated bounds");


            gpuRays[i].subpanelOffset = gpuSubpanels.size();
            gpuRays[i].subpanelCount = sCount;
            gpuRays[i].overlapOffset = gpuOverlaps.size();
            gpuRays[i].overlapCount = oCount;
            maxSubpanelsPerRay = std::max(maxSubpanelsPerRay, sCount);

            for (uint32_t s = 0; s < sCount; ++s) {
                gpuSubpanels.push_back(mappedSubs[sBase + s]);
            }
            for (uint32_t o = 0; o < oCount; ++o) {
                gpuOverlaps.push_back(mappedOvers[oBase + o]);
            }
        }

        wgpuBufferUnmap(readRay);
        wgpuBufferUnmap(readSub);
        wgpuBufferUnmap(readOver);
        wgpuBufferRelease(readRay);
        wgpuBufferRelease(readSub);
        wgpuBufferRelease(readOver);

        std::cout << "Read back GPU Producer schedule to CPU:\n"
                  << "  Total Subpanels: " << gpuSubpanels.size() << " (max " << maxSubpanelsPerRay << "/ray)\n"
                  << "  Total Overlaps:  " << gpuOverlaps.size() << "\n";
    }


    uint32_t workgroups = (uint32_t(executionRays) + 63u) / 64u;



    if(!geometryCase.empty()){
        unsigned positiveChecks=0,fallbacks=0;
        const auto& spec=curtainSpecs[0];
        for(size_t i=0;i<count;++i){
            const auto& ray=gpuRays[i];bool refused=(producerFlags[i]&0x80000000u)!=0;fallbacks+=refused;
            auto check=[&](double t){
                const glm::dvec3 p=glm::dvec3(ray.ro[0],ray.ro[1],ray.ro[2])+t*glm::dvec3(ray.rd[0],ray.rd[1],ray.rd[2]);
                const double phi=p.z+double(spec.amps.x)*std::sin(double(spec.freqs.x)*p.x+spec.phases.x)+
                    double(spec.amps.y)*std::cos(double(spec.freqs.y)*p.x+spec.phases.y);
                if(std::abs(p.x)>=spec.limits.x||std::abs(p.y)>=spec.limits.y||std::abs(phi)>=spec.limits.w)return;
                ++positiveChecks;bool kept=refused;
                for(unsigned k=0;k<ray.subpanelCount;++k){const auto& q=gpuSubpanels[ray.subpanelOffset+k];kept=kept||(q.mediumIndex==0&&q.s0<=t&&q.s1>=t);}
                for(unsigned k=0;k<ray.overlapCount;++k){const auto& q=gpuOverlaps[ray.overlapOffset+k];kept=kept||((q.activeMask&1u)&&q.s0<=t&&q.s1>=t);}
                if(!kept)throw std::runtime_error("native geometry witness dropped positive support");
            };
            for(unsigned k=0;k<4096;++k)check(ray.clipA+(ray.clipB-ray.clipA)*(k+.5)/4096);
            if(geometryCase=="narrow-lobe"){check(.007-.00004);check(.007+.00004);}
        }
        if(!positiveChecks)throw std::runtime_error("geometry control never exercised positive support");
        if(geometryCase=="near-parallel"&&fallbacks==count)throw std::runtime_error("near-parallel unexpectedly all refused");
        J q={{"scope","Native producer geometry control only; no transport/accuracy/speed qualification"},
            {"case",geometryCase},{"rays",count},{"positive_support_checks",positiveChecks},{"fallback_rays",fallbacks},{"pass",true}};
        std::ofstream f(outputPath);f<<q.dump(2)<<"\n";std::cout<<q.dump(2)<<std::endl;return 0;
    }

    WGPUComputePipeline fallbackCP=nullptr;WGPUBindGroup fallbackBG=nullptr;
    auto runBatch=[&](WGPUComputePipeline cp,WGPUBindGroup bg,int n)->double {
        auto enc=wgpuDeviceCreateCommandEncoder(gpu.device,nullptr);
        auto pass=wgpuCommandEncoderBeginComputePass(enc,nullptr);
        wgpuComputePassEncoderSetPipeline(pass,cp);
        if(bg)wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);
        for(int k=0;k<n;++k){
            wgpuComputePassEncoderSetPipeline(pass,cp);
            if(bg)wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass,workgroups,1,1);
            if(fallbackCP&&(cp==cpUnfused||cp==cpFused)){
                wgpuComputePassEncoderSetPipeline(pass,fallbackCP);
                wgpuComputePassEncoderSetBindGroup(pass,0,fallbackBG,0,nullptr);
                wgpuComputePassEncoderDispatchWorkgroups(pass,workgroups,1,1);
            }
        }
        wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);
        auto cmd=wgpuCommandEncoderFinish(enc,nullptr);wgpuCommandEncoderRelease(enc);
        auto t0=std::chrono::steady_clock::now();wgpuQueueSubmit(gpu.queue,1,&cmd);wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device,true,nullptr);
        return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();
    };
    auto runPass=[&](WGPUComputePipeline cp,WGPUBindGroup bg){return runBatch(cp,bg,1);};

    auto runBatchConnected = [&](int n) -> double {
        auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        for (int k = 0; k < n; ++k) {
            auto pass1 = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(pass1, cpProducer);
            wgpuComputePassEncoderSetBindGroup(pass1, 0, bgProducer, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass1, (count + 63) / 64, 1, 1);
            wgpuComputePassEncoderEnd(pass1);
            wgpuComputePassEncoderRelease(pass1);

            auto pass2 = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(pass2, cpUnfused);
            wgpuComputePassEncoderSetBindGroup(pass2, 0, bgUnfused, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass2, (count + 63) / 64, 1, 1);
            wgpuComputePassEncoderEnd(pass2);
            wgpuComputePassEncoderRelease(pass2);
            auto pass3=wgpuCommandEncoderBeginComputePass(enc,nullptr);
            wgpuComputePassEncoderSetPipeline(pass3,fallbackCP);
            wgpuComputePassEncoderSetBindGroup(pass3,0,fallbackBG,0,nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass3,(count+63)/64,1,1);
            wgpuComputePassEncoderEnd(pass3);wgpuComputePassEncoderRelease(pass3);

        }
        auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuCommandEncoderRelease(enc);
        auto t0 = std::chrono::steady_clock::now();
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device, true, nullptr);
        return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    };

    // Helper for readback

    auto readBackBuffer = [&](WGPUBuffer src, uint64_t size) -> std::vector<uint8_t> {
        auto rb = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, size, nullptr);
        WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        wgpuCommandEncoderCopyBufferToBuffer(enc, src, 0, rb, 0, size);
        WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuCommandEncoderRelease(enc);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);

        MapContext mc;
        WGPUBufferMapCallbackInfo cbInfo = {};
        cbInfo.mode = WGPUCallbackMode_AllowProcessEvents;
        cbInfo.callback = onMapped;
        cbInfo.userdata1 = &mc;
        wgpuBufferMapAsync(rb, WGPUMapMode_Read, 0, size, cbInfo);
        while (!mc.done) wgpuDevicePoll(gpu.device, true, nullptr);
        if (!mc.ok) throw std::runtime_error("buffer mapping failed");

        const uint8_t* ptr = static_cast<const uint8_t*>(wgpuBufferGetConstMappedRange(rb, 0, size));
        std::vector<uint8_t> data(ptr, ptr + size);
        wgpuBufferUnmap(rb);
        wgpuBufferRelease(rb);
        return data;
    };

    auto readResults = [&]() -> std::vector<GpuResult> {
        WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        wgpuCommandEncoderCopyBufferToBuffer(enc, outBuf, 0, readBuf, 0, outBytes);
        WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuCommandEncoderRelease(enc);

        MapContext mc;
        WGPUBufferMapCallbackInfo mci = {};
        mci.mode = WGPUCallbackMode_AllowProcessEvents;
        mci.callback = onMapped;
        mci.userdata1 = &mc;
        wgpuBufferMapAsync(readBuf, WGPUMapMode_Read, 0, outBytes, mci);
        while (!mc.done) wgpuDevicePoll(gpu.device, true, nullptr);
        if(!mc.ok)throw std::runtime_error("result mapping failed");

        const auto* ptr = static_cast<const GpuResult*>(wgpuBufferGetConstMappedRange(readBuf, 0, outBytes));
        std::vector<GpuResult> res(ptr, ptr + executionRays);
        wgpuBufferUnmap(readBuf);
        return res;
    };

    // Warmup
    std::cout << "Warming up Metal GPU pipelines..." << std::endl;
    runPass(cpUnfused, bgUnfused);
    runPass(cpFused, bgFused);

    // Read back results for verification
    runPass(cpUnfused, bgUnfused);
    auto resUnfused = readResults();

    runPass(cpFused, bgFused);
    auto resFused = readResults();



    auto cuBuf=makeBuffer(WGPUBufferUsage_Uniform|WGPUBufferUsage_CopyDst,sizeof(currentU),&currentU);
    auto cparamsBuf=makeBuffer(WGPUBufferUsage_Storage|WGPUBufferUsage_CopyDst,currentParams.size()*4,currentParams.data());
    auto ciBuf=makeBuffer(WGPUBufferUsage_Storage|WGPUBufferUsage_CopyDst,currentInstances.size()*sizeof(CurrentInstance),currentInstances.data());
    auto buildRaw=[&](const std::string& text,const char* entry) {
        wgpuDevicePushErrorScope(gpu.device,WGPUErrorFilter_Validation);
        WGPUShaderSourceWGSL code={};code.chain.sType=WGPUSType_ShaderSourceWGSL;code.code=wgpu::Device::str(text.c_str());
        WGPUShaderModuleDescriptor md={};md.nextInChain=&code.chain;auto module=wgpuDeviceCreateShaderModule(gpu.device,&md);
        WGPUComputePipelineDescriptor pd={};pd.compute.module=module;pd.compute.entryPoint=wgpu::Device::str(entry);
        auto pipeline=wgpuDeviceCreateComputePipeline(gpu.device,&pd);wgpuShaderModuleRelease(module);
        PopContext error;WGPUPopErrorScopeCallbackInfo cb={};cb.mode=WGPUCallbackMode_AllowProcessEvents;cb.callback=onPopError;cb.userdata1=&error;
        wgpuDevicePopErrorScope(gpu.device,cb);while(!error.done)wgpuDevicePoll(gpu.device,true,nullptr);
        if(error.type!=WGPUErrorType_NoError||!pipeline)throw std::runtime_error("production compute pipeline validation failed");
        return pipeline;
    };
    auto currentCP=buildRaw(currentShader,"rayMain"),prepCP=buildRaw(prepShader,"volumeTimePrepare");
    auto bindCurrent=[&](WGPUComputePipeline cp) {
        WGPUBindGroupEntry entries[5]={};
        WGPUBuffer buffers[5]={cuBuf,cparamsBuf,ciBuf,rBuf,outBuf};
        uint64_t sizes[5]={sizeof(currentU),currentParams.size()*4,currentInstances.size()*sizeof(CurrentInstance),rayBytes,outBytes};
        for(uint32_t k=0;k<5;++k){entries[k].binding=k;entries[k].buffer=buffers[k];entries[k].size=sizes[k];}
        auto layout=wgpuComputePipelineGetBindGroupLayout(cp,0);WGPUBindGroupDescriptor d={};d.layout=layout;d.entryCount=5;d.entries=entries;
        auto bg=wgpuDeviceCreateBindGroup(gpu.device,&d);wgpuBindGroupLayoutRelease(layout);return bg;
    };
    auto currentBG=bindCurrent(currentCP),prepBG=bindCurrent(prepCP);
    std::string fallbackShader=currentShader;
    const std::string rayHook=" let ray=capturedRays[idx%arrayLength(&capturedRays)];";
    auto where=fallbackShader.find(rayHook);if(where==std::string::npos)throw std::runtime_error("fallback ray hook");
    fallbackShader.insert(where+rayHook.size(),"\n if((ray.counts.w & 0x80000000u)==0u){return;}\n");
    fallbackCP=buildRaw(fallbackShader,"rayMain");fallbackBG=bindCurrent(fallbackCP);

    {
        auto enc=wgpuDeviceCreateCommandEncoder(gpu.device,nullptr);auto pass=wgpuCommandEncoderBeginComputePass(enc,nullptr);
        wgpuComputePassEncoderSetPipeline(pass,prepCP);wgpuComputePassEncoderSetBindGroup(pass,0,prepBG,0,nullptr);
        wgpuComputePassEncoderDispatchWorkgroups(pass,media.size(),1,1);wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);
        auto cmd=wgpuCommandEncoderFinish(enc,nullptr);wgpuCommandEncoderRelease(enc);wgpuQueueSubmit(gpu.queue,1,&cmd);wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device,true,nullptr);
    }
    runPass(currentCP,currentBG);auto resCurrent=readResults();
    double currentDeltaRGB=0,currentDeltaT=0;
    for(size_t i=0;i<count;++i) {
        currentDeltaT=std::max(currentDeltaT,std::abs(double(resCurrent[i].rgb_T[3])-R[i][7].get<double>()));
        for(int k=0;k<3;++k)currentDeltaRGB=std::max(currentDeltaRGB,std::abs(double(resCurrent[i].rgb_T[k])-R[i][8+k].get<double>()));
    }
    std::cout<<"CURRENT stored-native agreement RGB="<<currentDeltaRGB<<" T="<<currentDeltaT<<" trim="<<trim<<std::endl;
    if(!outputPath.empty()) {J a=J::array();for(size_t i=0;i<count;++i)a.push_back({R[i][0],R[i][1],resCurrent[i].rgb_T[0],resCurrent[i].rgb_T[1],resCurrent[i].rgb_T[2],resCurrent[i].rgb_T[3]});std::ofstream f(outputPath+"-baseline-rows.json");f<<a;}
    if(currentDeltaRGB>1e-5||currentDeltaT>1e-5)throw std::runtime_error("baseline does not reproduce recorded native; timing refused");
    for(size_t i=count;i<executionRays;++i)for(int k=0;k<4;++k)
        if(resCurrent[i].rgb_T[k]!=resCurrent[i%count].rgb_T[k]||resUnfused[i].rgb_T[k]!=resUnfused[i%count].rgb_T[k])throw std::runtime_error("replicated output mismatch");


    runPass(cpUnfused,bgUnfused);resUnfused=readResults();
    runPass(cpFused,bgFused);resFused=readResults();

    std::vector<double> timesUnfused,timesFused;
    J batchSeries=J::array();
    auto cpEmpty=buildPipeline("@compute @workgroup_size(64) fn rayMain() {}\n");
    if(!cpEmpty)throw std::runtime_error("empty pipeline failed");
    for(int n: (repeatFactor==1?std::vector<int>{1,2,4}:std::vector<int>{1,2,4})) {
        for(int k=0;k<4;++k){runBatch(currentCP,currentBG,n);runBatch(cpUnfused,bgUnfused,n);}
        std::vector<double> A,B,C,E;
        for(int block=0;block<6;++block) {
            A.push_back(runBatch(currentCP,currentBG,n));
            B.push_back(runBatch(cpUnfused,bgUnfused,n));
            C.push_back(runBatchConnected(n));
            C.push_back(runBatchConnected(n));
            B.push_back(runBatch(cpUnfused,bgUnfused,n));
            A.push_back(runBatch(currentCP,currentBG,n));
            E.push_back(runBatch(cpEmpty,nullptr,n));
        }
        if(n==(repeatFactor==1?4:4)){for(double x:A)timesUnfused.push_back(x/n);for(double x:B)timesFused.push_back(x/n);}
        batchSeries.push_back({{"dispatches_per_fence",n},{"current_batch_ms",stats(A)},{"consumer_only_batch_ms",stats(B)},{"connected_batch_ms",stats(C)},
            {"empty_batch_ms",stats(E)},{"speedup_connected",stats(A)["mean"].get<double>()/stats(C)["mean"].get<double>()}});
        std::cout<<"BATCH "<<n<<" Current="<<stats(A)["mean"]<<"ms, Connected(Producer+Consumer)="<<stats(C)["mean"]<<"ms, Speedup="<<stats(A)["mean"].get<double>()/stats(C)["mean"].get<double>()<<"x"<<std::endl;
    }
    wgpuComputePipelineRelease(cpEmpty);

    J connected;
    {
        // Combined Connected GPU Producer + A* Consumer Pass
        auto connectedPass = [&]() -> double {
            auto t0 = std::chrono::steady_clock::now();
            auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);

            // Pass 1: GPU Canonical Producer
            auto pass1 = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(pass1, cpProducer);
            wgpuComputePassEncoderSetBindGroup(pass1, 0, bgProducer, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass1, (count + 63) / 64, 1, 1);
            wgpuComputePassEncoderEnd(pass1);
            wgpuComputePassEncoderRelease(pass1);

            // Pass 2: Complete Ordered A* Consumer
            auto pass2 = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(pass2, cpUnfused);
            wgpuComputePassEncoderSetBindGroup(pass2, 0, bgUnfused, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass2, (count + 63) / 64, 1, 1);
            wgpuComputePassEncoderEnd(pass2);
            wgpuComputePassEncoderRelease(pass2);
            auto pass3=wgpuCommandEncoderBeginComputePass(enc,nullptr);
            wgpuComputePassEncoderSetPipeline(pass3,fallbackCP);
            wgpuComputePassEncoderSetBindGroup(pass3,0,fallbackBG,0,nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass3,(count+63)/64,1,1);
            wgpuComputePassEncoderEnd(pass3);wgpuComputePassEncoderRelease(pass3);


            auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
            wgpuCommandEncoderRelease(enc);
            wgpuQueueSubmit(gpu.queue, 1, &cmd);
            wgpuCommandBufferRelease(cmd);
            wgpuDevicePoll(gpu.device, true, nullptr);
            return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        };

        // Standalone Producer Pass
        auto producerOnlyPass = [&]() -> double {
            auto t0 = std::chrono::steady_clock::now();
            auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
            auto pass1 = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(pass1, cpProducer);
            wgpuComputePassEncoderSetBindGroup(pass1, 0, bgProducer, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass1, (count + 63) / 64, 1, 1);
            wgpuComputePassEncoderEnd(pass1);
            wgpuComputePassEncoderRelease(pass1);
            auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
            wgpuCommandEncoderRelease(enc);
            wgpuQueueSubmit(gpu.queue, 1, &cmd);
            wgpuCommandBufferRelease(cmd);
            wgpuDevicePoll(gpu.device, true, nullptr);
            return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        };

        // Warmup
        connectedPass();
        runPass(currentCP, currentBG);

        // ABBA Benchmark: Current Resident Marcher vs Connected GPU (Producer + Consumer)
        std::vector<double> c, a, p;
        for (int block = 0; block < 8; ++block) {
            c.push_back(runPass(currentCP, currentBG));
            a.push_back(connectedPass());
            a.push_back(connectedPass());
            c.push_back(runPass(currentCP, currentBG));
            p.push_back(producerOnlyPass());
        }

        connected = {
            {"scope", "Same 2304 frozen rays; warmed stable scene/buffers; GPU Canonical Producer + A* Consumer chained in single command buffer versus resident production marcher"},
            {"current_host_ms", stats(c)},
            {"connected_gpu_ms", stats(a)},
            {"producer_only_gpu_ms", stats(p)},
            {"samples_current_ms", c},
            {"samples_connected_ms", a},
            {"samples_producer_ms", p},
            {"speedup_factor", stats(c)["mean"].get<double>() / stats(a)["mean"].get<double>()},
            {"actual_full_viewport", false},
            {"zero_host_schedule_cpu_ms", true},
            {"zero_host_schedule_upload_bytes", true}
        };


        // Re-execute connected pass and verify output stability
        std::vector<GpuResult> poisoned(count);
        for(auto& q:poisoned)for(float& v:q.rgb_T)v=NAN;
        wgpuQueueWriteBuffer(gpu.queue,outBuf,0,poisoned.data(),outBytes);
        connectedPass();
        auto connectedRes = readResults();
        for(const auto& q:connectedRes)for(float v:q.rgb_T)if(!std::isfinite(v))throw std::runtime_error("connected output was not fully written");
        resUnfused = connectedRes;
    }

    // Arithmetic fidelity comparison (Fused vs Unfused on device)
    double maxDeltaRGB_dev = 0.0;
    double maxDeltaT_dev = 0.0;
    for (size_t i = 0; i < count; ++i) {
        double dR = std::abs(resFused[i].rgb_T[0] - resUnfused[i].rgb_T[0]);
        double dG = std::abs(resFused[i].rgb_T[1] - resUnfused[i].rgb_T[1]);
        double dB = std::abs(resFused[i].rgb_T[2] - resUnfused[i].rgb_T[2]);
        double dT = std::abs(resFused[i].rgb_T[3] - resUnfused[i].rgb_T[3]);
        maxDeltaRGB_dev = std::max({maxDeltaRGB_dev, dR, dG, dB});
        maxDeltaT_dev = std::max(maxDeltaT_dev, dT);
    }


    // Independently evaluate the original authored AST at native f32 coordinates.
    std::vector<GpuResult> resCPU(count);
    long long cpuSingles=0,cpuOverlaps=0,cpuOverlapMemberSites=0,cpuBaselineFallbacks=0;
    auto astAt=[&](glm::vec3 ro,glm::vec3 rd,float t,uint32_t mask)->glm::vec4 {
        glm::vec4 value(0.0f); const glm::vec3 world=ro+t*rd;
        for(size_t id=0;id<media.size();++id) {
            if(!(mask&(1u<<id)))continue;
            const auto& m=media[id]; const glm::vec3 p=world-glm::vec3(m.origin);
            if(glm::any(glm::greaterThan(glm::abs(glm::dvec3(p)),m.half)))continue;
            const std::map<std::string,PropertyValue> vars{{"p",PropertyValue(p)},
                {"x",PropertyValue(double(p.x))},{"y",PropertyValue(double(p.y))},{"z",PropertyValue(double(p.z))},
                {OntoMath::kTimeVar,PropertyValue(clock)},
                {OntoMath::kOmegaXVar,PropertyValue(double(-rd.x))},
                {OntoMath::kOmegaYVar,PropertyValue(double(-rd.y))},
                {OntoMath::kOmegaZVar,PropertyValue(double(-rd.z))}};
            double D=0,X=0;
            auto v=m.density->evaluate(vars);
            if(!v||!propertyValueToNumber(*v,D))throw std::runtime_error("AST density refusal");
            if(!(D>0))continue;
            v=m.sigma->evaluate(vars);
            if(!v||!propertyValueToNumber(*v,X))throw std::runtime_error("AST extinction refusal");
            v=m.emission->evaluate(vars);
            if(!v||!std::holds_alternative<glm::vec3>(*v))throw std::runtime_error("AST emission refusal");
            const auto E=glm::max(std::get<glm::vec3>(*v),glm::vec3(0));
            value+=glm::vec4(E,float(std::max(X,1e-6)));
        }
        return value;
    };
    auto cpuFlow=[](glm::vec4 state,glm::vec4 q,float h) {
        const float tau=h*q.w,att=std::exp(-tau);
        const float gain=tau==0?h:h*(-std::expm1(-tau)/tau);
        return glm::vec4(glm::vec3(state)+state.w*glm::vec3(q)*gain,state.w*att);
    };
    auto tCpu0=std::chrono::steady_clock::now();

    for(size_t rayIdx=0;rayIdx<count;++rayIdx) {
        if((producerFlags[rayIdx]&0x80000000u)!=0){
            for(int k=0;k<4;++k)if(std::bit_cast<uint32_t>(resUnfused[rayIdx].rgb_T[k])!=std::bit_cast<uint32_t>(resCurrent[rayIdx].rgb_T[k]))throw std::runtime_error("fallback differs from native baseline");
            resCPU[rayIdx]=resCurrent[rayIdx];++cpuBaselineFallbacks;continue;
        }

        const auto& r=gpuRays[rayIdx]; const glm::vec3 ro(r.ro[0],r.ro[1],r.ro[2]),rd(r.rd[0],r.rd[1],r.rd[2]);
        glm::vec4 state(0,0,0,1);uint32_t si=0,oi=0;float last=-INFINITY;
        while(si<r.subpanelCount||oi<r.overlapCount) {
            const bool overlap=oi<r.overlapCount && (si>=r.subpanelCount || gpuOverlaps[r.overlapOffset+oi].s0<gpuSubpanels[r.subpanelOffset+si].s0);
            if(overlap) {
                const auto& o=gpuOverlaps[r.overlapOffset+oi++];
                if(o.s0<last)throw std::runtime_error("overlap schedule is not chronological");last=o.s1;++cpuOverlaps;
                const float h=(o.s1-o.s0)*.5f,a=.25f-std::sqrt(3.f)/6.f,b=.5f-a;
                for(int k=0;k<2;++k) {
                    const float lo=o.s0+k*h;
                    const auto u=astAt(ro,rd,lo+(.5f-std::sqrt(3.f)/6.f)*h,o.activeMask),v=astAt(ro,rd,lo+(.5f+std::sqrt(3.f)/6.f)*h,o.activeMask);
                    state=cpuFlow(state,b*u+a*v,h);state=cpuFlow(state,a*u+b*v,h);
                    cpuOverlapMemberSites+=2*__builtin_popcount(o.activeMask);
                }
            } else {
                const auto& p=gpuSubpanels[r.subpanelOffset+si++];
                if(p.s0<last)throw std::runtime_error("single schedule is not chronological");last=p.s1;++cpuSingles;
                const float h=p.s1-p.s0;
                const auto u=astAt(ro,rd,p.s0+(.5f-std::sqrt(3.f)/6.f)*h,1u<<p.mediumIndex),v=astAt(ro,rd,p.s0+(.5f+std::sqrt(3.f)/6.f)*h,1u<<p.mediumIndex);
                state=cpuFlow(state,.5f*(u+v),h);
            }
        }
        resCPU[rayIdx]=GpuResult{state.x,state.y,state.z,state.w};
    }
    if(size_t(cpuSingles)!=gpuSubpanels.size()||size_t(cpuOverlaps)!=gpuOverlaps.size())throw std::runtime_error("schedule coverage mismatch");
    auto tCpu1=std::chrono::steady_clock::now();
    double cpuQuadratureMs=std::chrono::duration<double,std::milli>(tCpu1-tCpu0).count();
    double maxDeltaRGB_CPU_vs_GPU = 0.0;
    double maxDeltaT_CPU_vs_GPU = 0.0;
    for (size_t i = 0; i < count; ++i) {
        double dR = std::abs(resCPU[i].rgb_T[0] - resUnfused[i].rgb_T[0]);
        double dG = std::abs(resCPU[i].rgb_T[1] - resUnfused[i].rgb_T[1]);
        double dB = std::abs(resCPU[i].rgb_T[2] - resUnfused[i].rgb_T[2]);
        double dT = std::abs(resCPU[i].rgb_T[3] - resUnfused[i].rgb_T[3]);
        maxDeltaRGB_CPU_vs_GPU = std::max({maxDeltaRGB_CPU_vs_GPU, dR, dG, dB});
        maxDeltaT_CPU_vs_GPU = std::max(maxDeltaT_CPU_vs_GPU, dT);
    }

    // Reference error evaluation vs ROWS.json (65,536-step Simpson)
    std::vector<double> errRGB_channel_fused, errRGB_ray_fused, errT_fused;
    std::vector<double> errRGB_channel_native, errRGB_ray_native, errT_native;

    long long aStarWorseThanNat_RGB = 0, aStarWorseThanNat_T = 0;
    double aStarMaxDeltaNat_RGB = 0.0, aStarMaxDeltaNat_T = 0.0;

    for (size_t referenceIndex = 0; referenceIndex < Rows.size(); ++referenceIndex) {
        const size_t i=ref.at("ray_indices")[referenceIndex].get<size_t>();
        const auto& truth = Rows[referenceIndex];
        double trueT = truth[2].get<double>();
        glm::dvec3 trueRGB(truth[3].get<double>(), truth[4].get<double>(), truth[5].get<double>());

        const auto& r = R[i];
        double TNative = r[7];
        glm::dvec3 LNative(r[8], r[9], r[10]);

        double errR_nat = std::abs(LNative.x - trueRGB.x);
        double errG_nat = std::abs(LNative.y - trueRGB.y);
        double errB_nat = std::abs(LNative.z - trueRGB.z);
        double errT_nat = std::abs(TNative - trueT);
        double errRay_nat = std::max({errR_nat, errG_nat, errB_nat});

        errRGB_channel_native.push_back(errR_nat);
        errRGB_channel_native.push_back(errG_nat);
        errRGB_channel_native.push_back(errB_nat);
        errRGB_ray_native.push_back(errRay_nat);
        errT_native.push_back(errT_nat);

        double errR_dev = std::abs(resUnfused[i].rgb_T[0] - trueRGB.x);
        double errG_dev = std::abs(resUnfused[i].rgb_T[1] - trueRGB.y);
        double errB_dev = std::abs(resUnfused[i].rgb_T[2] - trueRGB.z);
        double errT_dev = std::abs(resUnfused[i].rgb_T[3] - trueT);
        double errRay_dev = std::max({errR_dev, errG_dev, errB_dev});

        errRGB_channel_fused.push_back(errR_dev);
        errRGB_channel_fused.push_back(errG_dev);
        errRGB_channel_fused.push_back(errB_dev);
        errRGB_ray_fused.push_back(errRay_dev);
        errT_fused.push_back(errT_dev);

        double dRGB = errRay_dev - errRay_nat;
        if (dRGB > 1e-12) { ++aStarWorseThanNat_RGB; aStarMaxDeltaNat_RGB = std::max(aStarMaxDeltaNat_RGB, dRGB); }
        double dT = errT_dev - errT_nat;
        if (dT > 1e-12) { ++aStarWorseThanNat_T; aStarMaxDeltaNat_T = std::max(aStarMaxDeltaNat_T, dT); }
    }

    double meanUnfusedMs = stats(timesUnfused)["mean"].get<double>();
    double meanFusedMs = stats(timesFused)["mean"].get<double>();
    double speedup = meanUnfusedMs / meanFusedMs;

    J report;
    report["scope"] = "Northern Veil — Lane A Bounded Consumer-Only Metal Ceiling Diagnostic";
    report["platform"] = "Apple Silicon M5 (Metal / WebGPU)";
    report["rays"] = count;
    report["workload_accounting"] = {
        {"ray_headers_bytes", rayBytes},
        {"subpanels_count", gpuSubpanels.size()},
        {"subpanels_bytes", subpanelBytes},
        {"max_subpanels_per_ray", maxSubpanelsPerRay},
        {"overlaps_count", gpuOverlaps.size()},
        {"overlaps_bytes", overlapBytes},
        {"media_bytes", mediaBytes},
        {"params_bytes", paramBytes},
        {"total_schedule_bytes", totalScheduleBytes},
        {"total_schedule_kb", totalScheduleBytes / 1024.0}
    };

    report["fusion_isolation_benchmark"] = {
        {"unfused_ms", stats(timesUnfused)},
        {"fused_ms", stats(timesFused)},
        {"mean_unfused_ms", meanUnfusedMs},
        {"mean_fused_ms", meanFusedMs},
        {"speedup_factor", speedup},
        {"speedup_pct", (speedup - 1.0) * 100.0},
        {"microkernel_us_per_ray_unfused", (meanUnfusedMs * 1000.0) / count},
        {"microkernel_us_per_ray_fused", (meanFusedMs * 1000.0) / count}
    };

    report["device_arithmetic_fidelity"] = {
        {"max_delta_RGB_between_fused_and_unfused", maxDeltaRGB_dev},
        {"max_delta_T_between_fused_and_unfused", maxDeltaT_dev},
        {"arithmetic_identical_within_f32_eps", (maxDeltaRGB_dev < 1e-5 && maxDeltaT_dev < 1e-5)}
    };

    report["cpu_vs_gpu_arithmetic_deviation"] = {
        {"max_delta_RGB", maxDeltaRGB_CPU_vs_GPU},
        {"max_delta_T", maxDeltaT_CPU_vs_GPU},
        {"within_1e-5_tolerance", (maxDeltaRGB_CPU_vs_GPU < 1e-5 && maxDeltaT_CPU_vs_GPU < 1e-5)},
        {"cpu_quadrature_ms", cpuQuadratureMs},
        {"cpu_us_per_ray", (cpuQuadratureMs * 1000.0) / count}
    };

    report["accuracy_vs_independent_reference"] = {
        {"unfused_A_star_on_device", {
            {"RGB_pooled_channels", stats(errRGB_channel_fused)},
            {"RGB_max_per_ray", stats(errRGB_ray_fused)},
            {"T", stats(errT_fused)}
        }},
        {"native_baseline", {
            {"RGB_pooled_channels", stats(errRGB_channel_native)},
            {"RGB_max_per_ray", stats(errRGB_ray_native)},
            {"T", stats(errT_native)}
        }}
    };

    report["regressions_vs_native"] = {
        {"RGB_worse_rays", aStarWorseThanNat_RGB},
        {"RGB_worse_pct", double(aStarWorseThanNat_RGB) * 100.0 / count},
        {"RGB_max_delta", aStarMaxDeltaNat_RGB},
        {"T_worse_rays", aStarWorseThanNat_T},
        {"T_worse_pct", double(aStarWorseThanNat_T) * 100.0 / count},
        {"T_max_delta", aStarMaxDeltaNat_T}
    };




    // Bounded schedule storage only. Frozen input/output buffers still span the
    // finite query; full viewport ray generation/depth/composition is future work.

    // Inspect the ORIGINAL complete GPU schedule, including all overlap members.
    // Do not assume a periodic authored fold intersects a ray in one span.
    J spanExamples=J::array(),spanHistogram=J::object(),scheduleCensusInputs=J::array();unsigned multiSpanPairs=0,maxSpans=0;
    for(size_t i=0;i<count;++i){
        std::array<std::vector<glm::vec2>,4> spans;const auto& ray=gpuRays[i];
        J rawSingles=J::array(),rawOverlaps=J::array();
        if(producerFlags[i]&0x80000000u){scheduleCensusInputs.push_back({R[i][0],R[i][1],producerFlags[i],rawSingles,rawOverlaps});continue;}
        for(unsigned k=0;k<ray.subpanelCount;++k){const auto& p=gpuSubpanels[ray.subpanelOffset+k];spans[p.mediumIndex].push_back({p.s0,p.s1});rawSingles.push_back({p.s0,p.s1,p.mediumIndex});}
        for(unsigned k=0;k<ray.overlapCount;++k){const auto& p=gpuOverlaps[ray.overlapOffset+k];for(unsigned m=0;m<4;++m)if(p.activeMask&(1u<<m))spans[m].push_back({p.s0,p.s1});rawOverlaps.push_back({p.s0,p.s1,p.activeMask});}
        scheduleCensusInputs.push_back({R[i][0],R[i][1],producerFlags[i],rawSingles,rawOverlaps});
        for(unsigned m=0;m<4;++m){
            auto& v=spans[m];std::sort(v.begin(),v.end(),[](auto a,auto b){return a.x<b.x||(a.x==b.x&&a.y<b.y);});
            std::vector<glm::vec2> merged;
            for(auto p:v){if(!merged.empty()&&p.x<=merged.back().y)merged.back().y=std::max(merged.back().y,p.y);else merged.push_back(p);}
            const unsigned n=merged.size();maxSpans=std::max(maxSpans,n);
            auto key=std::to_string(n);spanHistogram[key]=spanHistogram.value(key,0u)+1u;
            if(n>1){++multiSpanPairs;if(spanExamples.size()<8){J intervals=J::array();for(auto p:merged)intervals.push_back({p.x,p.y});
                spanExamples.push_back({{"pixel",{R[i][0],R[i][1]}},{"member",m},{"retained_disjoint_intervals",intervals}});}}
        }
    }
    report["schedule_census_inputs"]=scheduleCensusInputs;
    report["single_span_compression_preflight"]={{"ray_member_pairs",count*4},{"pairs_with_multiple_retained_spans",multiSpanPairs},
        {"maximum_retained_spans_per_member",maxSpans},{"span_count_histogram",spanHistogram},{"examples",spanExamples},
        {"merged_only_touching_or_overlapping",true},{"source_or_omission_authority",false}};
    J streamingCases=J::array();
    for(uint32_t capacity:{65536u}){
        auto setupBegin=std::chrono::steady_clock::now();
        const uint64_t tileSingleBytes=uint64_t(capacity)*maxSubPerRay*sizeof(GpuSubpanel);
        const uint64_t tileOverlapBytes=uint64_t(capacity)*maxOverPerRay*sizeof(GpuOverlap);
        auto tileSingles=makeBuffer(WGPUBufferUsage_Storage,tileSingleBytes,nullptr);
        auto tileOverlaps=makeBuffer(WGPUBufferUsage_Storage,tileOverlapBytes,nullptr);
        struct Tile {uint32_t start,n;WGPUBindGroup producer,forced,consumer,fallback,fastFull,forcedFastFull,fastCompact,forcedFastCompact;};
        std::vector<Tile> tiles;std::vector<WGPUBuffer> tileUniforms;
        auto group=[&](WGPUComputePipeline cp,std::vector<WGPUBindGroupEntry> entries){
            auto layout=wgpuComputePipelineGetBindGroupLayout(cp,0);
            WGPUBindGroupDescriptor d={};d.layout=layout;d.entryCount=entries.size();d.entries=entries.data();
            auto bg=wgpuDeviceCreateBindGroup(gpu.device,&d);wgpuBindGroupLayoutRelease(layout);
            if(!bg)throw std::runtime_error("stream bind group refused");return bg;
        };
        auto entry=[](uint32_t binding,WGPUBuffer buffer,uint64_t offset,uint64_t size){
            WGPUBindGroupEntry e={};e.binding=binding;e.buffer=buffer;e.offset=offset;e.size=size;return e;
        };
        for(uint32_t start=0;start<count;start+=capacity){
            const uint32_t n=std::min(capacity,uint32_t(count)-start);
            const uint64_t rayOffset=uint64_t(start)*sizeof(GpuRayHeader),outputOffset=uint64_t(start)*sizeof(GpuResult);
            // Dawn's storage alignment is 256 here; fail rather than misbind.
            if(rayOffset%256||outputOffset%256)throw std::runtime_error("unaligned stream storage offset");
            auto u=udata;u.rayCount=n;auto pcfg=cfg;pcfg.rayCount=n;auto fcfg=pcfg;fcfg.pad=0;
            auto cu=currentU;cu.viewport.z=float(n);
            auto ub=makeBuffer(WGPUBufferUsage_Uniform|WGPUBufferUsage_CopyDst,sizeof(u),&u);
            auto cb=makeBuffer(WGPUBufferUsage_Uniform|WGPUBufferUsage_CopyDst,sizeof(pcfg),&pcfg);
            auto fb=makeBuffer(WGPUBufferUsage_Uniform|WGPUBufferUsage_CopyDst,sizeof(fcfg),&fcfg);
            auto cub=makeBuffer(WGPUBufferUsage_Uniform|WGPUBufferUsage_CopyDst,sizeof(cu),&cu);
            tileUniforms.insert(tileUniforms.end(),{ub,cb,fb,cub});
            auto producer=[&](WGPUBuffer configuration){return group(cpProducer,{
                entry(0,configuration,0,sizeof(pcfg)),entry(1,specBuf,0,curtainSpecs.size()*sizeof(GpuCurtainSpec)),
                entry(2,rBuf,rayOffset,uint64_t(n)*sizeof(GpuRayHeader)),entry(3,tileSingles,0,tileSingleBytes),entry(4,tileOverlaps,0,tileOverlapBytes)});};
            auto consumer=group(cpUnfused,{entry(0,ub,0,sizeof(u)),entry(1,mBuf,0,mediaBytes),entry(2,pBuf,0,paramBytes),
                entry(3,rBuf,rayOffset,uint64_t(n)*sizeof(GpuRayHeader)),entry(4,tileSingles,0,tileSingleBytes),
                entry(5,tileOverlaps,0,tileOverlapBytes),entry(6,outBuf,outputOffset,uint64_t(n)*sizeof(GpuResult))});
            auto current=[&](WGPUComputePipeline cp){return group(cp,{entry(0,cub,0,sizeof(cu)),entry(1,cparamsBuf,0,currentParams.size()*4),
                entry(2,ciBuf,0,currentInstances.size()*sizeof(CurrentInstance)),entry(3,rBuf,rayOffset,uint64_t(n)*sizeof(GpuRayHeader)),
                entry(4,outBuf,outputOffset,uint64_t(n)*sizeof(GpuResult))});};
            auto prodGroup=[&](WGPUComputePipeline cp, WGPUBuffer configuration){return group(cp,{
                entry(0,configuration,0,sizeof(pcfg)),entry(1,specBuf,0,curtainSpecs.size()*sizeof(GpuCurtainSpec)),
                entry(2,rBuf,rayOffset,uint64_t(n)*sizeof(GpuRayHeader)),entry(3,tileSingles,0,tileSingleBytes),entry(4,tileOverlaps,0,tileOverlapBytes)});};
            tiles.push_back({start,n,producer(cb),producer(fb),consumer,current(fallbackCP),
                prodGroup(cpFastFull,cb),prodGroup(cpFastFull,fb),
                prodGroup(cpFastCompact,cb),prodGroup(cpFastCompact,fb)});
        }
        const double setupMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-setupBegin).count();
        // mode 0 current marcher, 1 retained bulk connected, 2 streamed connected.
        // Both command encoding and submit-to-completion are separately observed.
        auto execute=[&](int mode,int repeats,bool forced){
            auto begin=std::chrono::steady_clock::now();auto enc=wgpuDeviceCreateCommandEncoder(gpu.device,nullptr);
            auto dispatch=[&](WGPUComputePipeline cp,WGPUBindGroup bg,uint32_t n){
                auto pass=wgpuCommandEncoderBeginComputePass(enc,nullptr);
                wgpuComputePassEncoderSetPipeline(pass,cp);wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);
                wgpuComputePassEncoderDispatchWorkgroups(pass,(n+63u)/64u,1,1);
                wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);
            };
            for(int k=0;k<repeats;++k){
                if(mode==0)dispatch(currentCP,currentBG,count);
                else if(mode==1){dispatch(cpProducer,bgProducer,count);dispatch(cpUnfused,bgUnfused,count);dispatch(fallbackCP,fallbackBG,count);}
                else if(mode==2){
                    // Mode 2: Frozen §6dr Canonical Routed Unfused Control
                    // Pass 0: Reset Counters
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpReset);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgReset, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 1, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 1: Classify Tiles
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpClassify);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgClassify, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 36, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 2: Route Args
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpArgs);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgArgs, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 3, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 3: S1 Producer Unfused (writes subpanels to sBuf)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS1Unfused);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS1UnfusedForced : bgS1Unfused, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 4: S2 Producer (Indirect)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS2);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS2Forced : bgS2, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 5: Fallback Producer (Indirect)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpFallback);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgFallbackForced : bgFallback, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 6: Canonical Unfused A* Consumer (processes S1 subpanels from sBuf)
                    dispatch(cpUnfused, bgUnfused, count);
                    // Pass 7: Production-Generated Current Marcher Fallback (only for refused rays)
                    dispatch(fallbackCP, fallbackBG, count);
                }
                else if(mode==3){
                    // Mode 3: §6dt/§6du True Terminal S1
                    // Pass 0: Reset Counters
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpReset);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgReset, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 1, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 1: Classify Tiles
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpClassify);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgClassify, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 36, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 2: Route Args
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpArgs);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgArgs, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 3, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 3: S1 Producer Terminal (evaluates quadrature in-producer, writes results[id], marks counts.w |= 0x40000000u)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS1Terminal);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS1TerminalForced : bgS1Terminal, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 4: S2 Producer (Indirect)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS2);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS2Forced : bgS2, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 5: Fallback Producer (Indirect)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpFallback);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgFallbackForced : bgFallback, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 6: Canonical Unfused A* Consumer (skips completed S1 rays and refused rays)
                    dispatch(cpUnfused, bgUnfused, count);
                    // Pass 7: Production-Generated Current Marcher Fallback (only for refused rays)
                    dispatch(fallbackCP, fallbackBG, count);
                }
            }
            auto cmd=wgpuCommandEncoderFinish(enc,nullptr);wgpuCommandEncoderRelease(enc);
            auto submitted=std::chrono::steady_clock::now();wgpuQueueSubmit(gpu.queue,1,&cmd);wgpuCommandBufferRelease(cmd);
            wgpuDevicePoll(gpu.device,true,nullptr);auto end=std::chrono::steady_clock::now();
            return std::array<double,3>{std::chrono::duration<double,std::milli>(submitted-begin).count(),
                std::chrono::duration<double,std::milli>(end-submitted).count(),std::chrono::duration<double,std::milli>(end-begin).count()};
        };
        auto correctness=[&](int testMode, bool forced){
            std::vector<GpuResult> poison(executionRays);for(auto& p:poison)for(float& v:p.rgb_T)v=NAN;
            wgpuQueueWriteBuffer(gpu.queue,outBuf,0,poison.data(),outBytes);execute(testMode,1,forced);auto result=readResults();
            const auto& expected=forced?resCurrent:resUnfused;
            for(size_t i=0;i<count;++i)for(int k=0;k<4;++k)
                if(!std::isfinite(result[i].rgb_T[k])||std::bit_cast<uint32_t>(result[i].rgb_T[k])!=std::bit_cast<uint32_t>(expected[i].rgb_T[k]))
                    throw std::runtime_error("stream mode " + std::to_string(testMode) + " changed or missed a result at ray " + std::to_string(i));
            J rows=J::array();for(size_t i=0;i<count;++i)rows.push_back({R[i][0],R[i][1],result[i].rgb_T[0],result[i].rgb_T[1],result[i].rgb_T[2],result[i].rgb_T[3]});
            return rows;
        };
        auto mode2NormalRows = correctness(2, false);
        auto mode2ForcedRows = correctness(2, true);
        auto normalRows = correctness(3, false);
        auto forcedRows = correctness(3, true);
        auto mode3ForcedHdrBytes = readBackBuffer(rBuf, rayBytes);
        const auto* mode3ForcedHdrs = reinterpret_cast<const GpuRayHeader*>(mode3ForcedHdrBytes.data());
        unsigned forcedCount = 0;
        for(size_t i=0;i<count;++i)if(mode3ForcedHdrs[i].overlapCount&0x80000000u)++forcedCount;
        if(forcedCount!=count)throw std::runtime_error("mode3 stream did not force every fallback");

        {
            auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
            // Reset counters
            {
                auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                wgpuComputePassEncoderSetPipeline(p, cpReset);
                wgpuComputePassEncoderSetBindGroup(p, 0, bgReset, 0, nullptr);
                wgpuComputePassEncoderDispatchWorkgroups(p, 1, 1, 1);
                wgpuComputePassEncoderEnd(p);
                wgpuComputePassEncoderRelease(p);
            }
            // Classify
            {
                auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                wgpuComputePassEncoderSetPipeline(p, cpClassify);
                wgpuComputePassEncoderSetBindGroup(p, 0, bgClassify, 0, nullptr);
                wgpuComputePassEncoderDispatchWorkgroups(p, 36, 1, 1);
                wgpuComputePassEncoderEnd(p);
                wgpuComputePassEncoderRelease(p);
            }
            // Route Args
            {
                auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                wgpuComputePassEncoderSetPipeline(p, cpArgs);
                wgpuComputePassEncoderSetBindGroup(p, 0, bgArgs, 0, nullptr);
                wgpuComputePassEncoderDispatchWorkgroups(p, 3, 1, 1);
                wgpuComputePassEncoderEnd(p);
                wgpuComputePassEncoderRelease(p);
            }
            // S1 Producer (Indirect)
            {
                auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                wgpuComputePassEncoderSetPipeline(p, cpS1Terminal);
                wgpuComputePassEncoderSetBindGroup(p, 0, bgS1Terminal, 0, nullptr);
                wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
                wgpuComputePassEncoderEnd(p);
                wgpuComputePassEncoderRelease(p);
            }
            // S2 Producer (Indirect)
            {
                auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                wgpuComputePassEncoderSetPipeline(p, cpS2);
                wgpuComputePassEncoderSetBindGroup(p, 0, bgS2, 0, nullptr);
                wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
                wgpuComputePassEncoderEnd(p);
                wgpuComputePassEncoderRelease(p);
            }
            // Fallback Producer (Indirect)
            {
                auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                wgpuComputePassEncoderSetPipeline(p, cpFallback);
                wgpuComputePassEncoderSetBindGroup(p, 0, bgFallback, 0, nullptr);
                wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                wgpuComputePassEncoderEnd(p);
                wgpuComputePassEncoderRelease(p);
            }
            auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
            wgpuCommandEncoderRelease(enc);
            wgpuQueueSubmit(gpu.queue, 1, &cmd);
            wgpuCommandBufferRelease(cmd);
            wgpuDevicePoll(gpu.device, true, nullptr);
            auto hb=readBackBuffer(rBuf,rayBytes),sb=readBackBuffer(sBuf,subpanelBytes),ob=readBackBuffer(oBuf,overlapBytes);
            const auto* hs=reinterpret_cast<const GpuRayHeader*>(hb.data());const auto* ss=reinterpret_cast<const GpuSubpanel*>(sb.data());const auto* os=reinterpret_cast<const GpuOverlap*>(ob.data());
            J packets=J::array();
            for(size_t i=0;i<count;++i){
                uint32_t flags = hs[i].overlapCount & 0xC0000000u;
                if (flags == 0xC0000000u) throw std::runtime_error("corrupt mutually exclusive ownership flags");
                J singles=J::array(),overs=J::array();
                if ((flags & 0x40000000u) != 0u) {
                    if (hs[i].subpanelCount != gpuRays[i].subpanelCount) throw std::runtime_error("coarse candidate S1 header mismatch");
                    for (uint32_t k = 0; k < hs[i].subpanelCount; ++k) {
                        const auto& b = gpuSubpanels[gpuRays[i].subpanelOffset + k];
                        singles.push_back({b.s0, b.s1, b.mediumIndex});
                    }
                } else {
                    if (hs[i].subpanelCount != gpuRays[i].subpanelCount || (hs[i].overlapCount & 0x00ffffffu) != gpuRays[i].overlapCount)
                        throw std::runtime_error("coarse candidate residual header mismatch");
                    for (uint32_t k = 0; k < hs[i].subpanelCount; ++k) {
                        const auto& a = ss[hs[i].subpanelOffset + k];
                        const auto& b = gpuSubpanels[gpuRays[i].subpanelOffset + k];
                        if (std::bit_cast<uint32_t>(a.s0) != std::bit_cast<uint32_t>(b.s0) ||
                            std::bit_cast<uint32_t>(a.s1) != std::bit_cast<uint32_t>(b.s1) ||
                            a.mediumIndex != b.mediumIndex) throw std::runtime_error("coarse candidate single packet mismatch");
                        singles.push_back({a.s0, a.s1, a.mediumIndex});
                    }
                    for (uint32_t k = 0; k < (hs[i].overlapCount & 0x00ffffffu); ++k) {
                        const auto& a = os[hs[i].overlapOffset + k];
                        const auto& b = gpuOverlaps[gpuRays[i].overlapOffset + k];
                        if (std::bit_cast<uint32_t>(a.s0) != std::bit_cast<uint32_t>(b.s0) ||
                            std::bit_cast<uint32_t>(a.s1) != std::bit_cast<uint32_t>(b.s1) ||
                            a.activeMask != b.activeMask) throw std::runtime_error("coarse candidate overlap packet mismatch");
                        overs.push_back({a.s0, a.s1, a.activeMask});
                    }
                }
                packets.push_back({R[i][0], R[i][1], hs[i].overlapCount & 0x80ffffffu, singles, overs});
            }
            report["coarse_packet_census_inputs"]=packets;
            auto cbBytes = readBackBuffer(cntBuf, sizeof(initCnt));
            const auto* cbPtr = reinterpret_cast<const DispatchCounters*>(cbBytes.data());
            report["routed_residual"] = {
                {"s1_tiles", cbPtr->s1},
                {"s2_tiles", cbPtr->s2},
                {"fallback_tiles", cbPtr->fb}
            };
            std::cerr << "ROUTED RESIDUAL CENSUS: S1=" << cbPtr->s1 << " S2=" << cbPtr->s2 << " Fallback=" << cbPtr->fb << std::endl;
        }

        J budgetControls=J::array();auto specs=curtainSpecs;
        for(auto& m:specs){m.origin=glm::vec4(1000,1000,1000,0);m.half=glm::vec4(1);m.amps=glm::vec4(0);m.freqs=glm::vec4(0);m.phases=glm::vec4(0);}
        specs[0].origin=glm::vec4(0);specs[0].half=glm::vec4(10);specs[0].limits={2,2,0,.2f};specs[0].curv={0,.001f,0,0};
        std::vector<GpuRayHeader> synthetic(16);for(auto& r:synthetic){r.ro[0]=-.5f;r.ro[1]=0;r.ro[2]=2;r.rd[0]=1;r.rd[1]=r.rd[2]=0;r.clipA=1;r.clipB=2;}
        auto specB=makeBuffer(WGPUBufferUsage_Storage|WGPUBufferUsage_CopyDst,specs.size()*sizeof(GpuCurtainSpec),specs.data());
        auto rayB=makeBuffer(WGPUBufferUsage_Storage|WGPUBufferUsage_CopySrc|WGPUBufferUsage_CopyDst,16*sizeof(GpuRayHeader),synthetic.data());
        for(int variant:{0,1})for(uint32_t budget:{23u,24u,25u}){
            auto u=cfg;u.rayCount=16;u.pad=budget;auto cb=makeBuffer(WGPUBufferUsage_Uniform|WGPUBufferUsage_CopyDst,sizeof(u),&u);auto cp=variant?cpFastCompact:cpFastFull;
            wgpuQueueWriteBuffer(gpu.queue,rayB,0,synthetic.data(),16*sizeof(GpuRayHeader));
            auto bg=group(cp,{entry(0,cb,0,sizeof(u)),entry(1,specB,0,specs.size()*sizeof(GpuCurtainSpec)),entry(2,rayB,0,16*sizeof(GpuRayHeader)),entry(3,sBuf,0,subpanelBytes),entry(4,oBuf,0,overlapBytes)});
            auto enc=wgpuDeviceCreateCommandEncoder(gpu.device,nullptr);auto pass=wgpuCommandEncoderBeginComputePass(enc,nullptr);
            wgpuComputePassEncoderSetPipeline(pass,cp);wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);wgpuComputePassEncoderDispatchWorkgroups(pass,1,1,1);
            wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);auto cmd=wgpuCommandEncoderFinish(enc,nullptr);wgpuCommandEncoderRelease(enc);wgpuQueueSubmit(gpu.queue,1,&cmd);wgpuCommandBufferRelease(cmd);
            auto hb=readBackBuffer(rayB,16*sizeof(GpuRayHeader));const auto* hs=reinterpret_cast<const GpuRayHeader*>(hb.data());J flags=J::array();
            for(int i=0;i<16;++i){uint32_t expected=budget<24?0x80000001u:0u;if(hs[i].overlapCount!=expected||hs[i].subpanelCount!=0)throw std::runtime_error("coarse exact-budget boundary mismatch");flags.push_back(hs[i].overlapCount);}
            budgetControls.push_back({{"variant",variant},{"budget",budget},{"flags",flags}});wgpuBindGroupRelease(bg);wgpuBufferRelease(cb);
        }
        wgpuBufferRelease(specB);wgpuBufferRelease(rayB);report["coarse_budget_controls"]=budgetControls;
        J capacityControls=J::array();
        for(int kind:{0,1}){
            auto capCfg = cfg; if (kind == 0) capCfg.maxSubPerRay = 4; else capCfg.maxOverPerRay = 1;
            wgpuQueueWriteBuffer(gpu.queue, cfgBuf, 0, &capCfg, sizeof(capCfg));
            for(size_t ti=0;ti<tiles.size();++ti){auto u=cfg;u.rayCount=tiles[ti].n;if(kind==0)u.maxSubPerRay=4;else u.maxOverPerRay=1;wgpuQueueWriteBuffer(gpu.queue,tileUniforms[4*ti+1],0,&u,sizeof(u));}
            std::vector<GpuResult> poison(executionRays);for(auto& r:poison)for(float& v:r.rgb_T)v=NAN;wgpuQueueWriteBuffer(gpu.queue,outBuf,0,poison.data(),outBytes);
            execute(3,1,false);auto res=readResults();auto hb=readBackBuffer(rBuf,rayBytes);const auto* hs=reinterpret_cast<const GpuRayHeader*>(hb.data());J flags=J::array(),output=J::array();uint32_t refused=0;
            for(size_t i=0;i<count;++i){const bool fallback=(hs[i].overlapCount&0x80000000u)!=0;refused+=fallback;
                if(fallback&&(hs[i].overlapCount&0x7fffffffu)!=(kind==0?16u:32u))throw std::runtime_error("coarse capacity reason mismatch");
                const auto& expected=fallback?resCurrent[i]:resUnfused[i];for(int k=0;k<4;++k)if(!std::isfinite(res[i].rgb_T[k])||std::bit_cast<uint32_t>(res[i].rgb_T[k])!=std::bit_cast<uint32_t>(expected.rgb_T[k]))throw std::runtime_error("coarse poisoned capacity output mismatch");
                flags.push_back(hs[i].overlapCount);output.push_back({R[i][0],R[i][1],res[i].rgb_T[0],res[i].rgb_T[1],res[i].rgb_T[2],res[i].rgb_T[3]});}
            if(refused==0)throw std::runtime_error("coarse capacity witness vacuous");capacityControls.push_back({{"kind",kind},{"refused",refused},{"flags",flags},{"output_rows",output}});
        }
        for(size_t ti=0;ti<tiles.size();++ti){auto u=cfg;u.rayCount=tiles[ti].n;wgpuQueueWriteBuffer(gpu.queue,tileUniforms[4*ti+1],0,&u,sizeof(u));}
        wgpuQueueWriteBuffer(gpu.queue,cfgBuf,0,&cfg,sizeof(cfg));
        report["coarse_capacity_controls"]=capacityControls;
        correctness(2,false);
        correctness(3,false);
        // 4 Warmup cycles
        for(int k=0;k<4;++k){execute(0,1,false);execute(1,1,false);execute(2,1,false);execute(3,1,false);}

        J series = J::array();
        J cleanTiming = J::object();
        for (int sIdx = 1; sIdx <= 2; ++sIdx) {
            std::string sKey = "series_" + std::to_string(sIdx);
            J seriesData = J::object();
            for (int rep : {1, 2, 4}) {
                std::string repKey = std::to_string(rep);
                J repData = J::object();
                J series1Samples = J::array();
                std::vector<std::vector<double>> modeSamples(4);
                for (int block = 0; block < 4; ++block) {
                    const std::vector<int> order = block % 2 ? std::vector<int>{3, 2, 1, 0, 0, 1, 2, 3} : std::vector<int>{0, 1, 2, 3, 3, 2, 1, 0};
                    for (int mode : order) {
                        auto t = execute(mode, rep, false);
                        modeSamples[mode].push_back(t[1]); // completion_ms
                        if (sIdx == 1) {
                            series1Samples.push_back({{"mode", mode}, {"encode_ms", t[0]}, {"completion_ms", t[1]}, {"total_ms", t[2]}});
                        }
                    }
                }
                if (sIdx == 1) {
                    series.push_back({{"repeats", rep}, {"samples", series1Samples}});
                }
                for (int m = 0; m < 4; ++m) {
                    auto& sVec = modeSamples[m];
                    std::sort(sVec.begin(), sVec.end());
                    double sum = std::accumulate(sVec.begin(), sVec.end(), 0.0);
                    double mean = sum / sVec.size();
                    double med = 0.5 * (sVec[sVec.size() / 2 - 1] + sVec[sVec.size() / 2]);
                    repData[std::to_string(m)] = {
                        {"samples", sVec},
                        {"min_ms", sVec.front()},
                        {"median_ms", med},
                        {"mean_ms", mean},
                        {"max_ms", sVec.back()}
                    };
                }
                seriesData[repKey] = repData;
            }
            cleanTiming[sKey] = seriesData;
        }

        // Pooled statistics across 64 samples
        J pooled = J::object();
        for (int rep : {1, 2, 4}) {
            std::string repKey = std::to_string(rep);
            J repPooled = J::object();
            for (int m = 0; m < 4; ++m) {
                std::string mKey = std::to_string(m);
                auto s1 = cleanTiming["series_1"][repKey][mKey]["samples"].get<std::vector<double>>();
                auto s2 = cleanTiming["series_2"][repKey][mKey]["samples"].get<std::vector<double>>();
                std::vector<double> allSamples = s1;
                allSamples.insert(allSamples.end(), s2.begin(), s2.end());
                std::sort(allSamples.begin(), allSamples.end());
                double sum = std::accumulate(allSamples.begin(), allSamples.end(), 0.0);
                double mean = sum / allSamples.size();
                double med = 0.5 * (allSamples[allSamples.size() / 2 - 1] + allSamples[allSamples.size() / 2]);
                repPooled[mKey] = {
                    {"samples", allSamples},
                    {"min_ms", allSamples.front()},
                    {"median_ms", med},
                    {"mean_ms", mean},
                    {"max_ms", allSamples.back()}
                };
            }
            pooled[repKey] = repPooled;
        }
        cleanTiming["pooled"] = pooled;
        report["clean_timing_series"] = cleanTiming;

        // Dedicated Pass Breakdown (16 iterations per single submission to eliminate host OS polling noise)
        J passBreakdown = J::object();
        auto measurePass = [&](const std::string& name, auto fn) {
            std::vector<double> passTimes;
            for (int s = 0; s < 16; ++s) {
                auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
                for (int it = 0; it < 16; ++it) {
                    fn(enc);
                }
                auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
                wgpuCommandEncoderRelease(enc);
                auto t0 = std::chrono::steady_clock::now();
                wgpuQueueSubmit(gpu.queue, 1, &cmd);
                wgpuCommandBufferRelease(cmd);
                wgpuDevicePoll(gpu.device, true, nullptr);
                double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / 16.0;
                passTimes.push_back(ms);
            }
            std::sort(passTimes.begin(), passTimes.end());
            double sum = std::accumulate(passTimes.begin(), passTimes.end(), 0.0);
            double mean = sum / passTimes.size();
            double med = 0.5 * (passTimes[passTimes.size() / 2 - 1] + passTimes[passTimes.size() / 2]);
            passBreakdown[name] = {
                {"min_ms", passTimes.front()},
                {"median_ms", med},
                {"mean_ms", mean},
                {"max_ms", passTimes.back()}
            };
        };

        measurePass("pass0_reset", [&](WGPUCommandEncoder enc) {
            auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(p, cpReset);
            wgpuComputePassEncoderSetBindGroup(p, 0, bgReset, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(p, 1, 1, 1);
            wgpuComputePassEncoderEnd(p);
            wgpuComputePassEncoderRelease(p);
        });
        measurePass("pass1_classify", [&](WGPUCommandEncoder enc) {
            auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(p, cpClassify);
            wgpuComputePassEncoderSetBindGroup(p, 0, bgClassify, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(p, 36, 1, 1);
            wgpuComputePassEncoderEnd(p);
            wgpuComputePassEncoderRelease(p);
        });
        measurePass("pass2_args", [&](WGPUCommandEncoder enc) {
            auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(p, cpArgs);
            wgpuComputePassEncoderSetBindGroup(p, 0, bgArgs, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(p, 3, 1, 1);
            wgpuComputePassEncoderEnd(p);
            wgpuComputePassEncoderRelease(p);
        });
        measurePass("pass3_s1_producer", [&](WGPUCommandEncoder enc) {
            auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(p, cpS1Terminal);
            wgpuComputePassEncoderSetBindGroup(p, 0, bgS1Terminal, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
            wgpuComputePassEncoderEnd(p);
            wgpuComputePassEncoderRelease(p);
        });
        measurePass("pass4_s2_producer", [&](WGPUCommandEncoder enc) {
            auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(p, cpS2);
            wgpuComputePassEncoderSetBindGroup(p, 0, bgS2, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
            wgpuComputePassEncoderEnd(p);
            wgpuComputePassEncoderRelease(p);
        });
        measurePass("pass5_fallback_producer", [&](WGPUCommandEncoder enc) {
            auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(p, cpFallback);
            wgpuComputePassEncoderSetBindGroup(p, 0, bgFallback, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
            wgpuComputePassEncoderEnd(p);
            wgpuComputePassEncoderRelease(p);
        });
        measurePass("pass6_cp_unfused", [&](WGPUCommandEncoder enc) {
            auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(p, cpUnfused);
            wgpuComputePassEncoderSetBindGroup(p, 0, bgUnfused, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(p, (count + 63u) / 64u, 1, 1);
            wgpuComputePassEncoderEnd(p);
            wgpuComputePassEncoderRelease(p);
        });
        measurePass("pass7_fallback_cp", [&](WGPUCommandEncoder enc) {
            auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(p, fallbackCP);
            wgpuComputePassEncoderSetBindGroup(p, 0, fallbackBG, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(p, (count + 63u) / 64u, 1, 1);
            wgpuComputePassEncoderEnd(p);
            wgpuComputePassEncoderRelease(p);
        });
        report["pass_breakdown_ms"] = passBreakdown;

        // Warm vs Cold Routed Execution
        J warmVsCold = J::object();
        for (int rep : {1, 2, 4}) {
            std::vector<double> coldTimes, warmTimes;
            for (int s = 0; s < 16; ++s) {
                // Cold: execute(3, rep, false)
                auto tCold = execute(3, rep, false);
                coldTimes.push_back(tCold[1]);

                // Warm: execute Mode 3 without Pass 0, 1, 2 (reusing argsBuf)
                auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
                for (int k = 0; k < rep; ++k) {
                    // S1 Terminal
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS1Terminal);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgS1Terminal, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // S2
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS2);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgS2, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Fallback
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpFallback);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgFallback, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // cpUnfused
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpUnfused);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgUnfused, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, (count + 63u) / 64u, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // fallbackCP
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, fallbackCP);
                        wgpuComputePassEncoderSetBindGroup(p, 0, fallbackBG, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, (count + 63u) / 64u, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                }
                auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
                wgpuCommandEncoderRelease(enc);
                auto t0 = std::chrono::steady_clock::now();
                wgpuQueueSubmit(gpu.queue, 1, &cmd);
                wgpuCommandBufferRelease(cmd);
                wgpuDevicePoll(gpu.device, true, nullptr);
                double tWarm = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
                warmTimes.push_back(tWarm);
            }
            std::sort(coldTimes.begin(), coldTimes.end());
            std::sort(warmTimes.begin(), warmTimes.end());
            auto stat = [](const std::vector<double>& v) {
                double sum = std::accumulate(v.begin(), v.end(), 0.0);
                return J{
                    {"min_ms", v.front()},
                    {"median_ms", 0.5 * (v[v.size() / 2 - 1] + v[v.size() / 2])},
                    {"mean_ms", sum / v.size()},
                    {"max_ms", v.back()}
                };
            };
            warmVsCold[std::to_string(rep)] = {
                {"cold", stat(coldTimes)},
                {"warm", stat(warmTimes)}
            };
        }
        report["warm_vs_cold_routed_ms"] = warmVsCold;
        streamingCases.push_back({{"capacity",capacity},{"tiles",tiles.size()},{"tail_rays",tiles.back().n},
            {"schedule_storage_bytes",tileSingleBytes+tileOverlapBytes},{"uniform_buffer_bytes",tiles.size()*(sizeof(udata)+2*sizeof(cfg)+sizeof(currentU))},
            {"binding_buffer_setup_ms",setupMs},{"normal_rows",normalRows},{"forced_rows",forcedRows},
            {"mode2_normal_rows",mode2NormalRows},{"mode2_forced_rows",mode2ForcedRows},
            {"forced_fallback_rays",forcedCount},{"bit_identical_to_bulk_candidate",true},{"forced_bit_identical_to_native",true},{"series",series}});
        for(auto& tile:tiles)for(auto bg:{tile.producer,tile.forced,tile.consumer,tile.fallback,tile.fastFull,tile.forcedFastFull,tile.fastCompact,tile.forcedFastCompact})wgpuBindGroupRelease(bg);
        for(auto b:tileUniforms)wgpuBufferRelease(b);wgpuBufferRelease(tileSingles);wgpuBufferRelease(tileOverlaps);
    }
    // Restore global producer offsets/schedules before other diagnostic callers.
    runBatchConnected(1);
    report["streamed_schedule"]={{"cases",streamingCases},{"unique_input_rays",count},{"full_viewport",false},
        {"original_interval_packets_retained",true},{"schedule_buffer_reused_only_after_consumer_and_fallback",true},
        {"world_or_source_admission_changed",false},{"production_lifetime_qualified",false},
        {"timing_scope","Host encoding + submission/completion; matching inputs/dispatch repetition; cold buffer/bind-group setup and correctness readbacks separate"}};


    // Native semantic controls invoke the producer's shared mayAbsorb helper.
    J policyControls=J::array();
    {
        const char* code=R"POLICY(
fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

@group(0) @binding(0) var<storage,read_write> output: array<vec4f>;
@compute @workgroup_size(64) fn policyMain(@builtin(global_invocation_id) gid: vec3u) { let id = gid.x; if (id >= 9u) { return; } var accepted = false;
if (id == 0u) { accepted = mayAbsorb(vec2f(0.0,0.01), vec2f(0.01,2.0), true, false, false, false); }
if (id == 1u) { accepted = mayAbsorb(vec2f(0.0,2.0), vec2f(2.0,2.01), false, true, true, false); }
if (id == 2u) { accepted = mayAbsorb(vec2f(0.0,0.01), vec2f(0.01,2.0), false, true, false, true); }
if (id == 3u) { accepted = mayAbsorb(vec2f(0.0,0.01), vec2f(0.01,2.0), false, true, false, false); }
if (id == 4u) { accepted = mayAbsorb(vec2f(0.0,2.0), vec2f(2.0,2.01), false, true, true, true); }
if (id == 5u) { accepted = mayAbsorb(vec2f(0.0,0.01), vec2f(0.01,2.0), true, false, false, true); }
if (id == 6u) { accepted = mayAbsorb(vec2f(0.0,0.01), vec2f(0.02,2.0), true, false, false, false); }
if (id == 7u) { accepted = mayAbsorb(vec2f(0.0,0.01), vec2f(0.01,0.02), true, false, true, false); }
if (id == 8u) { accepted = mayAbsorb(vec2f(0.0,2.0), vec2f(2.0,2.1), false, true, true, false); }
output[id] = vec4f(select(0.0, 1.0, accepted)); })POLICY";
        wgpuDevicePushErrorScope(gpu.device,WGPUErrorFilter_Validation);
        WGPUShaderSourceWGSL src={};src.chain.sType=WGPUSType_ShaderSourceWGSL;src.code=wgpu::Device::str(code);
        WGPUShaderModuleDescriptor smd={};smd.nextInChain=&src.chain;
        auto sm=wgpuDeviceCreateShaderModule(gpu.device,&smd);
        WGPUComputePipelineDescriptor pd={};pd.compute.module=sm;pd.compute.entryPoint=wgpu::Device::str("policyMain");
        auto cp=wgpuDeviceCreateComputePipeline(gpu.device,&pd);
        PopContext check;WGPUPopErrorScopeCallbackInfo cb={};cb.mode=WGPUCallbackMode_AllowProcessEvents;cb.callback=onPopError;cb.userdata1=&check;
        wgpuDevicePopErrorScope(gpu.device,cb);while(!check.done)wgpuDevicePoll(gpu.device,true,nullptr);
        if(check.type!=WGPUErrorType_NoError||!cp)throw std::runtime_error("guarded policy shader refused");
        auto layout=wgpuComputePipelineGetBindGroupLayout(cp,0);
        WGPUBindGroupEntry entry={};entry.binding=0;entry.buffer=outBuf;entry.size=outBytes;
        WGPUBindGroupDescriptor bd={};bd.layout=layout;bd.entryCount=1;bd.entries=&entry;
        auto bg=wgpuDeviceCreateBindGroup(gpu.device,&bd);
        std::vector<GpuResult> poison(executionRays);for(auto& r:poison)for(float& v:r.rgb_T)v=NAN;
        wgpuQueueWriteBuffer(gpu.queue,outBuf,0,poison.data(),outBytes);
        runPass(cp,bg);auto got=readResults();const float expected[]={1.0f,1.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f};
        for(size_t i=0;i<std::size(expected);++i){
            for(float v:got[i].rgb_T)if(v!=expected[i])throw std::runtime_error("native protected-boundary policy failed");
            policyControls.push_back({{"case",i},{"expected",expected[i]},{"observed",got[i].rgb_T[0]},{"pass",true}});
        }
        wgpuBindGroupRelease(bg);wgpuBindGroupLayoutRelease(layout);wgpuComputePipelineRelease(cp);wgpuShaderModuleRelease(sm);
    }

    // Independent closed-form witnesses. These change only scratch GPU buffers,
    // after all fixture readback and timing; the world/save never changes.
    auto syntheticMedia=gpuMedia;auto syntheticParams=globalParamPool;
    const float rawTargets[4]={0.0f,0.5e-6f,0.2f,0.7f};
    const glm::vec3 witnessColors[4]={{.2f,.4f,.8f},{.2f,.4f,.8f},{.8f,.2f,.1f},{.1f,.3f,.9f}};
    for(size_t m=0;m<4;++m) {
        const size_t at=media[m].paramOffset;
        std::fill(syntheticParams.begin()+at,syntheticParams.begin()+at+34,0.0f);
        auto* v=syntheticParams.data()+at;
        v[0]=rawTargets[m]/.7f;v[1]=1;v[2]=1;v[4]=1;
        v[5]=1;v[6]=1;v[8]=1;v[9]=1;v[10]=1;v[13]=1;
        v[14]=1;v[15]=1;v[26]=1;v[27]=1;
        for(int k=0;k<4;++k)syntheticMedia[m].origin[k]=0;
        for(int k=0;k<3;++k)syntheticMedia[m].color[k]=witnessColors[m][k];
        syntheticMedia[m].color[3]=1;syntheticMedia[m].freq[0]=0;
    }
    std::vector<GpuSubpanel> ws{{0,.01f,0,0},{0,.01f,1,0},{0,1,2,0},{0,1,2,0},{2,3,3,0}};
    std::vector<GpuOverlap> wo{{0,1,12u,0},{1,2,12u,0}};
    std::vector<GpuRayHeader> wr(5);
    for(size_t i=0;i<5;++i)wr[i].clipB=3;
    wr[0].subpanelOffset=0;wr[0].subpanelCount=1;
    wr[1].subpanelOffset=1;wr[1].subpanelCount=1;
    wr[2].subpanelOffset=2;wr[2].subpanelCount=1;
    wr[3].overlapOffset=0;wr[3].overlapCount=1;
    wr[4].subpanelOffset=3;wr[4].subpanelCount=2;wr[4].overlapOffset=1;wr[4].overlapCount=1;
    auto knownFlow=[&](glm::dvec4 state,uint32_t mask,double h) {
        double sigma=0;glm::dvec3 emit(0);
        for(int m=0;m<4;++m)if(mask&(1u<<m)) {
            const double raw=double(syntheticParams[media[m].paramOffset]*.7f);
            if(!(raw>0))continue;
            sigma+=std::max(raw,1e-6);emit+=glm::dvec3(witnessColors[m])*raw;
        }
        const double tau=h*sigma,gain=tau==0?h:h*(-std::expm1(-tau)/tau);
        return glm::dvec4(glm::dvec3(state)+state.w*emit*gain,state.w*std::exp(-tau));
    };
    const glm::dvec4 initial(0,0,0,1);
    std::vector<glm::dvec4> expected{knownFlow(initial,1u,.01f),knownFlow(initial,2u,.01f),knownFlow(initial,4u,1),knownFlow(initial,12u,1),
        knownFlow(knownFlow(knownFlow(initial,4u,1),12u,1),8u,1)};
    wgpuQueueWriteBuffer(gpu.queue,mBuf,0,syntheticMedia.data(),mediaBytes);
    wgpuQueueWriteBuffer(gpu.queue,pBuf,0,syntheticParams.data(),paramBytes);
    wgpuQueueWriteBuffer(gpu.queue,rBuf,0,wr.data(),wr.size()*sizeof(GpuRayHeader));
    wgpuQueueWriteBuffer(gpu.queue,sBuf,0,ws.data(),ws.size()*sizeof(GpuSubpanel));
    wgpuQueueWriteBuffer(gpu.queue,oBuf,0,wo.data(),wo.size()*sizeof(GpuOverlap));
    auto wu=udata;wu.rayCount=5;wgpuQueueWriteBuffer(gpu.queue,uBuf,0,&wu,sizeof(wu));
    runPass(cpUnfused,bgUnfused);auto witnessA=readResults();
    runPass(cpFused,bgFused);auto witnessB=readResults();
    const char* names[]={"zero density","tiny positive floored depth","ordinary single medium","pure different-color overlap","single-overlap-single chronological flow"};
    J witnesses=J::array();bool witnessesPass=true;
    for(size_t i=0;i<5;++i) {
        bool pass=true;double maxRGB=0,maxT=0;
        for(auto* actual:{&witnessA,&witnessB})for(int k=0;k<4;++k) {
            const double err=std::abs(double((*actual)[i].rgb_T[k])-expected[i][k]);
            const double tolerance=k==3?2e-6:3e-6*std::max(std::abs(expected[i][k]),1e-12);
            pass=pass&&err<=tolerance;
            if(k==3)maxT=std::max(maxT,err);else maxRGB=std::max(maxRGB,err);
        }
        witnessesPass=witnessesPass&&pass;
        witnesses.push_back({{"case",names[i]},{"pass",pass},{"max_RGB_delta",maxRGB},{"max_T_delta",maxT},
            {"expected",{expected[i].x,expected[i].y,expected[i].z,expected[i].w}},
            {"unfused",{witnessA[i].rgb_T[0],witnessA[i].rgb_T[1],witnessA[i].rgb_T[2],witnessA[i].rgb_T[3]}}});
    }
    report["closed_form_witnesses"]=witnesses;
    bool accuracyPass=true;
    for(const char* channel:{"RGB_pooled_channels","T"})for(const char* metric:{"mean","p99","max"})
        accuracyPass=accuracyPass&&report["accuracy_vs_independent_reference"]["unfused_A_star_on_device"][channel][metric].get<double>()<=report["accuracy_vs_independent_reference"]["native_baseline"][channel][metric].get<double>();
    report["qualification"]={{"closed_form_witnesses_pass",witnessesPass},{"mean_p99_max_reference_gates_pass",accuracyPass},
        {"independent_AST_agreement_pass",maxDeltaRGB_CPU_vs_GPU<1e-5&&maxDeltaT_CPU_vs_GPU<1e-5},
        {"shipping_performance_qualified",false}};
    report["scope"]="Scratch complete ordered single+overlap A* diagnostic; sparse rays, not a renderer speed claim";
    report["timing_protocol"]="Completion-fenced host elapsed, per-dispatch normalization from 64-dispatch batches; no GPU timestamps, no readback in timed batches";
    report["batched_fence_series"]=batchSeries;
    report["ordered_coverage"]={{"cpu_single_subpanels",cpuSingles},{"cpu_overlap_intervals",cpuOverlaps},{"cpu_overlap_member_sites",cpuOverlapMemberSites},
        {"independent_comparator","original authored MathNode density/extinction/emission; no copied-envelope oracle"}};
    report["cpu_vs_gpu_arithmetic_deviation"]["note"]="Independent AST; CPU double scalar operations and vec3/f32 properties differ from shader execution";
    J raw=J::array();
    for(size_t i=0;i<count;++i)raw.push_back({R[i][0],R[i][1],resUnfused[i].rgb_T[0],resUnfused[i].rgb_T[1],resUnfused[i].rgb_T[2],resUnfused[i].rgb_T[3],resFused[i].rgb_T[0],resFused[i].rgb_T[1],resFused[i].rgb_T[2],resFused[i].rgb_T[3],resCPU[i].rgb_T[0],resCPU[i].rgb_T[1],resCPU[i].rgb_T[2],resCPU[i].rgb_T[3],gpuRays[i].overlapCount});
    if(!outputPath.empty()){std::ofstream out(outputPath+"-rows.json");out<<raw.dump()<<"\n";}

    report.erase("fusion_isolation_benchmark");
    report["timing_protocol"]="Completion-fenced host elapsed; normalization by the last configured batch (64 dispatches at repeat=1, 4 at repeat>1); no GPU timestamps, no readback in timed batches";
    report["scope"]="Generated production marcher versus complete unfused A* on identical captured rays, repeated for throughput; precomputed A* schedules";
    report["current_baseline_witness"]={{"stored_native_max_RGB_delta",currentDeltaRGB},{"stored_native_max_T_delta",currentDeltaT},
        {"integration_body_verbatim",true},{"zero_proofs",true},{"trim_support_lane",trim},{"GPU_time_preparation",true}};
    report["execution_workload"]={{"distinct_rays",count},{"repeat_factor",repeatFactor},{"invocations_per_dispatch",executionRays},
        {"replicated_output_verified",true},{"actual_full_viewport",false},{"boundary_preparation_in_timing",false}};
    report["current_vs_A_star"]={{"current_normalized_host_ms",meanUnfusedMs},{"A_star_normalized_host_ms",meanFusedMs},
        {"speedup_factor",meanUnfusedMs/meanFusedMs},{"clock","submission-to-blocking-poll host elapsed; normalized batched dispatches"}};
    WGPUAdapterInfo adapterInfo={};
    if(wgpuAdapterGetInfo(gpu.adapter,&adapterInfo)==WGPUStatus_Success) {
        report["observed_adapter"]={{"device",std::string(adapterInfo.device.data,adapterInfo.device.length)},
            {"backend",uint32_t(adapterInfo.backendType)},{"metal",adapterInfo.backendType==WGPUBackendType_Metal},{"timestamps",gpu.timestampQueries}};
        wgpuAdapterInfoFreeMembers(adapterInfo);
    }
    wgpuBindGroupRelease(currentBG);wgpuBindGroupRelease(prepBG);wgpuComputePipelineRelease(currentCP);wgpuComputePipelineRelease(prepCP);
    for(auto b:{cuBuf,cparamsBuf,ciBuf})wgpuBufferRelease(b);


    report["scope"] = "Generative GPU Canonical Producer + A* Consumer connected in single command buffer; dynamic OntoMath extraction";
    report["gpu_canonical_producer"] = {
        {"dynamic_OntoMath_extraction", true},
        {"GPU_producer", true},
        {"zero_cpu_schedule_generation", true},
        {"zero_schedule_upload_overhead", true},
        {"chained_command_buffer", true}
    };
    report["connected_measured_scope"] = connected;
    report["qualification"]["device_fused_unfused_parity_pass"] = maxDeltaRGB_dev == 0 && maxDeltaT_dev == 0;
    report["qualification"]["shipping_performance_qualified"] = connected["speedup_factor"].get<double>() > 1.0;


    J reasons=J::object();unsigned fallbackRays=0;
    for(auto flag:producerFlags)if(flag&0x80000000u){++fallbackRays;auto key=std::to_string(flag&0x7fffffffu);reasons[key]=reasons.value(key,0u)+1;}
    report["scope"]="Pinned GPU numerical producer; typed whole-ray native fallback; no generic derivation or certified native omission admission";
    report["gpu_canonical_producer"]={{"GPU_producer",true},{"fixed_layout_parameter_decode",true},{"generic_OntoMath_extraction",false},
        {"native_omission_admitted",false},{"diagnostic_margin",curtainSpecs[0].curv.y},{"fallback_rays",fallbackRays},{"fallback_reasons",reasons},
        {"zero_per_run_host_schedule_generation",true},{"schedule_initial_upload_bytes",0},{"padded_capacity_bytes",subpanelBytes+overlapBytes+rayBytes}};
    report["execution_workload"]["boundary_preparation_in_timing"]=true;
    report["execution_workload"]["boundary_preparation_scope"]="GPU per-ray instantiation in connected batches; cold host decoding/compilation/reference work excluded";
    report["current_vs_A_star"]["scope"]="Consumer plus native fallback only, excludes GPU producer; use batched_fence_series for connected costs";
    auto& connectedReport=report["connected_measured_scope"];
    connectedReport["connected_submission_to_poll_host_ms"]=connectedReport["connected_gpu_ms"];
    connectedReport.erase("connected_gpu_ms");
    connectedReport["producer_only_submission_to_poll_host_ms"]=connectedReport["producer_only_gpu_ms"];
    connectedReport.erase("producer_only_gpu_ms");
    connectedReport["clock"]="Submission-to-blocking-poll host elapsed, not a GPU timestamp or fence-floor-subtracted estimate";
    report["qualification"]["shipping_performance_qualified"]=false;
    report["qualification"]["fallback_native_baseline_identical"]=true;
    report["qualification"]["poisoned_connected_output_fully_written"]=true;
    report["ordered_coverage"]["native_baseline_fallback_rays"]=cpuBaselineFallbacks;
    report["cpu_vs_gpu_arithmetic_deviation"]["note"]="Independent AST quadrature only on canonical rays; fallback rays verified bit-identical to actual production-generated native baseline";
    wgpuBindGroupRelease(fallbackBG);wgpuComputePipelineRelease(fallbackCP);


    report["uncertain_band_experiment"]={{"depth_limited_intervals_retained_whole",true},{"touching_uncertainty_bands_unioned_without_gap",true},
        {"uncertainty_is_root_resolution",false},{"proof_subdivision_stops_when_curvature_is_below_existing_error_model",true},{"numerical_quadrature_error_certified",false},
        {"work_and_capacity_exhaustion_use_native_fallback",true},
        {"scope","Fixture numerical experiment: no native omission admission or shipping qualification"}};


    report["scope"]="Additional native camera-ray numerical qualification; pinned four-curtain source; no generic/native omission/production/full-frame admission";
    report["current_baseline_witness"]["integration_body_verbatim"]=emptySupportDiscardAdaptations==0;
    report["current_baseline_witness"]["empty_support_discard_to_identity_adaptations"]=emptySupportDiscardAdaptations;
    report["current_baseline_witness"]["adaptation_scope"]="Only generated empty-support fragment discard becomes raw transport identity (L=0,T=1); all other operations retained";
    report["reference_resolution"]={{"finest_intervals",ref.at("finest_intervals")},{"half_intervals",ref.at("half_intervals")}};
    report["pose_case"]={{"view",rays.at("view")},{"clock",clock},{"captured_native_ray_count",rays.at("native_volume_rays")},
        {"selected_reference_ray_count",count},{"selection",rays.at("selection")},{"actual_full_viewport",false}};
    report["timing_protocol"]="Matched captured-ray invocations, 1/64/512-dispatch completion-fenced host batches; final consumer-only normalization512; no GPU timestamps or timed readback";


    J coefficients=J::array();
    for(const auto& m:media)coefficients.push_back({{"member",m.id},{"extinction_over_density",m.alpha},
        {"emission_over_extinction",{m.color.x,m.color.y,m.color.z}}});
    report["authored_coefficient_binding"]={{"literal_clock_specific_color_tables_used",false},
        {"shared_original_subtree_identity_checked",true},{"emission_coefficient_time_only_checked",true},
        {"clock",clock},{"members",coefficients},{"general_native_execution_certificate",false},{"cold_structural_binding_ms",coefficientBindingMs},{"binding_in_gpu_timing",false},{"dynamic_frame_lifetime_qualified",false}};


    report["authored_coefficient_binding"]["derivation_office"]="OntoMath::factorCommonScalar";
    report["authored_coefficient_binding"]["source_snapshots_owned"]=true;
    report["authored_coefficient_binding"]["clock_preparation_ms"]=coefficientPreparationMs;
    report["authored_coefficient_binding"]["production_revision_device_lifetime_qualified"]=false;
    report["authored_coefficient_binding"]["cold_structural_binding_ms"]=coefficientBindingMs;
    report["authored_coefficient_binding"]["full_frame_preparation_upload_in_gpu_timing"]=false;

    report["authored_coefficient_binding"]["recipe_header_sha256"]="abc149b49a9c4683080304a58eab169f64e4ea66848f799b3dcdbb6087011dba";


    report["scope"]="32784 distinct native-ray ring-reuse screen; independent dense transport reference only on192 predetermined holdout rays; no full viewport/frame/source generality";
    report["pose_case"]["selected_reference_ray_count"]=Rows.size();
    report["reference_scope"]={{"query_count",count},{"dense_reference_count",Rows.size()},
        {"ray_indices",ref.at("ray_indices")},{"selection","Uniform indices fixed before candidate/error evaluation"},
        {"all_rays_have_dense_reference",false},{"all_rays_original_AST_node_agreement_checked",true}};
    report["regressions_vs_native"]["RGB_worse_pct"]=double(aStarWorseThanNat_RGB)*100/Rows.size();
    report["regressions_vs_native"]["T_worse_pct"]=double(aStarWorseThanNat_T)*100/Rows.size();
    report["timing_protocol"]="Bounded1/2/4 query repetitions; streamed_schedule includes encoding and completion, paired with actual current and bulk candidate; no GPU timestamps";
    report["current_vs_A_star"]["legacy_normalization_used_for_retention"]=false;


    report["producer_sliver_merge"] = {
        {"stack_endpoint_forwarding", true},
        {"stack_evalPhi_calls_on_pop", 0},
        {"stack_evalPhi_calls_on_split", 1},
        {"bounds_and_events_merged_into_knots_96", true},
        {"pieces_packed_to_vec2f_48_with_member_bits", true},
        {"private_memory_bytes_per_thread", 1344},
        {"root_sliver_absorption_enabled", true},
        {"root_sliver_threshold_m", 0.02},
        {"all_capacities_retained", true},
        {"scope", "§6cp: Numerical candidate with touching root-sliver absorption (<= 0.02 m) on top of §6co"}
    };


    report["guarded_sliver_policy"]={{"numerical_candidate",true},{"requires_short_uncertainty_provenance",true},
        {"affine_knot_boundaries_protected",true},{"zero_level_band_endpoints_protected",true},
        {"policy_native_controls",policyControls},{"mode_names",{{"0","current"},{"1","bulk connected"},{"2","bounded streamed connected"}}},
        {"shipping_performance_qualified",false}};
    report["guarded_sliver_policy"]["curtain_bindings"]=J::array();
    for(const auto& spec:curtainSpecs)report["guarded_sliver_policy"]["curtain_bindings"].push_back({
        {"origin",{spec.origin.x,spec.origin.y,spec.origin.z}},
        {"limits",{spec.limits.x,spec.limits.y,spec.limits.z,spec.limits.w}}});
    report["producer_sliver_merge"]["scope"]="Historical width-only §6cp replaced by guarded numerical policy; unchanged threshold/accuracy/fallback";
    report["producer_sliver_merge"].erase("private_memory_bytes_per_thread");


    report["four_way_merge_and_sweep"] = {
        {"algorithm", "4-way merge of ordered member streams with linear-advance mask sweep"},
        {"global_insertion_sort_eliminated", true},
        {"repeated_full_piece_scan_eliminated", true},
        {"bit_identical_to_guarded_baseline_required", true},
        {"scope", "§6cr: Isolated event construction/sweep optimization under guarded policy"}
    };


    report["coarse_peel_experiment"]={{"scope","§6du Corrective Qualification: Unthrottled 4-Mode Timing Series & Mode 2 Frozen §6dr Routed Unfused Control"},
        {"new_math_or_cull",false},{"modes",{{"0","Current"},{"1","Guarded bulk"},{"2","Guarded stream"},{"3","Coarse peel stream"}}}};
    wgpuComputePipelineRelease(cpFastFull);
    wgpuComputePipelineRelease(cpFastCompact);

    std::cout << "Coarse-only report saved." << std::endl;

    if (!outputPath.empty()) {
        std::ofstream out(outputPath);
        out << report.dump(2) << "\n";
        std::cout << "Report saved to " << outputPath << "\n";
    }

    // Release resources
    wgpuBindGroupRelease(bgUnfused);
    wgpuBindGroupRelease(bgFused);
    wgpuComputePipelineRelease(cpUnfused);
    wgpuComputePipelineRelease(cpFused);
    for (WGPUBuffer b : {uBuf, mBuf, pBuf, rBuf, sBuf, oBuf, outBuf, readBuf}) {
        wgpuBufferRelease(b);
    }

    return witnessesPass && accuracyPass && maxDeltaRGB_CPU_vs_GPU<1e-5 && maxDeltaT_CPU_vs_GPU<1e-5 && maxDeltaRGB_dev==0 && maxDeltaT_dev==0 ? 0 : 3;
}
