#include "Singularity/OntoMath/CommonScalarFactor.hpp"
// CommonScalarFactor.hpp sha256: abc149b49a9c4683080304a58eab169f64e4ea66848f799b3dcdbb6087011dba
#include <bit>

#include <fstream>
#include <iostream>
#include <memory>
#include <chrono>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <array>
#include <numeric>
#include <stdexcept>
#include <webgpu/wgpu.h>
#include "Singularity/Screen/VolumeZeroProof.hpp"

#include "ConstructedBeing/Singular/Object/Geometry/FieldNode.hpp"
#include "Singularity/Screen/VolumeDensity.hpp"
#include "Singularity/OntoMath/LineRestriction.hpp"
#include "Singularity/Screen/WebGPU/WgpuDevice.hpp"
#include "Singularity/Screen/WebGPU/SdfWgsl.hpp"
#include "json.hpp"

using J = nlohmann::json;

// Dynamic curtain specification extracted from authored MathNode AST
struct alignas(16) GpuCurtainSpec {
    glm::vec4 origin;    // xyz = origin, w = unused
    glm::vec4 half;      // xyz = halfExtent, w = unused
    glm::vec4 limits;    // x = Wx, y = Wy, z = yKnee, w = wz
    glm::vec4 curv;      // x = M2_x, yzw = unused
    glm::vec4 amps;      // x = A1, y = A2, z = A3, w = unused
    glm::vec4 freqs;     // x = w1, y = w2, z = w3, w = unused
    glm::vec4 phases;    // x = p1, y = p2, z = p3, w = unused
};
static_assert(sizeof(GpuCurtainSpec) == 112);

// Extract curtain specifications dynamically from authored zone
inline bool extractCurtainSpecs(const J& zone, std::vector<GpuCurtainSpec>& outSpecs) {
    outSpecs.clear();
    for (const auto& j : zone.at("spatialFields")) {
        auto field = geom::FieldNode::fromJson(j);
        Rendering::VolumeDensityBinding bnd;
        if (!field || !Rendering::readVolumeDensity(*field, 0, 0, bnd)) continue;
        if (!bnd.densityExpr) continue;
        
        auto pb = sdfwgsl::collectVolumeParams(bnd.densityExpr);
        if (pb.values.size() < 34) return false;
        const auto& v = pb.values;
        
        GpuCurtainSpec spec{};
        spec.origin = glm::vec4(bnd.origin, 0.0f);
        spec.half = glm::vec4(glm::abs(bnd.scale), 0.0f);
        
        float Wx = v[2];
        float Wy = v[6];
        float yKnee = -Wy + (v[5] > 0.0f ? 1.0f / v[5] : 4.0f);
        float wz = v[15];
        if(!(Wx>0&&Wy>0&&wz>0&&v[5]>0&&std::isfinite(Wx)&&std::isfinite(Wy)&&std::isfinite(wz)))return false;
        spec.limits = glm::vec4(Wx, Wy, yKnee, wz);
        
        float A1 = v[16], w1 = v[17], p1 = v[18];
        float A2 = v[19], w2 = v[20], p2 = v[21];
        float A3 = v[22], w3 = v[23], p3 = v[24];
        
        spec.amps = glm::vec4(A1, A2, A3, 0.0f);
        spec.freqs = glm::vec4(w1, w2, w3, 0.0f);
        spec.phases = glm::vec4(p1, p2, p3, 0.0f);
        
        float M2 = std::abs(A1) * w1 * w1 + std::abs(A2) * w2 * w2 + std::abs(A3) * w3 * w3;
        spec.curv = glm::vec4(std::nextafter(M2,INFINITY)*1.00002f, std::getenv("EC_GPU_MARGIN")?std::stof(std::getenv("EC_GPU_MARGIN")):.001f,0,0);
        
        outSpecs.push_back(spec);
    }
    return outSpecs.size() == 4;
}

static const char* kGpuProducerWgsl=R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<storage,read> curtains:array<CurtainSpec,4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;
fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}
fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 // Bands describe uncertainty sets, not distinct roots. Merge only
 // intersecting/touching bands; never bridge an unrepresented gap.
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}
// The curvature/endpoint model is explicit. A bin must be monotone before
// bisection can resolve it. Exhaustion never becomes an isolated midpoint.

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}
fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  stack[0] = vec4f(a, b, phi_a0, phi_b0); setDepth(&depthBits, 0u, 0u); top = 1u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if ((va > error && vb < -error) || (va < -error && vb > error)) {
     var l = a; var r = b; var left = va;
     for (var iter = 0u; iter < 32u; iter++) {
      if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
      let mid = l + 0.5 * (r - l);
      if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
      let v = evalPhi(m, o, d, mid) - c;
      if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
      if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
     }
     putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
    }
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

@compute @workgroup_size(64)
fn producerMain(@builtin(global_invocation_id) gid: vec3u) {
 let id = gid.x; if (id >= cfg.rayCount) { return; }
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 4u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   // Reuse exactly the affine-knot arithmetic used when inserting knots above.
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
  var ne = 0u;
 var head = vec4u(0u);
 let totalKnots = (memCount.x + memCount.y + memCount.z + memCount.w) * 2u;
 loop {
  if (ne >= totalKnots) { break; }
  var bestM = 4u;
  var bestVal = 0.0;
  for (var m = 0u; m < 4u; m++) {
   let h = head[m];
   if (h < memCount[m] * 2u) {
    let pIdx = memStart[m] + (h >> 1u);
    let isY = (h & 1u) != 0u;
    let val = select(pieces[pIdx].x, pieces[pIdx].y, isY);
    if (bestM == 4u || val < bestVal) {
     bestVal = val;
     bestM = m;
    }
   }
  }
  knots[ne] = bestVal;
  ne++;
  head[bestM]++;
 }
 var singles = 0u; var overs = 0u;
 var pIdx = vec4u(0u);
 for (var i = 1u; i < ne && reason == 0u; i++) {
  let a = knots[i - 1u]; let b = knots[i]; if (!(b > a)) { continue; }
  let mid = a + 0.5 * (b - a);
  var mask = 0u;
  for (var m = 0u; m < 4u; m++) {
   let start = memStart[m];
   let numPieces = memCount[m];
   var cur = pIdx[m];
   loop {
    if (cur >= numPieces || pieces[start + cur].y >= mid) { break; }
    cur++;
   }
   pIdx[m] = cur;
   if (cur < numPieces) {
    let p = pieces[start + cur];
    if (mid >= p.x && mid <= p.y) {
     mask |= (1u << m);
    }
   }
  }
  if (mask == 0u) { continue; }
  if (countOneBits(mask) == 1u) {
   let n = max(1u, u32(ceil((b - a) / 4.0)));
   if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
   let member = firstTrailingBit(mask);
   for (var k = 0u; k < n; k++) {
    let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
    let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
    subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(member, 0)); singles++;
   }
  } else {
   if (overs >= cfg.maxOverPerRay) { reason |= 32u; break; }
   overlaps[overBase + overs] = Overlap(vec2f(a, b), vec2u(mask, 0)); overs++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, overs); }
}

)WGSL";

using M = OntoMath::MathNode;

static bool containsNoise(const M& n) {
    if (n.op == M::Op::Noise) return true;
    for (const auto& ch : n.children) if (ch && containsNoise(*ch)) return true;
    return false;
}

static std::unique_ptr<M> cloneEnvelope(const M& n) {
    if (n.op == M::Op::Clamp && containsNoise(n)) {
        auto one = std::make_unique<M>();
        one->op = M::Op::ScalarLeaf;
        one->scalarForm = OntoMath::ScalarForm::constant(1.0);
        return one;
    }
    auto copy = std::make_unique<M>();
    copy->op = n.op;
    copy->scalarForm = n.scalarForm;
    copy->variableName = n.variableName;
    copy->stringArg = n.stringArg;
    copy->matrixRows = n.matrixRows;
    copy->matrixCols = n.matrixCols;
    for (const auto& ch : n.children) {
        copy->children.push_back(ch ? cloneEnvelope(*ch) : nullptr);
    }
    return copy;
}

static const M* single(const OntoMath::Piecewise* p) {
    if (!p || p->pieces.size() != 1) return nullptr;
    const auto& x = p->pieces[0];
    return !x.guard && !x.call && !x.fold && !x.hasLo && !x.hasHi && !x.whereLEZero ? x.mathNode.get() : nullptr;
}

struct Medium {
    std::shared_ptr<geom::FieldNode> owner;
    std::string id;
    glm::dvec3 origin;
    glm::dvec3 half;
    const M *density = nullptr, *sigma = nullptr, *emission = nullptr;
    std::unique_ptr<M> envAST;
    OntoMath::LineAlgebraicForm envForm;
    bool hasEnv = false;
    float alpha = 0.0f;
    glm::vec3 color{0.0f};
    float noiseFreq = 0.0f;
    uint32_t paramOffset = 0;
};

struct Piece {
    int mediumIndex;
    double s0, s1;
    std::vector<int8_t> signs;
};

// GPU Data structures
struct GpuRayHeader {
    float ro[3]; float clipA;
    float rd[3]; float clipB;
    uint32_t subpanelOffset; uint32_t subpanelCount;
    uint32_t overlapOffset;  uint32_t overlapCount;
};

struct GpuSubpanel {
    float s0, s1;
    uint32_t mediumIndex;
    float pad;
};

struct GpuOverlap {
    float s0, s1;
    uint32_t activeMask;
    float pad;
};

struct GpuMediumParams {
    float origin[4];   // x, y, z, pad
    float color[4];    // r, g, b, alpha
    float freq[4];     // freq, paramOffset, pad, pad
};

struct GpuResult {
    float rgb_T[4];    // r, g, b, T
};

// WebGPU Map Callback
struct MapContext { bool done = false; bool ok = false; };
static void onMapped(WGPUMapAsyncStatus s, WGPUStringView, void* u, void*) {
    auto* c = static_cast<MapContext*>(u);
    c->ok = (s == WGPUMapAsyncStatus_Success);
    c->done = true;
}

// WebGPU Pop Error Scope Callback
struct PopContext { WGPUErrorType type = WGPUErrorType_NoError; bool done = false; };
static void onPopError(WGPUPopErrorScopeStatus, WGPUErrorType type, WGPUStringView msg, void* u, void*) {
    auto* c = static_cast<PopContext*>(u);
    c->type = type;
    c->done = true;
    if (type != WGPUErrorType_NoError) {
        std::fprintf(stderr, "[WebGPU Error %d]: %.*s\n", (int)type, (int)msg.length, msg.data); std::fflush(stderr);
    }
}

// WGSL Header with common math, cnoise3, envelope, and transfer functions
static const char* kCommonWgslHeader = R"WGSL(
struct RayHeader {
    ro_clipA: vec4<f32>,
    rd_clipB: vec4<f32>,
    counts: vec4<u32>, // subpanelOffset, subpanelCount, overlapOffset, overlapCount
};

struct Subpanel {
    span: vec2<f32>, // s0, s1
    info: vec2<u32>, // mediumIndex, pad
};

struct OverlapInterval {
    span: vec2<f32>, // s0, s1
    info: vec2<u32>, // activeMask, pad
};

struct MediumParams {
    origin: vec4<f32>,
    color_alpha: vec4<f32>, // r, g, b, alpha
    freq_offset: vec4<f32>, // freq, paramOffset, pad, pad
};

struct GlobalUniforms {
    clock: f32,
    rayCount: u32,
    pad0: u32,
    pad1: u32,
};

struct ParameterBuffer {
    v: array<f32>,
};

@group(0) @binding(0) var<uniform> u: GlobalUniforms;
@group(0) @binding(1) var<storage, read> media: array<MediumParams>;
@group(0) @binding(2) var<storage, read> params: ParameterBuffer;
@group(0) @binding(3) var<storage, read> rays: array<RayHeader>;
@group(0) @binding(4) var<storage, read> subpanels: array<Subpanel>;
@group(0) @binding(5) var<storage, read> overlaps: array<OverlapInterval>;
@group(0) @binding(6) var<storage, read_write> results: array<vec4<f32>>;

fn mod289(x: vec4<f32>) -> vec4<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn mod289_3(x: vec3<f32>) -> vec3<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn permute4(x: vec4<f32>) -> vec4<f32> {
    return mod289(((x * 34.0) + 1.0) * x);
}
fn taylorInvSqrt(r: vec4<f32>) -> vec4<f32> {
    return 1.79284291400159 - 0.85373472095314 * r;
}

fn cnoise3(P: vec3<f32>) -> f32 {
    let Pi0 = floor(P);
    let Pi1 = Pi0 + vec3<f32>(1.0);
    let Pi0_mod = mod289_3(Pi0);
    let Pi1_mod = mod289_3(Pi1);
    let Pf0 = fract(P);
    let Pf1 = Pf0 - vec3<f32>(1.0);
    let ix = vec4<f32>(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
    let iy = vec4<f32>(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
    let iz0 = vec4<f32>(Pi0_mod.z);
    let iz1 = vec4<f32>(Pi1_mod.z);

    let ixy = permute4(permute4(ix) + iy);
    let ixy0 = permute4(ixy + iz0);
    let ixy1 = permute4(ixy + iz1);

    var gx0 = ixy0 / 7.0;
    var gy0 = fract(floor(gx0) / 7.0) - 0.5;
    gx0 = fract(gx0);
    var gz0 = vec4<f32>(0.5) - abs(gx0) - abs(gy0);
    let sz0 = step(gz0, vec4<f32>(0.0));
    gx0 = gx0 - sz0 * (step(vec4<f32>(0.0), gx0) - 0.5);
    gy0 = gy0 - sz0 * (step(vec4<f32>(0.0), gy0) - 0.5);

    var gx1 = ixy1 / 7.0;
    var gy1 = fract(floor(gx1) / 7.0) - 0.5;
    gx1 = fract(gx1);
    var gz1 = vec4<f32>(0.5) - abs(gx1) - abs(gy1);
    let sz1 = step(gz1, vec4<f32>(0.0));
    gx1 = gx1 - sz1 * (step(vec4<f32>(0.0), gx1) - 0.5);
    gy1 = gy1 - sz1 * (step(vec4<f32>(0.0), gy1) - 0.5);

    var g000 = vec3<f32>(gx0.x,gy0.x,gz0.x);
    var g100 = vec3<f32>(gx0.y,gy0.y,gz0.y);
    var g010 = vec3<f32>(gx0.z,gy0.z,gz0.z);
    var g110 = vec3<f32>(gx0.w,gy0.w,gz0.w);
    var g001 = vec3<f32>(gx1.x,gy1.x,gz1.x);
    var g101 = vec3<f32>(gx1.y,gy1.y,gz1.y);
    var g011 = vec3<f32>(gx1.z,gy1.z,gz1.z);
    var g111 = vec3<f32>(gx1.w,gy1.w,gz1.w);

    let norm0 = taylorInvSqrt(vec4<f32>(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));
    g000 = g000 * norm0.x;
    g010 = g010 * norm0.y;
    g100 = g100 * norm0.z;
    g110 = g110 * norm0.w;
    let norm1 = taylorInvSqrt(vec4<f32>(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));
    g001 = g001 * norm1.x;
    g011 = g011 * norm1.y;
    g101 = g101 * norm1.z;
    g111 = g111 * norm1.w;

    let n000 = dot(g000, Pf0);
    let n100 = dot(g100, vec3<f32>(Pf1.x, Pf0.y, Pf0.z));
    let n010 = dot(g010, vec3<f32>(Pf0.x, Pf1.y, Pf0.z));
    let n110 = dot(g110, vec3<f32>(Pf1.x, Pf1.y, Pf0.z));
    let n001 = dot(g001, vec3<f32>(Pf0.x, Pf0.y, Pf1.z));
    let n101 = dot(g101, vec3<f32>(Pf1.x, Pf0.y, Pf1.z));
    let n011 = dot(g011, vec3<f32>(Pf0.x, Pf1.y, Pf1.z));
    let n111 = dot(g111, Pf1);

    let fade_xyz = Pf0 * Pf0 * Pf0 * (Pf0 * (Pf0 * 6.0 - 15.0) + 10.0);
    let n_z = mix(vec4<f32>(n000, n100, n010, n110), vec4<f32>(n001, n101, n011, n111), fade_xyz.z);
    let n_yz = mix(n_z.xy, n_z.zw, fade_xyz.y);
    let n_xyz = mix(n_yz.x, n_yz.y, fade_xyz.x); 
    return 2.2 * n_xyz;
}

fn evalEnvelope(p: vec3<f32>, paramOffset: u32) -> f32 {
    let f0 = params.v[paramOffset + 0u];
    if (f0 == 0.0) { return 0.0; }
    let f1 = clamp(params.v[paramOffset + 1u] - select(0.0, abs(p.x) / params.v[paramOffset + 2u], abs(params.v[paramOffset + 2u]) >= 1e-06), params.v[paramOffset + 3u], params.v[paramOffset + 4u]);
    if (f1 == 0.0) { return 0.0; }
    let f2 = clamp(params.v[paramOffset + 5u] * (p.y + params.v[paramOffset + 6u]), params.v[paramOffset + 7u], params.v[paramOffset + 8u]);
    if (f2 == 0.0) { return 0.0; }
    let f3 = clamp(params.v[paramOffset + 9u] - select(0.0, (p.y + params.v[paramOffset + 11u]) / params.v[paramOffset + 10u], abs(params.v[paramOffset + 10u]) >= 1e-06), params.v[paramOffset + 12u], params.v[paramOffset + 13u]);
    if (f3 == 0.0) { return 0.0; }
    let z_curve = p.z + params.v[paramOffset + 16u] * sin(params.v[paramOffset + 17u] * p.x + params.v[paramOffset + 18u])
                      + params.v[paramOffset + 19u] * cos(params.v[paramOffset + 20u] * p.x + params.v[paramOffset + 21u])
                      + params.v[paramOffset + 22u] * sin(params.v[paramOffset + 23u] * p.x + params.v[paramOffset + 24u]);
    let f4 = clamp(params.v[paramOffset + 14u] - select(0.0, abs(z_curve) / params.v[paramOffset + 15u], abs(params.v[paramOffset + 15u]) >= 1e-06), params.v[paramOffset + 25u], params.v[paramOffset + 26u]);
    if (f4 == 0.0) { return 0.0; }
    let f5 = params.v[paramOffset + 27u] + params.v[paramOffset + 28u] * cos(params.v[paramOffset + 29u] * p.x + params.v[paramOffset + 30u])
                                         + params.v[paramOffset + 31u] * cos(params.v[paramOffset + 32u] * p.x + params.v[paramOffset + 33u]);
    if (f5 == 0.0) { return 0.0; }
    return f0 * f1 * f2 * f3 * f4 * f5;
}
)WGSL";

static const char* kOverlapWgsl=R"WGSL(
fn phiSafe(tau: f32) -> f32 {
    if (abs(tau) < 0.01) {
        return 1.0 + tau * (-0.5 + tau * (1.0/6.0 - tau/24.0));
    }
    return (1.0 - exp(-tau)) / tau;
}
fn projectedAt(ro: vec3<f32>, rd: vec3<f32>, s: f32, mask: u32) -> vec4<f32> {
    var result=vec4<f32>(0.0);
    for (var member=0u; member<arrayLength(&media); member+=1u) {
        if ((mask & (1u<<member))==0u) {continue;}
        let m=media[member];
        let local=ro+s*rd-m.origin.xyz;
        let env=evalEnvelope(local,u32(m.freq_offset.y));
        if (env<=0.0) {continue;}
        let D=env*clamp(0.7+0.3*cnoise3(m.freq_offset.x*local),0.0,1.0);
        if (D<=0.0) {continue;}
        let raw=m.color_alpha.w*D;
        result+=vec4<f32>(m.color_alpha.xyz*raw,max(raw,1e-6));
    }
    return result;
}
fn advanceFlow(state: vec4<f32>, sourceSigma: vec4<f32>, h: f32) -> vec4<f32> {
    let tau=h*sourceSigma.w;
    return vec4<f32>(state.xyz+state.w*sourceSigma.xyz*(h*phiSafe(tau)),state.w*exp(-tau));
}
fn advanceOverlap(stateIn: vec4<f32>, ro: vec3<f32>, rd: vec3<f32>, o: OverlapInterval) -> vec4<f32> {
    var state=stateIn;
    let h=(o.span.y-o.span.x)*0.5;
    let a=0.25-sqrt(3.0)/6.0;
    let b=0.5-a;
    for (var panel=0u; panel<2u; panel+=1u) {
        let lo=o.span.x+f32(panel)*h;
        let minus=projectedAt(ro,rd,lo+(0.5-sqrt(3.0)/6.0)*h,o.info.x);
        let plus=projectedAt(ro,rd,lo+(0.5+sqrt(3.0)/6.0)*h,o.info.x);
        state=advanceFlow(state,b*minus+a*plus,h);
        state=advanceFlow(state,a*minus+b*plus,h);
    }
    return state;
}
)WGSL";

// Pipeline 1: Unfused A* Shader
static const char* kUnfusedShader = R"WGSL(
@compute @workgroup_size(64)
fn rayMain(@builtin(global_invocation_id) gid: vec3<u32>) {
    let rayIdx = gid.x;
    if (rayIdx >= u.rayCount) { return; }

    let r = rays[rayIdx % arrayLength(&rays)];
    if((r.counts.w & 0x80000000u) != 0u){ return; }
    if((r.counts.w & 0x40000000u) != 0u){ return; }
    let ro = r.ro_clipA.xyz;
    let rd = r.rd_clipB.xyz;
    let subOffset = r.counts.x;
    let subCount = r.counts.y;
    let overOffset = r.counts.z;
    let overCount = r.counts.w;

    let gx0 = 0.5 * (1.0 - 0.5773502691896257);
    let gx1 = 0.5 * (1.0 + 0.5773502691896257);

    var T = 1.0;
    var L = vec3<f32>(0.0);

    // Two sorted streams must be consumed in ray order, including overlap.
    var single=0u;
    var overlap=0u;
    loop {
        if (single>=subCount && overlap>=overCount) {break;}
        var useOverlap=false;
        if (overlap<overCount) {
            if (single>=subCount) {useOverlap=true;}
            else {useOverlap=overlaps[overOffset+overlap].span.x<subpanels[subOffset+single].span.x;}
        }
        if (useOverlap) {
            let state=advanceOverlap(vec4<f32>(L,T),ro,rd,overlaps[overOffset+overlap]);
            L=state.xyz; T=state.w;
            overlap+=1u;
            continue;
        }
        let sub = subpanels[subOffset + single];
        single+=1u;
        let s0 = sub.span.x;
        let s1 = sub.span.y;
        let sub_h = s1 - s0;
        let mid = sub.info.x;
        let m = media[mid];
        let pOffset = u32(m.freq_offset.y);
        let freq = m.freq_offset.x;
        let alpha = m.color_alpha.w;
        let color = m.color_alpha.xyz;

        let s_m = s0 + gx0 * sub_h;
        let s_p = s0 + gx1 * sub_h;
        let w_m = ro + s_m * rd - m.origin.xyz;
        let w_p = ro + s_p * rd - m.origin.xyz;

        let env_m = evalEnvelope(w_m, pOffset);
        let env_p = evalEnvelope(w_p, pOffset);

        var D_m = 0.0;
        if (env_m > 0.0) {
            let nm = cnoise3(freq * w_m);
            D_m = env_m * clamp(0.7 + 0.3 * nm, 0.0, 1.0);
        }
        var D_p = 0.0;
        if (env_p > 0.0) {
            let np = cnoise3(freq * w_p);
            D_p = env_p * clamp(0.7 + 0.3 * np, 0.0, 1.0);
        }

        // Sixth-one Sun: Strict D > 0 gate
        let sig_m = select(0.0, max(alpha * D_m, 1e-6), D_m > 0.0);
        let em_m  = select(vec3<f32>(0.0), color * (alpha * D_m), D_m > 0.0);
        let sig_p = select(0.0, max(alpha * D_p, 1e-6), D_p > 0.0);
        let em_p  = select(vec3<f32>(0.0), color * (alpha * D_p), D_p > 0.0);

        let sig_avg = 0.5 * (sig_m + sig_p);
        let em_avg  = 0.5 * (em_m + em_p);
        let tau = sub_h * sig_avg;
        let atten = exp(-tau);

        // Sixth-one Sun: Numerically safe small-depth gain in f32
        var gain: f32;
        gain=sub_h*phiSafe(tau);

        L = L + T * em_avg * gain;
        T = T * atten;
    }

    results[rayIdx] = vec4<f32>(L, T);
}
)WGSL";

// Pipeline 2: Fused A* Shader (with Same-Cell 90.78% Gradient Sharing)
static const char* kFusedShader = R"WGSL(
fn cnoise3_fused(Pm: vec3<f32>, Pp: vec3<f32>) -> vec2<f32> {
    let Pi0_m = floor(Pm);
    let Pi0_p = floor(Pp);
    if (all(Pi0_m == Pi0_p)) {
        // --- SHARED 8 CORNER GRADIENTS ---
        let Pi0 = Pi0_m;
        let Pi1 = Pi0 + vec3<f32>(1.0);
        let Pi0_mod = mod289_3(Pi0);
        let Pi1_mod = mod289_3(Pi1);
        let ix = vec4<f32>(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
        let iy = vec4<f32>(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
        let iz0 = vec4<f32>(Pi0_mod.z);
        let iz1 = vec4<f32>(Pi1_mod.z);

        let ixy = permute4(permute4(ix) + iy);
        let ixy0 = permute4(ixy + iz0);
        let ixy1 = permute4(ixy + iz1);

        var gx0 = ixy0 / 7.0;
        var gy0 = fract(floor(gx0) / 7.0) - 0.5;
        gx0 = fract(gx0);
        var gz0 = vec4<f32>(0.5) - abs(gx0) - abs(gy0);
        let sz0 = step(gz0, vec4<f32>(0.0));
        gx0 = gx0 - sz0 * (step(vec4<f32>(0.0), gx0) - 0.5);
        gy0 = gy0 - sz0 * (step(vec4<f32>(0.0), gy0) - 0.5);

        var gx1 = ixy1 / 7.0;
        var gy1 = fract(floor(gx1) / 7.0) - 0.5;
        gx1 = fract(gx1);
        var gz1 = vec4<f32>(0.5) - abs(gx1) - abs(gy1);
        let sz1 = step(gz1, vec4<f32>(0.0));
        gx1 = gx1 - sz1 * (step(vec4<f32>(0.0), gx1) - 0.5);
        gy1 = gy1 - sz1 * (step(vec4<f32>(0.0), gy1) - 0.5);

        var g000 = vec3<f32>(gx0.x,gy0.x,gz0.x);
        var g100 = vec3<f32>(gx0.y,gy0.y,gz0.y);
        var g010 = vec3<f32>(gx0.z,gy0.z,gz0.z);
        var g110 = vec3<f32>(gx0.w,gy0.w,gz0.w);
        var g001 = vec3<f32>(gx1.x,gy1.x,gz1.x);
        var g101 = vec3<f32>(gx1.y,gy1.y,gz1.y);
        var g011 = vec3<f32>(gx1.z,gy1.z,gz1.z);
        var g111 = vec3<f32>(gx1.w,gy1.w,gz1.w);

        let norm0 = taylorInvSqrt(vec4<f32>(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));
        g000 = g000 * norm0.x;
        g010 = g010 * norm0.y;
        g100 = g100 * norm0.z;
        g110 = g110 * norm0.w;
        let norm1 = taylorInvSqrt(vec4<f32>(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));
        g001 = g001 * norm1.x;
        g011 = g011 * norm1.y;
        g101 = g101 * norm1.z;
        g111 = g111 * norm1.w;

        // Sample node m (s_-)
        let Pf0_m = fract(Pm);
        let Pf1_m = Pf0_m - vec3<f32>(1.0);
        let n000_m = dot(g000, Pf0_m);
        let n100_m = dot(g100, vec3<f32>(Pf1_m.x, Pf0_m.y, Pf0_m.z));
        let n010_m = dot(g010, vec3<f32>(Pf0_m.x, Pf1_m.y, Pf0_m.z));
        let n110_m = dot(g110, vec3<f32>(Pf1_m.x, Pf1_m.y, Pf0_m.z));
        let n001_m = dot(g001, vec3<f32>(Pf0_m.x, Pf0_m.y, Pf1_m.z));
        let n101_m = dot(g101, vec3<f32>(Pf1_m.x, Pf0_m.y, Pf1_m.z));
        let n011_m = dot(g011, vec3<f32>(Pf0_m.x, Pf1_m.y, Pf1_m.z));
        let n111_m = dot(g111, Pf1_m);
        let fade_m = Pf0_m * Pf0_m * Pf0_m * (Pf0_m * (Pf0_m * 6.0 - 15.0) + 10.0);
        let nz_m = mix(vec4<f32>(n000_m, n100_m, n010_m, n110_m), vec4<f32>(n001_m, n101_m, n011_m, n111_m), fade_m.z);
        let nyz_m = mix(nz_m.xy, nz_m.zw, fade_m.y);
        let val_m = 2.2 * mix(nyz_m.x, nyz_m.y, fade_m.x);

        // Sample node p (s_+)
        let Pf0_p = fract(Pp);
        let Pf1_p = Pf0_p - vec3<f32>(1.0);
        let n000_p = dot(g000, Pf0_p);
        let n100_p = dot(g100, vec3<f32>(Pf1_p.x, Pf0_p.y, Pf0_p.z));
        let n010_p = dot(g010, vec3<f32>(Pf0_p.x, Pf1_p.y, Pf0_p.z));
        let n110_p = dot(g110, vec3<f32>(Pf1_p.x, Pf1_p.y, Pf0_p.z));
        let n001_p = dot(g001, vec3<f32>(Pf0_p.x, Pf0_p.y, Pf1_p.z));
        let n101_p = dot(g101, vec3<f32>(Pf1_p.x, Pf0_p.y, Pf1_p.z));
        let n011_p = dot(g011, vec3<f32>(Pf0_p.x, Pf1_p.y, Pf1_p.z));
        let n111_p = dot(g111, Pf1_p);
        let fade_p = Pf0_p * Pf0_p * Pf0_p * (Pf0_p * (Pf0_p * 6.0 - 15.0) + 10.0);
        let nz_p = mix(vec4<f32>(n000_p, n100_p, n010_p, n110_p), vec4<f32>(n001_p, n101_p, n011_p, n111_p), fade_p.z);
        let nyz_p = mix(nz_p.xy, nz_p.zw, fade_p.y);
        let val_p = 2.2 * mix(nyz_p.x, nyz_p.y, fade_p.x);

        return vec2<f32>(val_m, val_p);
    } else {
        // Fallback for cross-cell (9.22%)
        return vec2<f32>(cnoise3(Pm), cnoise3(Pp));
    }
}

@compute @workgroup_size(64)
fn rayMain(@builtin(global_invocation_id) gid: vec3<u32>) {
    let rayIdx = gid.x;
    if (rayIdx >= u.rayCount) { return; }

    let r = rays[rayIdx % arrayLength(&rays)];
    if((r.counts.w & 0x80000000u) != 0u){ return; }
    if((r.counts.w & 0x40000000u) != 0u){ return; }
    let ro = r.ro_clipA.xyz;
    let rd = r.rd_clipB.xyz;
    let subOffset = r.counts.x;
    let subCount = r.counts.y;
    let overOffset = r.counts.z;
    let overCount = r.counts.w;

    let gx0 = 0.5 * (1.0 - 0.5773502691896257);
    let gx1 = 0.5 * (1.0 + 0.5773502691896257);

    var T = 1.0;
    var L = vec3<f32>(0.0);

    // Two sorted streams must be consumed in ray order, including overlap.
    var single=0u;
    var overlap=0u;
    loop {
        if (single>=subCount && overlap>=overCount) {break;}
        var useOverlap=false;
        if (overlap<overCount) {
            if (single>=subCount) {useOverlap=true;}
            else {useOverlap=overlaps[overOffset+overlap].span.x<subpanels[subOffset+single].span.x;}
        }
        if (useOverlap) {
            let state=advanceOverlap(vec4<f32>(L,T),ro,rd,overlaps[overOffset+overlap]);
            L=state.xyz; T=state.w;
            overlap+=1u;
            continue;
        }
        let sub = subpanels[subOffset + single];
        single+=1u;
        let s0 = sub.span.x;
        let s1 = sub.span.y;
        let sub_h = s1 - s0;
        let mid = sub.info.x;
        let m = media[mid];
        let pOffset = u32(m.freq_offset.y);
        let freq = m.freq_offset.x;
        let alpha = m.color_alpha.w;
        let color = m.color_alpha.xyz;

        let s_m = s0 + gx0 * sub_h;
        let s_p = s0 + gx1 * sub_h;
        let w_m = ro + s_m * rd - m.origin.xyz;
        let w_p = ro + s_p * rd - m.origin.xyz;

        let env_m = evalEnvelope(w_m, pOffset);
        let env_p = evalEnvelope(w_p, pOffset);

        var D_m = 0.0;
        var D_p = 0.0;
        if (env_m > 0.0 || env_p > 0.0) {
            let noises = cnoise3_fused(freq * w_m, freq * w_p);
            if (env_m > 0.0) { D_m = env_m * clamp(0.7 + 0.3 * noises.x, 0.0, 1.0); }
            if (env_p > 0.0) { D_p = env_p * clamp(0.7 + 0.3 * noises.y, 0.0, 1.0); }
        }

        // Sixth-one Sun: Strict D > 0 gate
        let sig_m = select(0.0, max(alpha * D_m, 1e-6), D_m > 0.0);
        let em_m  = select(vec3<f32>(0.0), color * (alpha * D_m), D_m > 0.0);
        let sig_p = select(0.0, max(alpha * D_p, 1e-6), D_p > 0.0);
        let em_p  = select(vec3<f32>(0.0), color * (alpha * D_p), D_p > 0.0);

        let sig_avg = 0.5 * (sig_m + sig_p);
        let em_avg  = 0.5 * (em_m + em_p);
        let tau = sub_h * sig_avg;
        let atten = exp(-tau);

        // Sixth-one Sun: Numerically safe small-depth gain in f32
        var gain: f32;
        gain=sub_h*phiSafe(tau);

        L = L + T * em_avg * gain;
        T = T * atten;
    }

    results[rayIdx] = vec4<f32>(L, T);
}
)WGSL";

static glm::vec4 mod289(glm::vec4 x) { return x - glm::floor(x * (1.0f / 289.0f)) * 289.0f; }
static glm::vec3 mod289(glm::vec3 x) { return x - glm::floor(x * (1.0f / 289.0f)) * 289.0f; }
static glm::vec4 permute4(glm::vec4 x) { return mod289(((x * 34.0f) + 1.0f) * x); }
static glm::vec4 taylorInvSqrt(glm::vec4 r) { return 1.79284291400159f - 0.85373472095314f * r; }

static float cnoise3_cpu(glm::vec3 P) {
    glm::vec3 Pi0 = glm::floor(P);
    glm::vec3 Pi1 = Pi0 + glm::vec3(1.0f);
    glm::vec3 Pi0_mod = mod289(Pi0);
    glm::vec3 Pi1_mod = mod289(Pi1);
    glm::vec3 Pf0 = glm::fract(P);
    glm::vec3 Pf1 = Pf0 - glm::vec3(1.0f);
    glm::vec4 ix(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
    glm::vec4 iy(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
    glm::vec4 iz0(Pi0_mod.z);
    glm::vec4 iz1(Pi1_mod.z);

    glm::vec4 ixy = permute4(permute4(ix) + iy);
    glm::vec4 ixy0 = permute4(ixy + iz0);
    glm::vec4 ixy1 = permute4(ixy + iz1);

    glm::vec4 gx0 = ixy0 * (1.0f / 7.0f);
    glm::vec4 gy0 = glm::fract(glm::floor(gx0) * (1.0f / 7.0f)) - 0.5f;
    gx0 = glm::fract(gx0);
    glm::vec4 gz0 = glm::vec4(0.5f) - glm::abs(gx0) - glm::abs(gy0);
    glm::vec4 sz0 = glm::step(gz0, glm::vec4(0.0f));
    gx0 = gx0 - sz0 * (glm::step(glm::vec4(0.0f), gx0) - 0.5f);
    gy0 = gy0 - sz0 * (glm::step(glm::vec4(0.0f), gy0) - 0.5f);

    glm::vec4 gx1 = ixy1 * (1.0f / 7.0f);
    glm::vec4 gy1 = glm::fract(glm::floor(gx1) * (1.0f / 7.0f)) - 0.5f;
    gx1 = glm::fract(gx1);
    glm::vec4 gz1 = glm::vec4(0.5f) - glm::abs(gx1) - glm::abs(gy1);
    glm::vec4 sz1 = glm::step(gz1, glm::vec4(0.0f));
    gx1 = gx1 - sz1 * (glm::step(glm::vec4(0.0f), gx1) - 0.5f);
    gy1 = gy1 - sz1 * (glm::step(glm::vec4(0.0f), gy1) - 0.5f);

    glm::vec3 g000(gx0.x, gy0.x, gz0.x);
    glm::vec3 g100(gx0.y, gy0.y, gz0.y);
    glm::vec3 g010(gx0.z, gy0.z, gz0.z);
    glm::vec3 g110(gx0.w, gy0.w, gz0.w);
    glm::vec3 g001(gx1.x, gy1.x, gz1.x);
    glm::vec3 g101(gx1.y, gy1.y, gz1.y);
    glm::vec3 g011(gx1.z, gy1.z, gz1.z);
    glm::vec3 g111(gx1.w, gy1.w, gz1.w);

    glm::vec4 norm0 = taylorInvSqrt(glm::vec4(glm::dot(g000, g000), glm::dot(g010, g010), glm::dot(g100, g100), glm::dot(g110, g110)));
    g000 *= norm0.x; g010 *= norm0.y; g100 *= norm0.z; g110 *= norm0.w;
    glm::vec4 norm1 = taylorInvSqrt(glm::vec4(glm::dot(g001, g001), glm::dot(g011, g011), glm::dot(g101, g101), glm::dot(g111, g111)));
    g001 *= norm1.x; g011 *= norm1.y; g101 *= norm1.z; g111 *= norm1.w;

    float n000 = glm::dot(g000, Pf0);
    float n100 = glm::dot(g100, glm::vec3(Pf1.x, Pf0.y, Pf0.z));
    float n010 = glm::dot(g010, glm::vec3(Pf0.x, Pf1.y, Pf0.z));
    float n110 = glm::dot(g110, glm::vec3(Pf1.x, Pf1.y, Pf0.z));
    float n001 = glm::dot(g001, glm::vec3(Pf0.x, Pf0.y, Pf1.z));
    float n101 = glm::dot(g101, glm::vec3(Pf1.x, Pf0.y, Pf1.z));
    float n011 = glm::dot(g011, glm::vec3(Pf0.x, Pf1.y, Pf1.z));
    float n111 = glm::dot(g111, Pf1);

    glm::vec3 fade_xyz = Pf0 * Pf0 * Pf0 * (Pf0 * (Pf0 * 6.0f - 15.0f) + 10.0f);
    glm::vec4 n_z = glm::mix(glm::vec4(n000, n100, n010, n110), glm::vec4(n001, n101, n011, n111), fade_xyz.z);
    glm::vec2 n_yz = glm::mix(glm::vec2(n_z.x, n_z.y), glm::vec2(n_z.z, n_z.w), fade_xyz.y);
    float n_xyz = glm::mix(n_yz.x, n_yz.y, fade_xyz.x);
    return 2.2f * n_xyz;
}

static float evalEnvelope_cpu(glm::vec3 p, const float* v) {
    float f0 = v[0];
    if (f0 == 0.0f) return 0.0f;
    float f1 = std::clamp(v[1] - (std::abs(v[2]) >= 1e-6f ? std::abs(p.x) / v[2] : 0.0f), v[3], v[4]);
    if (f1 == 0.0f) return 0.0f;
    float f2 = std::clamp(v[5] * (p.y + v[6]), v[7], v[8]);
    if (f2 == 0.0f) return 0.0f;
    float f3 = std::clamp(v[9] - (std::abs(v[10]) >= 1e-6f ? (p.y + v[11]) / v[10] : 0.0f), v[12], v[13]);
    if (f3 == 0.0f) return 0.0f;
    float z_curve = p.z + v[16] * std::sin(v[17] * p.x + v[18])
                        + v[19] * std::cos(v[20] * p.x + v[21])
                        + v[22] * std::sin(v[23] * p.x + v[24]);
    float f4 = std::clamp(v[14] - (std::abs(v[15]) >= 1e-6f ? std::abs(z_curve) / v[15] : 0.0f), v[25], v[26]);
    if (f4 == 0.0f) return 0.0f;
    float f5 = v[27] + v[28] * std::cos(v[29] * p.x + v[30])
                     + v[31] * std::cos(v[32] * p.x + v[33]);
    if (f5 == 0.0f) return 0.0f;
    return f0 * f1 * f2 * f3 * f4 * f5;
}

static J stats(std::vector<double> e) {
    if (e.empty()) return J{{"mean", 0.0}, {"rms", 0.0}, {"min", 0.0}, {"p50", 0.0}, {"p90", 0.0}, {"p99", 0.0}, {"max", 0.0}};
    std::sort(e.begin(), e.end());
    double sum = 0, sq = 0;
    for (double x : e) { sum += x; sq += x * x; }
    size_t n = e.size();
    return J{
        {"mean", sum / n},
        {"rms", std::sqrt(sq / n)},
        {"min", e.front()},
        {"p50", e[n * 50 / 100]},
        {"p90", e[n * 90 / 100]},
        {"p99", e[n * 99 / 100]},
        {"max", e.back()}
    };
}


// Scratch admission for an original shared mathematical factor. No spatial
// samples are used to infer proportionality. Future reusable derivation belongs
// to OntoMath; these pinned backend diagnostics grant no omission authority.
static double literalCoefficient(const OntoMath::MathNode& n){
    if(n.op!=OntoMath::MathNode::Op::ScalarLeaf||n.unsupported||!n.children.empty()||n.scalarForm.terms.size()!=1)
        throw std::runtime_error("coefficient is not a literal scalar");
    const auto& term=n.scalarForm.terms[0];
    if(!term.factors.empty()||!term.trans.empty()||!std::isfinite(term.coefficient)||!(term.coefficient>0))
        throw std::runtime_error("coefficient requires a positive finite literal");
    return term.coefficient;
}
static void legacyBindOriginalCoefficients(Medium& m,double clock){
    for(auto n:{m.density,m.sigma,m.emission})
        if(!n||n->op!=OntoMath::MathNode::Op::Scale||n->unsupported||n->children.size()!=2||!n->children[0]||!n->children[1])
            throw std::runtime_error("transport common-factor shape refused");
    const double cD=literalCoefficient(*m.density->children[0]);
    const double cX=literalCoefficient(*m.sigma->children[0]);
    const auto B=m.density->children[1]->toJson();
    if(B!=m.sigma->children[1]->toJson()||B!=m.emission->children[0]->toJson())
        throw std::runtime_error("original common-factor subtrees differ");
    const auto& V=*m.emission->children[1];std::set<std::string> deps;V.collectDependencies(deps);
    for(const auto& dep:deps)if(dep!=OntoMath::kTimeVar)
        throw std::runtime_error("emission coefficient is not time-only");
    const auto value=V.evaluate({{OntoMath::kTimeVar,PropertyValue(clock)}});
    if(!value||!std::holds_alternative<glm::vec3>(*value))throw std::runtime_error("time-only vector evaluation refused");
    const auto v=std::get<glm::vec3>(*value);
    for(int k=0;k<3;++k)if(!std::isfinite(v[k])||v[k]<0)throw std::runtime_error("emission coefficient invalid");
    m.alpha=float(cX/cD);m.color=v/float(cX);
}


static OntoMath::CommonScalarFactor deriveOriginalCoefficients(const Medium& m){
    if(!m.density||!m.sigma||!m.emission)throw std::runtime_error("missing original channels");
    // Screen owns this diagnostic consumer's positive-literal policy, not the
    // generic factor office. No computed divisor/exponent admission is added.
    if(m.density->op!=M::Op::Scale||m.sigma->op!=M::Op::Scale||m.emission->op!=M::Op::Scale||
       m.density->children.size()!=2||m.sigma->children.size()!=2||m.emission->children.size()!=2||
       !m.density->children[0]||!m.sigma->children[0])throw std::runtime_error("transport source shape refused");
    literalCoefficient(*m.density->children[0]);literalCoefficient(*m.sigma->children[0]);
    OntoMath::TypeEnv env={{"p",OntoMath::ValueKind::Vector},{"x",OntoMath::ValueKind::Scalar},
        {"y",OntoMath::ValueKind::Scalar},{"z",OntoMath::ValueKind::Scalar},{OntoMath::kTimeVar,OntoMath::ValueKind::Scalar}};
    std::string why;auto recipe=OntoMath::factorCommonScalar({m.density,m.sigma,m.emission},env,{OntoMath::kTimeVar},&why);
    if(!recipe||recipe->factorChild!=std::vector<unsigned>({1,1,0}))
        throw std::runtime_error("transport factor recipe refused: "+why);
    if(recipe->coefficients[2].typeOf(env).kind!=OntoMath::ValueKind::Vector)
        throw std::runtime_error("transport coefficient must be vector");
    return std::move(*recipe);
}
static void prepareOriginalCoefficients(Medium& m,const OntoMath::CommonScalarFactor& recipe,double clock){
    if(!std::isfinite(clock))throw std::runtime_error("nonfinite explicit clock");
    std::string why;const auto values=OntoMath::evaluateFactorCoefficients(recipe,{{OntoMath::kTimeVar,PropertyValue(clock)}},&why);
    if(!values||values->size()!=3||!std::holds_alternative<glm::vec3>((*values)[2]))
        throw std::runtime_error("coefficient preparation refused: "+why);
    const auto cD=literalCoefficient(recipe.coefficients[0]);const auto cX=literalCoefficient(recipe.coefficients[1]);
    const auto v=std::get<glm::vec3>((*values)[2]);
    const float alpha=float(cX/cD),sigma=float(cX);const auto color=v/sigma;
    if(!(alpha>0)||!std::isfinite(alpha)||!(sigma>0)||!std::isfinite(sigma))throw std::runtime_error("backend scalar conversion refused");
    for(int k=0;k<3;++k)if(!std::isfinite(color[k])||color[k]<0)throw std::runtime_error("backend color conversion refused");
    m.alpha=alpha;m.color=color;
}
// Compatibility entry for the existing refusal witness: fresh admission each
// call. Actual main below keeps owned recipes for separate clock preparation.
static void bindOriginalCoefficients(Medium& m,double clock){
    auto recipe=deriveOriginalCoefficients(m);prepareOriginalCoefficients(m,recipe,clock);
}


static const char* kResetCountersWgsl = R"WGSL(
struct DispatchCounters {
    s1Count: atomic<u32>,
    s2Count: atomic<u32>,
    fallbackCount: atomic<u32>,
    pad0: u32,
};

@group(0) @binding(0) var<storage, read_write> counters: DispatchCounters;

@compute @workgroup_size(1, 1, 1)
fn resetCountersMain(@builtin(global_invocation_id) gid: vec3u) {
    atomicStore(&counters.s1Count, 0u);
    atomicStore(&counters.s2Count, 0u);
    atomicStore(&counters.fallbackCount, 0u);
}
)WGSL";
static const char* kClassifyWgsl = R"WGSL(
struct CurtainSpec {
    origin: vec4f,
    half: vec4f,
    limits: vec4f,
    curv: vec4f,
    amps: vec4f,
    freqs: vec4f,
    phases: vec4f,
};

struct Ray {
    ro_clipA: vec4f,
    rd_clipB: vec4f,
    counts: vec4u,
};

struct DispatchCounters {
    s1Count: atomic<u32>,
    s2Count: atomic<u32>,
    fallbackCount: atomic<u32>,
    pad0: u32,
};

@group(0) @binding(0) var<storage, read> curtains: array<CurtainSpec, 4>;
@group(0) @binding(1) var<storage, read> rays: array<Ray>;
@group(0) @binding(2) var<storage, read> tileOffsets: array<u32>;
@group(0) @binding(3) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(4) var<storage, read_write> s1TileList: array<u32>;
@group(0) @binding(5) var<storage, read_write> s2TileList: array<u32>;
@group(0) @binding(6) var<storage, read_write> fallbackTileList: array<u32>;
@group(0) @binding(7) var<storage, read_write> counters: DispatchCounters;

fn evalWave(cur: CurtainSpec, x: f32) -> f32 {
    return cur.amps.x * sin(cur.freqs.x * x + cur.phases.x) +
           cur.amps.y * cos(cur.freqs.y * x + cur.phases.y) +
           cur.amps.z * sin(cur.freqs.z * x + cur.phases.z);
}

@compute @workgroup_size(64, 1, 1)
fn classifyTilesMain(@builtin(global_invocation_id) gid: vec3u) {
    let tileId = gid.x;
    let totalTiles = arrayLength(&tileOffsets) - 1u;
    if (tileId >= totalTiles) { return; }

    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;

    var activeMemberMask = 0u;
    var tileCanOverlap = false;
    var enterArr: array<f32, 4>;
    var exitArr: array<f32, 4>;
    var memberHit: array<bool, 4>;

    for (var m = 0u; m < 4u; m++) {
        let cur = curtains[m];
        var uxMin = 1e9f;
        var uxMax = -1e9f;
        var anyRayHit = false;
        var rA: array<f32, 16>;
        var rB: array<f32, 16>;
        var rHit: array<bool, 16>;

        for (var i = 0u; i < rayCount && i < 16u; i++) {
            let rIdx = tileRayIndices[rayStart + i];
            let ray = rays[rIdx];
            let oRel = ray.ro_clipA.xyz - cur.origin.xyz;
            var a = ray.ro_clipA.w;
            var b = ray.rd_clipB.w;
            var hit = true;

            for (var axis = 0; axis < 3; axis++) {
                var half = cur.half[axis];
                if (axis == 0) { half = min(half, cur.limits.x); }
                if (axis == 1) { half = min(half, cur.limits.y); }
                let d = ray.rd_clipB[axis];
                let o = oRel[axis];
                if (d == 0.0) {
                    if (abs(o) > half + cur.curv.y) { hit = false; break; }
                } else {
                    let q0 = (-half - cur.curv.y - o) / d;
                    let q1 = (half + cur.curv.y - o) / d;
                    a = max(a, min(q0, q1));
                    b = min(b, max(q0, q1));
                }
            }

            rA[i] = a;
            rB[i] = b;
            rHit[i] = (hit && b > a);

            if (hit && b > a) {
                anyRayHit = true;
                let u0 = oRel.x + a * ray.rd_clipB.x;
                let u1 = oRel.x + b * ray.rd_clipB.x;
                uxMin = min(uxMin, min(u0, u1));
                uxMax = max(uxMax, max(u0, u1));
            }
        }

        if (anyRayHit && uxMax > uxMin) {
            var wKnots: array<f32, 9>;
            for (var k = 0u; k < 9u; k++) {
                let ux = uxMin + f32(k) / 8.0 * (uxMax - uxMin);
                wKnots[k] = evalWave(cur, ux);
            }
            let h_ux = (uxMax - uxMin) / 8.0;
            let bow = 0.125 * cur.curv.x * h_ux * h_ux;
            let thresh = bow + cur.limits.w + 0.001;

            var enter = 1e9f;
            var exit = -1e9f;
            var curActive = false;

            for (var i = 0u; i < rayCount && i < 16u; i++) {
                if (!rHit[i]) { continue; }
                let rIdx = tileRayIndices[rayStart + i];
                let ray = rays[rIdx];
                let oRel = ray.ro_clipA.xyz - cur.origin.xyz;
                let dx = ray.rd_clipB.x;
                if (abs(dx) < 1e-6) { curActive = true; enter = min(enter, rA[i]); exit = max(exit, rB[i]); break; }

                let a = rA[i];
                let b = rB[i];

                for (var bin = 0u; bin < 8u; bin++) {
                    let u0 = uxMin + f32(bin) / 8.0 * (uxMax - uxMin);
                    let u1 = uxMin + f32(bin + 1u) / 8.0 * (uxMax - uxMin);
                    let su0 = (u0 - oRel.x) / dx;
                    let su1 = (u1 - oRel.x) / dx;
                    let phi0 = oRel.z + su0 * ray.rd_clipB.z + wKnots[bin];
                    let phi1 = oRel.z + su1 * ray.rd_clipB.z + wKnots[bin + 1u];

                    let sMin = min(su0, su1);
                    let sMax = max(su0, su1);
                    let cLo = max(a, sMin);
                    let cHi = min(b, sMax);

                    if (cHi > cLo) {
                        let tA = (cLo - su0) / (su1 - su0);
                        let tB = (cHi - su0) / (su1 - su0);
                        let pA = phi0 + tA * (phi1 - phi0);
                        let pB = phi0 + tB * (phi1 - phi0);

                        if (!(min(pA, pB) > thresh || max(pA, pB) < -thresh)) {
                            curActive = true;
                            enter = min(enter, cLo);
                            exit = max(exit, cHi);
                        }
                    }
                }
            }

            if (curActive) {
                activeMemberMask |= (1u << m);
                memberHit[m] = true;
                enterArr[m] = enter;
                exitArr[m] = exit;
            }
        } else if (anyRayHit) {
            // No intrinsic interval was established (e.g. exactly dx=0).
            // Unknown support remains active; never infer empty from zero width.
            activeMemberMask |= (1u << m);
            memberHit[m] = true;
            var enter = 1e9f; var exit = -1e9f;
            for (var i = 0u; i < rayCount && i < 16u; i++) {
                if (rHit[i]) { enter = min(enter, rA[i]); exit = max(exit, rB[i]); }
            }
            enterArr[m] = enter; exitArr[m] = exit;
        }
    }

    let activeCount = countOneBits(activeMemberMask);
    if (activeCount > 1u) {
        for (var m1 = 0u; m1 < 4u; m1++) {
            if (!memberHit[m1]) { continue; }
            for (var m2 = m1 + 1u; m2 < 4u; m2++) {
                if (!memberHit[m2]) { continue; }
                let lo = max(enterArr[m1], enterArr[m2]);
                let hi = min(exitArr[m1], exitArr[m2]);
                if (hi > lo) { tileCanOverlap = true; }
            }
        }
    }

    if (activeMemberMask == 1u && !tileCanOverlap) {
        let slot = atomicAdd(&counters.s1Count, 1u);
        s1TileList[slot] = tileId;
    } else if (activeMemberMask == 3u && !tileCanOverlap && exitArr[0u] <= enterArr[1u]) {
        let slot = atomicAdd(&counters.s2Count, 1u);
        s2TileList[slot] = tileId;
    } else {
        let slot = atomicAdd(&counters.fallbackCount, 1u);
        fallbackTileList[slot] = tileId;
    }
}
)WGSL";
static const char* kRouteArgsWgsl = R"WGSL(
@group(0) @binding(0) var<storage, read> counts: array<u32>;
@group(0) @binding(1) var<storage, read_write> args: array<u32>;
@compute @workgroup_size(1) fn routeArgs(@builtin(global_invocation_id) id: vec3u) {
    if (id.x >= 3u) { return; }
    let n = counts[id.x];
    args[3u * id.x] = (n + 3u) / 4u;
    args[3u * id.x + 1u] = 1u;
    args[3u * id.x + 2u] = 1u;
}
)WGSL";
static const char* kS1UnfusedProducerWgsl = R"WGSL(

struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 15>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 15u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> s1TileList: array<u32>;
@group(0) @binding(8) var<storage, read> routeCounts: array<u32>;

@compute @workgroup_size(64, 1, 1)
fn s1ProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let totalTiles = arrayLength(&tileOffsets) - 1u;
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts[0u], totalTiles)) { return; }
    let tileId = s1TileList[tileSlot];
    if (tileId >= totalTiles) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 1u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  var allPositiveH = true;
  let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
  let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
  let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
  if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
   if (work + 24u > cfg.budget) { reason |= 1u; break; }
   work += 24u;
   memCount[member] = 0u;
   continue;
  }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); return; }
 var singles = 0u;
 for (var p = 0u; p < count; p++) {
  let a = pieces[p].x; let b = pieces[p].y;
  let n = max(1u, u32(ceil((b - a) / 4.0)));
  if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
  for (var k = 0u; k < n; k++) {
   let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
   let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
   subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(0u, 0u)); singles++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, 0u); }
}
)WGSL";
static const char* kS1TerminalProducerWgsl = R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
struct MediumParams {
    origin: vec4<f32>,
    color_alpha: vec4<f32>,
    freq_offset: vec4<f32>,
};
struct ParameterBuffer {
    v: array<f32>,
};
@group(0) @binding(4) var<storage, read_write> results: array<vec4<f32>>;
@group(0) @binding(9) var<storage, read> media: array<MediumParams>;
@group(0) @binding(10) var<storage, read> params: ParameterBuffer;

fn mod289(x: vec4<f32>) -> vec4<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn mod289_3(x: vec3<f32>) -> vec3<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn permute4(x: vec4<f32>) -> vec4<f32> {
    return mod289(((x * 34.0) + 1.0) * x);
}
fn taylorInvSqrt(r: vec4<f32>) -> vec4<f32> {
    return 1.79284291400159 - 0.85373472095314 * r;
}

fn cnoise3(P: vec3<f32>) -> f32 {
    let Pi0 = floor(P);
    let Pi1 = Pi0 + vec3<f32>(1.0);
    let Pi0_mod = mod289_3(Pi0);
    let Pi1_mod = mod289_3(Pi1);
    let Pf0 = fract(P);
    let Pf1 = Pf0 - vec3<f32>(1.0);
    let ix = vec4<f32>(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
    let iy = vec4<f32>(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
    let iz0 = vec4<f32>(Pi0_mod.z);
    let iz1 = vec4<f32>(Pi1_mod.z);

    let ixy = permute4(permute4(ix) + iy);
    let ixy0 = permute4(ixy + iz0);
    let ixy1 = permute4(ixy + iz1);

    var gx0 = ixy0 / 7.0;
    var gy0 = fract(floor(gx0) / 7.0) - 0.5;
    gx0 = fract(gx0);
    var gz0 = vec4<f32>(0.5) - abs(gx0) - abs(gy0);
    let sz0 = step(gz0, vec4<f32>(0.0));
    gx0 = gx0 - sz0 * (step(vec4<f32>(0.0), gx0) - 0.5);
    gy0 = gy0 - sz0 * (step(vec4<f32>(0.0), gy0) - 0.5);

    var gx1 = ixy1 / 7.0;
    var gy1 = fract(floor(gx1) / 7.0) - 0.5;
    gx1 = fract(gx1);
    var gz1 = vec4<f32>(0.5) - abs(gx1) - abs(gy1);
    let sz1 = step(gz1, vec4<f32>(0.0));
    gx1 = gx1 - sz1 * (step(vec4<f32>(0.0), gx1) - 0.5);
    gy1 = gy1 - sz1 * (step(vec4<f32>(0.0), gy1) - 0.5);

    var g000 = vec3<f32>(gx0.x,gy0.x,gz0.x);
    var g100 = vec3<f32>(gx0.y,gy0.y,gz0.y);
    var g010 = vec3<f32>(gx0.z,gy0.z,gz0.z);
    var g110 = vec3<f32>(gx0.w,gy0.w,gz0.w);
    var g001 = vec3<f32>(gx1.x,gy1.x,gz1.x);
    var g101 = vec3<f32>(gx1.y,gy1.y,gz1.y);
    var g011 = vec3<f32>(gx1.z,gy1.z,gz1.z);
    var g111 = vec3<f32>(gx1.w,gy1.w,gz1.w);

    let norm0 = taylorInvSqrt(vec4<f32>(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));
    g000 = g000 * norm0.x;
    g010 = g010 * norm0.y;
    g100 = g100 * norm0.z;
    g110 = g110 * norm0.w;
    let norm1 = taylorInvSqrt(vec4<f32>(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));
    g001 = g001 * norm1.x;
    g011 = g011 * norm1.y;
    g101 = g101 * norm1.z;
    g111 = g111 * norm1.w;

    let n000 = dot(g000, Pf0);
    let n100 = dot(g100, vec3<f32>(Pf1.x, Pf0.y, Pf0.z));
    let n010 = dot(g010, vec3<f32>(Pf0.x, Pf1.y, Pf0.z));
    let n110 = dot(g110, vec3<f32>(Pf1.x, Pf1.y, Pf0.z));
    let n001 = dot(g001, vec3<f32>(Pf0.x, Pf0.y, Pf1.z));
    let n101 = dot(g101, vec3<f32>(Pf1.x, Pf0.y, Pf1.z));
    let n011 = dot(g011, vec3<f32>(Pf0.x, Pf1.y, Pf1.z));
    let n111 = dot(g111, Pf1);

    let fade_xyz = Pf0 * Pf0 * Pf0 * (Pf0 * (Pf0 * 6.0 - 15.0) + 10.0);
    let n_z = mix(vec4<f32>(n000, n100, n010, n110), vec4<f32>(n001, n101, n011, n111), fade_xyz.z);
    let n_yz = mix(n_z.xy, n_z.zw, fade_xyz.y);
    let n_xyz = mix(n_yz.x, n_yz.y, fade_xyz.x); 
    return 2.2 * n_xyz;
}

fn evalEnvelope(p: vec3<f32>, paramOffset: u32) -> f32 {
    let f0 = params.v[paramOffset + 0u];
    if (f0 == 0.0) { return 0.0; }
    let f1 = clamp(params.v[paramOffset + 1u] - select(0.0, abs(p.x) / params.v[paramOffset + 2u], abs(params.v[paramOffset + 2u]) >= 1e-06), params.v[paramOffset + 3u], params.v[paramOffset + 4u]);
    if (f1 == 0.0) { return 0.0; }
    let f2 = clamp(params.v[paramOffset + 5u] * (p.y + params.v[paramOffset + 6u]), params.v[paramOffset + 7u], params.v[paramOffset + 8u]);
    if (f2 == 0.0) { return 0.0; }
    let f3 = clamp(params.v[paramOffset + 9u] - select(0.0, (p.y + params.v[paramOffset + 11u]) / params.v[paramOffset + 10u], abs(params.v[paramOffset + 10u]) >= 1e-06), params.v[paramOffset + 12u], params.v[paramOffset + 13u]);
    if (f3 == 0.0) { return 0.0; }
    let z_curve = p.z + params.v[paramOffset + 16u] * sin(params.v[paramOffset + 17u] * p.x + params.v[paramOffset + 18u])
                      + params.v[paramOffset + 19u] * cos(params.v[paramOffset + 20u] * p.x + params.v[paramOffset + 21u])
                      + params.v[paramOffset + 22u] * sin(params.v[paramOffset + 23u] * p.x + params.v[paramOffset + 24u]);
    let f4 = clamp(params.v[paramOffset + 14u] - select(0.0, abs(z_curve) / params.v[paramOffset + 15u], abs(params.v[paramOffset + 15u]) >= 1e-06), params.v[paramOffset + 25u], params.v[paramOffset + 26u]);
    if (f4 == 0.0) { return 0.0; }
    let f5 = params.v[paramOffset + 27u] + params.v[paramOffset + 28u] * cos(params.v[paramOffset + 29u] * p.x + params.v[paramOffset + 30u])
                                         + params.v[paramOffset + 31u] * cos(params.v[paramOffset + 32u] * p.x + params.v[paramOffset + 33u]);
    if (f5 == 0.0) { return 0.0; }
    return f0 * f1 * f2 * f3 * f4 * f5;
}

fn phiSafe(tau: f32) -> f32 {
    if (abs(tau) < 0.01) {
        return 1.0 + tau * (-0.5 + tau * (1.0/6.0 - tau/24.0));
    }
    return (1.0 - exp(-tau)) / tau;
}

const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 15>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 15u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> s1TileList: array<u32>;
@group(0) @binding(8) var<uniform> routeCounts: vec4u;

@compute @workgroup_size(64, 1, 1)
fn s1ProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let totalTiles = arrayLength(&tileOffsets) - 1u;
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts.x, totalTiles)) { return; }
    let tileId = s1TileList[tileSlot];
    if (tileId >= totalTiles) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
    let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
    var reason = 0u; var work = 0u; var count = 0u;
    var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
    var knots: array<f32, 96>;
    var memStart = vec4u(0u); var memCount = vec4u(0u);
    if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
    let gx0 = 0.5 * (1.0 - 0.5773502691896257);
    let gx1 = 0.5 * (1.0 + 0.5773502691896257);
    var T = 1.0;
    var L = vec3<f32>(0.0);

    for (var member = 0u; member < 1u; member++) {
        memStart[member] = count;
        let m = curtains[member]; let o = ro - m.origin.xyz;
        var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
        for (var axis = 0u; axis < 3u; axis++) {
            var half = m.half[axis];
            if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
            if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
            else {
                let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
                a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
            }
        }
        if (!hit || !(b > a)) { continue; }
        var phi_knots: array<f32, 9>;
        for (var k = 0u; k < 9u; k++) {
            var s = a + (b - a) * f32(k) / 8.0;
            if (k == 0u) { s = a; } if (k == 8u) { s = b; }
            phi_knots[k] = evalPhi(m, o, d, s);
        }
        var allPositiveH = true;
        let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
        let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
        let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
        if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
            if (work + 24u > cfg.budget) { reason |= 1u; break; }
            work += 24u;
            memCount[member] = 0u;
            continue;
        }
        var nb = 1u; knots[0] = a;
        var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
        roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
        if (reason != 0u) { break; }
        if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
        if (d.y != 0.0) {
            let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
            let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
        }
        knots[nb] = b; nb++;
        for (var i = 1u; i < nb; i++) {
            let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
            knots[j] = v;
        }
        let memberStart = count; var previousShortBand = false; var previousPositive = false;
        for (var i = 1u; i < nb; i++) {
            let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
            let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
            if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
            if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
            for (var k = 0u; k < nr; k++) {
                uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
                if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
            }
            if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
                if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
                     previousShortBand, previousPositive, uncertain, protectedBoundary)) {
                    pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
                } else {
                    if (count >= 48u) { reason |= 8u; break; }
                    pieces[count] = vec2f(l, r);
                    setMember(&pieceMembers, count, member);
                    count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
                }
            }
        }
        memCount[member] = count - memStart[member];
        if (reason != 0u) { break; }
    }
    if (reason != 0u) {
        rays[id].counts = vec4u(subBase, 0u, overBase, FALLBACK | reason);
        return;
    }
    // 1. Pre-check total subpanel count across finalized pieces[0..count-1] BEFORE any quadrature:
    var singles = 0u;
    for (var p = 0u; p < count; p++) {
        let pa = pieces[p].x;
        let pb = pieces[p].y;
        let n = max(1u, u32(ceil((pb - pa) / 4.0)));
        if (singles + n > cfg.maxSubPerRay) {
            reason |= 16u;
            break;
        }
        singles += n;
    }
    if (reason != 0u) {
        rays[id].counts = vec4u(subBase, 0u, overBase, FALLBACK | reason);
        return;
    }

    // 2. Subdivide pieces[0..count-1] directly in scalar registers and integrate (ZERO global sBuf writes/reads!):
    let rd = d;
    let m = media[0u];
    let pOffset = u32(m.freq_offset.y);
    let freq = m.freq_offset.x;
    let alpha = m.color_alpha.w;
    let color = m.color_alpha.xyz;

    for (var p = 0u; p < count; p++) {
        let pa = pieces[p].x;
        let pb = pieces[p].y;
        let n = max(1u, u32(ceil((pb - pa) / 4.0)));
        for (var k = 0u; k < n; k++) {
            let s0 = select(pa + f32(k) * (pb - pa) / f32(n), pa, k == 0u);
            let s1 = select(pa + f32(k + 1u) * (pb - pa) / f32(n), pb, k + 1u == n);
            let sub_h = s1 - s0;

            let s_m = s0 + gx0 * sub_h;
            let s_p = s0 + gx1 * sub_h;
            let w_m = ro + s_m * rd - m.origin.xyz;
            let w_p = ro + s_p * rd - m.origin.xyz;

            let env_m = evalEnvelope(w_m, pOffset);
            let env_p = evalEnvelope(w_p, pOffset);

            var D_m = 0.0;
            if (env_m > 0.0) {
                let nm = cnoise3(freq * w_m);
                D_m = env_m * clamp(0.7 + 0.3 * nm, 0.0, 1.0);
            }
            var D_p = 0.0;
            if (env_p > 0.0) {
                let np = cnoise3(freq * w_p);
                D_p = env_p * clamp(0.7 + 0.3 * np, 0.0, 1.0);
            }

            let sig_m = select(0.0, max(alpha * D_m, 1e-6), D_m > 0.0);
            let em_m  = select(vec3<f32>(0.0), color * (alpha * D_m), D_m > 0.0);
            let sig_p = select(0.0, max(alpha * D_p, 1e-6), D_p > 0.0);
            let em_p  = select(vec3<f32>(0.0), color * (alpha * D_p), D_p > 0.0);

            let sig_avg = 0.5 * (sig_m + sig_p);
            let em_avg  = 0.5 * (em_m + em_p);
            let tau = sub_h * sig_avg;
            let atten = exp(-tau);

            var gain: f32;
            gain = sub_h * phiSafe(tau);

            L = L + T * em_avg * gain;
            T = T * atten;
        }
    }
    results[id] = vec4<f32>(L, T);
    rays[id].counts = vec4u(subBase, singles, overBase, 0x40000000u);
}
)WGSL";
static const char* kS2ProducerWgsl = R"WGSL(

struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> s2TileList: array<u32>;
@group(0) @binding(8) var<storage, read> routeCounts: array<u32>;

@compute @workgroup_size(64, 1, 1)
fn s2ProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let totalTiles = arrayLength(&tileOffsets) - 1u;
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts[1u], totalTiles)) { return; }
    let tileId = s2TileList[tileSlot];
    if (tileId >= totalTiles) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    
    let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
    let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
    var reason = 0u; var work = 0u; var count = 0u;
    var pieces: array<vec2f, 48>;
    var knots: array<f32, 96>;
    if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }

    var singles = 0u;
    for (var member = 0u; member < 2u; member++) {
        let m = curtains[member]; let o = ro - m.origin.xyz;
        var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
        for (var axis = 0u; axis < 3u; axis++) {
            var half = m.half[axis];
            if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
            if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
            else {
                let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
                a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
            }
        }
        if (!hit || !(b > a)) { continue; }
        var phi_knots: array<f32, 9>;
        for (var k = 0u; k < 9u; k++) {
            var s = a + (b - a) * f32(k) / 8.0;
            if (k == 0u) { s = a; } if (k == 8u) { s = b; }
            phi_knots[k] = evalPhi(m, o, d, s);
        }
        var allPositiveH = true;
        let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
        let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
        let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
        if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
            if (work + 24u > cfg.budget) { reason |= 1u; break; }
            work += 24u;
            continue;
        }
        var nb = 1u; knots[0] = a;
        var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
        roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
        if (reason != 0u) { break; }
        if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
        if (d.y != 0.0) {
            let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
            let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
        }
        knots[nb] = b; nb++;
        for (var i = 1u; i < nb; i++) {
            let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
            knots[j] = v;
        }
        var memPieces = 0u;
        var previousShortBand = false; var previousPositive = false;
        for (var i = 1u; i < nb; i++) {
            let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
            let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
            if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
            if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
            for (var k = 0u; k < nr; k++) {
                uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
                if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
            }
            if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
                if (memPieces > 0u && mayAbsorb(pieces[memPieces - 1u], vec2f(l, r),
                     previousShortBand, previousPositive, uncertain, protectedBoundary)) {
                    pieces[memPieces - 1u].y = r; previousShortBand = false; previousPositive = true;
                } else {
                    // Capacity is shared across both members in the bulk producer.
                    if (count >= 48u) { reason |= 8u; break; }
                    pieces[memPieces] = vec2f(l, r);
                    memPieces++; count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
                }
            }
        }
        if (reason != 0u) { break; }

        for (var p = 0u; p < memPieces; p++) {
            let pa = pieces[p].x; let pb = pieces[p].y;
            let n = max(1u, u32(ceil((pb - pa) / 4.0)));
            if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
            for (var k = 0u; k < n; k++) {
                let sl = select(pa + f32(k) * (pb - pa) / f32(n), pa, k == 0u);
                let sr = select(pa + f32(k + 1u) * (pb - pa) / f32(n), pb, k + 1u == n);
                subpanels[subBase + singles] = Subpanel(vec2f(sl, sr), vec2u(member, 0u));
                singles++;
            }
        }
    }
    if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
    else { rays[id].counts = vec4u(subBase, singles, overBase, 0u); }
}
)WGSL";
static const char* kFallbackProducerWgsl = R"WGSL(

struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> fallbackTileList: array<u32>;
@group(0) @binding(8) var<storage, read> routeCounts: array<u32>;

@compute @workgroup_size(64, 1, 1)
fn fallbackProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let totalTiles = arrayLength(&tileOffsets) - 1u;
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts[2u], totalTiles)) { return; }
    let tileId = fallbackTileList[tileSlot];
    if (tileId >= totalTiles) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 4u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  var allPositiveH = true;
  let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
  let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
  let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
  if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
   if (work + 24u > cfg.budget) { reason |= 1u; break; }
   work += 24u;
   memCount[member] = 0u;
   continue;
  }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); return; }
 var ne = 0u;
 var head = vec4u(0u);
 let totalKnots = (memCount.x + memCount.y + memCount.z + memCount.w) * 2u;
 loop {
  if (ne >= totalKnots) { break; }
  var bestM = 4u;
  var bestVal = 0.0;
  for (var m = 0u; m < 4u; m++) {
   let h = head[m];
   if (h < memCount[m] * 2u) {
    let pIdx = memStart[m] + (h >> 1u);
    let isY = (h & 1u) != 0u;
    let val = select(pieces[pIdx].x, pieces[pIdx].y, isY);
    if (bestM == 4u || val < bestVal) {
     bestVal = val;
     bestM = m;
    }
   }
  }
  knots[ne] = bestVal;
  ne++;
  head[bestM]++;
 }
 var singles = 0u; var overs = 0u;
 var pIdx = vec4u(0u);
 for (var i = 1u; i < ne && reason == 0u; i++) {
  let a = knots[i - 1u]; let b = knots[i]; if (!(b > a)) { continue; }
  let mid = a + 0.5 * (b - a);
  var mask = 0u;
  for (var m = 0u; m < 4u; m++) {
   let start = memStart[m];
   let numPieces = memCount[m];
   var cur = pIdx[m];
   loop {
    if (cur >= numPieces || pieces[start + cur].y >= mid) { break; }
    cur++;
   }
   pIdx[m] = cur;
   if (cur < numPieces) {
    let p = pieces[start + cur];
    if (mid >= p.x && mid <= p.y) {
     mask |= (1u << m);
    }
   }
  }
  if (mask == 0u) { continue; }
  if (countOneBits(mask) == 1u) {
   let n = max(1u, u32(ceil((b - a) / 4.0)));
   if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
   let member = firstTrailingBit(mask);
   for (var k = 0u; k < n; k++) {
    let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
    let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
    subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(member, 0)); singles++;
   }
  } else {
   if (overs >= cfg.maxOverPerRay) { reason |= 32u; break; }
   overlaps[overBase + overs] = Overlap(vec2f(a, b), vec2u(mask, 0)); overs++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, overs); }
}
)WGSL";



static const char* kFallbackConsumerWgsl = R"WGSL(
@group(0) @binding(8) var<storage, read> tileOffsets: array<u32>;
@group(0) @binding(9) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(10) var<storage, read> fallbackTileList: array<u32>;
@group(0) @binding(11) var<storage, read> routeCounts: array<u32>;

@compute @workgroup_size(64, 1, 1)
fn fallbackConsumerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let totalTiles = arrayLength(&tileOffsets) - 1u;
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts[2u], totalTiles)) { return; }
    let tileId = fallbackTileList[tileSlot];
    if (tileId >= totalTiles) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let rayIdx = tileRayIndices[rayStart + rayInTile];
    if (rayIdx >= u.rayCount) { return; }

    let r = rays[rayIdx % arrayLength(&rays)];
    if((r.counts.w & 0x80000000u) != 0u){ return; }
    if((r.counts.w & 0x40000000u) != 0u){ return; }
    let ro = r.ro_clipA.xyz;
    let rd = r.rd_clipB.xyz;
    let subOffset = r.counts.x;
    let subCount = r.counts.y;
    let overOffset = r.counts.z;
    let overCount = r.counts.w;

    let gx0 = 0.5 * (1.0 - 0.5773502691896257);
    let gx1 = 0.5 * (1.0 + 0.5773502691896257);

    var T = 1.0;
    var L = vec3<f32>(0.0);

    // Two sorted streams must be consumed in ray order, including overlap.
    var single=0u;
    var overlap=0u;
    loop {
        if (single>=subCount && overlap>=overCount) {break;}
        var useOverlap=false;
        if (overlap<overCount) {
            if (single>=subCount) {useOverlap=true;}
            else {useOverlap=overlaps[overOffset+overlap].span.x<subpanels[subOffset+single].span.x;}
        }
        if (useOverlap) {
            let state=advanceOverlap(vec4<f32>(L,T),ro,rd,overlaps[overOffset+overlap]);
            L=state.xyz; T=state.w;
            overlap+=1u;
            continue;
        }
        let sub = subpanels[subOffset + single];
        single+=1u;
        let s0 = sub.span.x;
        let s1 = sub.span.y;
        let sub_h = s1 - s0;
        let mid = sub.info.x;
        let m = media[mid];
        let pOffset = u32(m.freq_offset.y);
        let freq = m.freq_offset.x;
        let alpha = m.color_alpha.w;
        let color = m.color_alpha.xyz;

        let s_m = s0 + gx0 * sub_h;
        let s_p = s0 + gx1 * sub_h;
        let w_m = ro + s_m * rd - m.origin.xyz;
        let w_p = ro + s_p * rd - m.origin.xyz;

        let env_m = evalEnvelope(w_m, pOffset);
        let env_p = evalEnvelope(w_p, pOffset);

        var D_m = 0.0;
        if (env_m > 0.0) {
            let nm = cnoise3(freq * w_m);
            D_m = env_m * clamp(0.7 + 0.3 * nm, 0.0, 1.0);
        }
        var D_p = 0.0;
        if (env_p > 0.0) {
            let np = cnoise3(freq * w_p);
            D_p = env_p * clamp(0.7 + 0.3 * np, 0.0, 1.0);
        }

        // Sixth-one Sun: Strict D > 0 gate
        let sig_m = select(0.0, max(alpha * D_m, 1e-6), D_m > 0.0);
        let em_m  = select(vec3<f32>(0.0), color * (alpha * D_m), D_m > 0.0);
        let sig_p = select(0.0, max(alpha * D_p, 1e-6), D_p > 0.0);
        let em_p  = select(vec3<f32>(0.0), color * (alpha * D_p), D_p > 0.0);

        let sig_avg = 0.5 * (sig_m + sig_p);
        let em_avg  = 0.5 * (em_m + em_p);
        let tau = sub_h * sig_avg;
        let atten = exp(-tau);

        // Sixth-one Sun: Numerically safe small-depth gain in f32
        var gain: f32;
        gain=sub_h*phiSafe(tau);

        L = L + T * em_avg * gain;
        T = T * atten;
    }

    results[rayIdx] = vec4<f32>(L, T);
}
)WGSL";
static const char* kS2TerminalProducerWgsl = R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<uniform> curtains: array<CurtainSpec, 4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
struct MediumParams {
    origin: vec4<f32>,
    color_alpha: vec4<f32>,
    freq_offset: vec4<f32>,
};
struct ParameterBuffer {
    v: array<f32>,
};
@group(0) @binding(4) var<storage, read_write> results: array<vec4<f32>>;
@group(0) @binding(9) var<storage, read> media: array<MediumParams>;
@group(0) @binding(10) var<storage, read> params: ParameterBuffer;

fn mod289(x: vec4<f32>) -> vec4<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn mod289_3(x: vec3<f32>) -> vec3<f32> {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
}
fn permute4(x: vec4<f32>) -> vec4<f32> {
    return mod289(((x * 34.0) + 1.0) * x);
}
fn taylorInvSqrt(r: vec4<f32>) -> vec4<f32> {
    return 1.79284291400159 - 0.85373472095314 * r;
}

fn cnoise3(P: vec3<f32>) -> f32 {
    let Pi0 = floor(P);
    let Pi1 = Pi0 + vec3<f32>(1.0);
    let Pi0_mod = mod289_3(Pi0);
    let Pi1_mod = mod289_3(Pi1);
    let Pf0 = fract(P);
    let Pf1 = Pf0 - vec3<f32>(1.0);
    let ix = vec4<f32>(Pi0_mod.x, Pi1_mod.x, Pi0_mod.x, Pi1_mod.x);
    let iy = vec4<f32>(Pi0_mod.y, Pi0_mod.y, Pi1_mod.y, Pi1_mod.y);
    let iz0 = vec4<f32>(Pi0_mod.z);
    let iz1 = vec4<f32>(Pi1_mod.z);

    let ixy = permute4(permute4(ix) + iy);
    let ixy0 = permute4(ixy + iz0);
    let ixy1 = permute4(ixy + iz1);

    var gx0 = ixy0 / 7.0;
    var gy0 = fract(floor(gx0) / 7.0) - 0.5;
    gx0 = fract(gx0);
    var gz0 = vec4<f32>(0.5) - abs(gx0) - abs(gy0);
    let sz0 = step(gz0, vec4<f32>(0.0));
    gx0 = gx0 - sz0 * (step(vec4<f32>(0.0), gx0) - 0.5);
    gy0 = gy0 - sz0 * (step(vec4<f32>(0.0), gy0) - 0.5);

    var gx1 = ixy1 / 7.0;
    var gy1 = fract(floor(gx1) / 7.0) - 0.5;
    gx1 = fract(gx1);
    var gz1 = vec4<f32>(0.5) - abs(gx1) - abs(gy1);
    let sz1 = step(gz1, vec4<f32>(0.0));
    gx1 = gx1 - sz1 * (step(vec4<f32>(0.0), gx1) - 0.5);
    gy1 = gy1 - sz1 * (step(vec4<f32>(0.0), gy1) - 0.5);

    var g000 = vec3<f32>(gx0.x,gy0.x,gz0.x);
    var g100 = vec3<f32>(gx0.y,gy0.y,gz0.y);
    var g010 = vec3<f32>(gx0.z,gy0.z,gz0.z);
    var g110 = vec3<f32>(gx0.w,gy0.w,gz0.w);
    var g001 = vec3<f32>(gx1.x,gy1.x,gz1.x);
    var g101 = vec3<f32>(gx1.y,gy1.y,gz1.y);
    var g011 = vec3<f32>(gx1.z,gy1.z,gz1.z);
    var g111 = vec3<f32>(gx1.w,gy1.w,gz1.w);

    let norm0 = taylorInvSqrt(vec4<f32>(dot(g000, g000), dot(g010, g010), dot(g100, g100), dot(g110, g110)));
    g000 = g000 * norm0.x;
    g010 = g010 * norm0.y;
    g100 = g100 * norm0.z;
    g110 = g110 * norm0.w;
    let norm1 = taylorInvSqrt(vec4<f32>(dot(g001, g001), dot(g011, g011), dot(g101, g101), dot(g111, g111)));
    g001 = g001 * norm1.x;
    g011 = g011 * norm1.y;
    g101 = g101 * norm1.z;
    g111 = g111 * norm1.w;

    let n000 = dot(g000, Pf0);
    let n100 = dot(g100, vec3<f32>(Pf1.x, Pf0.y, Pf0.z));
    let n010 = dot(g010, vec3<f32>(Pf0.x, Pf1.y, Pf0.z));
    let n110 = dot(g110, vec3<f32>(Pf1.x, Pf1.y, Pf0.z));
    let n001 = dot(g001, vec3<f32>(Pf0.x, Pf0.y, Pf1.z));
    let n101 = dot(g101, vec3<f32>(Pf1.x, Pf0.y, Pf1.z));
    let n011 = dot(g011, vec3<f32>(Pf0.x, Pf1.y, Pf1.z));
    let n111 = dot(g111, Pf1);

    let fade_xyz = Pf0 * Pf0 * Pf0 * (Pf0 * (Pf0 * 6.0 - 15.0) + 10.0);
    let n_z = mix(vec4<f32>(n000, n100, n010, n110), vec4<f32>(n001, n101, n011, n111), fade_xyz.z);
    let n_yz = mix(n_z.xy, n_z.zw, fade_xyz.y);
    let n_xyz = mix(n_yz.x, n_yz.y, fade_xyz.x); 
    return 2.2 * n_xyz;
}

fn evalEnvelope(p: vec3<f32>, paramOffset: u32) -> f32 {
    let f0 = params.v[paramOffset + 0u];
    if (f0 == 0.0) { return 0.0; }
    let f1 = clamp(params.v[paramOffset + 1u] - select(0.0, abs(p.x) / params.v[paramOffset + 2u], abs(params.v[paramOffset + 2u]) >= 1e-06), params.v[paramOffset + 3u], params.v[paramOffset + 4u]);
    if (f1 == 0.0) { return 0.0; }
    let f2 = clamp(params.v[paramOffset + 5u] * (p.y + params.v[paramOffset + 6u]), params.v[paramOffset + 7u], params.v[paramOffset + 8u]);
    if (f2 == 0.0) { return 0.0; }
    let f3 = clamp(params.v[paramOffset + 9u] - select(0.0, (p.y + params.v[paramOffset + 11u]) / params.v[paramOffset + 10u], abs(params.v[paramOffset + 10u]) >= 1e-06), params.v[paramOffset + 12u], params.v[paramOffset + 13u]);
    if (f3 == 0.0) { return 0.0; }
    let z_curve = p.z + params.v[paramOffset + 16u] * sin(params.v[paramOffset + 17u] * p.x + params.v[paramOffset + 18u])
                      + params.v[paramOffset + 19u] * cos(params.v[paramOffset + 20u] * p.x + params.v[paramOffset + 21u])
                      + params.v[paramOffset + 22u] * sin(params.v[paramOffset + 23u] * p.x + params.v[paramOffset + 24u]);
    let f4 = clamp(params.v[paramOffset + 14u] - select(0.0, abs(z_curve) / params.v[paramOffset + 15u], abs(params.v[paramOffset + 15u]) >= 1e-06), params.v[paramOffset + 25u], params.v[paramOffset + 26u]);
    if (f4 == 0.0) { return 0.0; }
    let f5 = params.v[paramOffset + 27u] + params.v[paramOffset + 28u] * cos(params.v[paramOffset + 29u] * p.x + params.v[paramOffset + 30u])
                                         + params.v[paramOffset + 31u] * cos(params.v[paramOffset + 32u] * p.x + params.v[paramOffset + 33u]);
    if (f5 == 0.0) { return 0.0; }
    return f0 * f1 * f2 * f3 * f4 * f5;
}

fn phiSafe(tau: f32) -> f32 {
    if (abs(tau) < 0.01) {
        return 1.0 + tau * (-0.5 + tau * (1.0/6.0 - tau/24.0));
    }
    return (1.0 - exp(-tau)) / tau;
}

const FALLBACK:u32=0x80000000u;

fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}

fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}

fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn isolateMonotone(m: CurtainSpec, o: vec3f, d: vec3f, a: f32, b: f32, c: f32,
 va: f32, vb: f32, error: f32, minSlope: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>,
 bands: ptr<function, array<vec2f, 32>>, nr: ptr<function, u32>,
 reason: ptr<function, u32>, work: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
 if ((va > error && vb < -error) || (va < -error && vb > error)) {
  var l = a; var r = b; var left = va;
  for (var iter = 0u; iter < 32u; iter++) {
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   let mid = l + 0.5 * (r - l);
   if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
   let v = evalPhi(m, o, d, mid) - c;
   if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
   if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
  }
  putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
 }
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool,
 levelActiveMask: u32) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  if (*work >= cfg.budget) { *reason |= 1u; break; }
  let coarseH = b - a;
  if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
  if ((levelActiveMask & (1u << bin)) == 0u) { *work += 1u; continue; }
  *work += 1u;
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
  let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
  let coarseError = err + 0.000001 * coarseScale;
  let coarseSlope = (coarseVb - coarseVa) / coarseH;
  let coarseRadius = 0.5 * M * coarseH + 2.0 * coarseError / coarseH;
  let coarseMinSlope = abs(coarseSlope) - coarseRadius;
  if (coarseMinSlope > 0.0) {
   isolateMonotone(m, o, d, a, b, c, coarseVa, coarseVb, coarseError, coarseMinSlope,
                   bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  if (0.125 * M * coarseH * coarseH <= coarseError) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let mid0 = a + 0.5 * coarseH;
  if (mid0 <= a || mid0 >= b) {
   putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
   if (*reason != 0u) { break; }
   continue;
  }
  let phi_mid0 = evalPhi(m, o, d, mid0);
  stack[0] = vec4f(mid0, b, phi_mid0, phi_b0); setDepth(&depthBits, 0u, 1u);
  stack[1] = vec4f(a, mid0, phi_a0, phi_mid0); setDepth(&depthBits, 1u, 1u);
  top = 2u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    isolateMonotone(m, o, d, a, b, c, va, vb, error, minSlope,
                    bounds, nb, bands, nr, reason, work, zeroBands, isZeroLevel);
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

fn exactLevelActiveMask(m: CurtainSpec, d: vec3f, lo: f32, hi: f32, c: f32,
                        phi_knots: ptr<function, array<f32, 9>>, allPositiveH: ptr<function, bool>) -> u32 {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var mask = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let h = b - a;
  if (!(h > 0.0)) { *allPositiveH = false; }
  let va = (*phi_knots)[bin] - c; let vb = (*phi_knots)[bin + 1u] - c;
  let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
  let error = err + 0.000001 * scale;
  let bow = 0.125 * M * h * h + error;
  if (!(min(va, vb) > bow || max(va, vb) < -bow)) {
   mask |= (1u << bin);
  }
 }
 return mask;
}

@group(0) @binding(5) var<storage, read> tileOffsets: array<u32>;
@group(0) @binding(6) var<storage, read> tileRayIndices: array<u32>;
@group(0) @binding(7) var<storage, read> s2TileList: array<u32>;
@group(0) @binding(8) var<uniform> routeCounts: vec4u;

@compute @workgroup_size(64, 1, 1)
fn s2TerminalProducerMain(@builtin(workgroup_id) wid: vec3u, @builtin(local_invocation_index) lid: u32) {
    let totalTiles = arrayLength(&tileOffsets) - 1u;
    let localTile = lid >> 4u;
    let rayInTile = lid & 15u;
    let tileSlot = wid.x * 4u + localTile;
    if (tileSlot >= min(routeCounts.y, totalTiles)) { return; }
    let tileId = s2TileList[tileSlot];
    if (tileId >= totalTiles) { return; }
    let rayStart = tileOffsets[tileId];
    let rayCount = tileOffsets[tileId + 1u] - rayStart;
    if (rayInTile >= rayCount) { return; }
    let id = tileRayIndices[rayStart + rayInTile];
    if (id >= cfg.rayCount) { return; }

    let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
    let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
    var reason = 0u; var work = 0u; var count = 0u;
    var pieces: array<vec2f, 48>;
    var knots: array<f32, 96>;
    var memStart = vec2u(0u, 0u);
    var memCount = vec2u(0u, 0u);
    if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }

    for (var member = 0u; member < 2u; member++) {
        memStart[member] = count;
        let m = curtains[member]; let o = ro - m.origin.xyz;
        var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
        for (var axis = 0u; axis < 3u; axis++) {
            var half = m.half[axis];
            if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
            if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
            else {
                let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
                a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
            }
        }
        if (!hit || !(b > a)) { continue; }
        var phi_knots: array<f32, 9>;
        for (var k = 0u; k < 9u; k++) {
            var s = a + (b - a) * f32(k) / 8.0;
            if (k == 0u) { s = a; } if (k == 8u) { s = b; }
            phi_knots[k] = evalPhi(m, o, d, s);
        }
        var allPositiveH = true;
        let mask0 = exactLevelActiveMask(m, d, a, b, -m.limits.w, &phi_knots, &allPositiveH);
        let mask1 = exactLevelActiveMask(m, d, a, b, 0.0, &phi_knots, &allPositiveH);
        let mask2 = exactLevelActiveMask(m, d, a, b, m.limits.w, &phi_knots, &allPositiveH);
        if (allPositiveH && (mask0 | mask1 | mask2) == 0u && abs(phi_knots[0]) > m.limits.w + m.curv.y) {
            if (work + 24u > cfg.budget) { reason |= 1u; break; }
            work += 24u;
            memCount[member] = 0u;
            continue;
        }
        var nb = 1u; knots[0] = a;
        var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
        roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask0);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true, mask1);
        if (reason != 0u) { break; }
        roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false, mask2);
        if (reason != 0u) { break; }
        if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
        if (d.y != 0.0) {
            let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
            let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
        }
        knots[nb] = b; nb++;
        for (var i = 1u; i < nb; i++) {
            let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
            knots[j] = v;
        }
        let memberStart = count; var previousShortBand = false; var previousPositive = false;
        for (var i = 1u; i < nb; i++) {
            let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
            let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
            if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
            if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
            for (var k = 0u; k < nr; k++) {
                uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
                if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
            }
            if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
                if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
                     previousShortBand, previousPositive, uncertain, protectedBoundary)) {
                    pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
                } else {
                    if (count >= 48u) { reason |= 8u; break; }
                    pieces[count] = vec2f(l, r);
                    count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
                }
            }
        }
        memCount[member] = count - memStart[member];
        if (reason != 0u) { break; }
    }
    if (reason != 0u) {
        rays[id].counts = vec4u(subBase, 0u, overBase, FALLBACK | reason);
        return;
    }

    // Pre-check total subpanel count across finalized pieces[0..count-1]
    var singles = 0u;
    for (var p = 0u; p < count; p++) {
        let pa = pieces[p].x;
        let pb = pieces[p].y;
        let n = max(1u, u32(ceil((pb - pa) / 4.0)));
        if (singles + n > cfg.maxSubPerRay) {
            reason |= 16u;
            break;
        }
        singles += n;
    }
    if (reason != 0u) {
        rays[id].counts = vec4u(subBase, 0u, overBase, FALLBACK | reason);
        return;
    }

    // Subdivide pieces directly in scalar registers and integrate into shared (L, T):
    let rd = d;
    let gx0 = 0.5 * (1.0 - 0.5773502691896257);
    let gx1 = 0.5 * (1.0 + 0.5773502691896257);
    var T = 1.0;
    var L = vec3<f32>(0.0);

    for (var member = 0u; member < 2u; member++) {
        let m = media[member];
        let pOffset = u32(m.freq_offset.y);
        let freq = m.freq_offset.x;
        let alpha = m.color_alpha.w;
        let color = m.color_alpha.xyz;
        let start = memStart[member];
        let end = start + memCount[member];

        for (var p = start; p < end; p++) {
            let pa = pieces[p].x;
            let pb = pieces[p].y;
            let n = max(1u, u32(ceil((pb - pa) / 4.0)));
            for (var k = 0u; k < n; k++) {
                let s0 = select(pa + f32(k) * (pb - pa) / f32(n), pa, k == 0u);
                let s1 = select(pa + f32(k + 1u) * (pb - pa) / f32(n), pb, k + 1u == n);
                let sub_h = s1 - s0;

                let s_m = s0 + gx0 * sub_h;
                let s_p = s0 + gx1 * sub_h;
                let w_m = ro + s_m * rd - m.origin.xyz;
                let w_p = ro + s_p * rd - m.origin.xyz;

                let env_m = evalEnvelope(w_m, pOffset);
                let env_p = evalEnvelope(w_p, pOffset);

                var D_m = 0.0;
                if (env_m > 0.0) {
                    let nm = cnoise3(freq * w_m);
                    D_m = env_m * clamp(0.7 + 0.3 * nm, 0.0, 1.0);
                }
                var D_p = 0.0;
                if (env_p > 0.0) {
                    let np = cnoise3(freq * w_p);
                    D_p = env_p * clamp(0.7 + 0.3 * np, 0.0, 1.0);
                }

                let sig_m = select(0.0, max(alpha * D_m, 1e-6), D_m > 0.0);
                let em_m  = select(vec3<f32>(0.0), color * (alpha * D_m), D_m > 0.0);
                let sig_p = select(0.0, max(alpha * D_p, 1e-6), D_p > 0.0);
                let em_p  = select(vec3<f32>(0.0), color * (alpha * D_p), D_p > 0.0);

                let sig_avg = 0.5 * (sig_m + sig_p);
                let em_avg  = 0.5 * (em_m + em_p);
                let tau = sub_h * sig_avg;
                let atten = exp(-tau);

                var gain: f32;
                gain = sub_h * phiSafe(tau);

                L = L + T * em_avg * gain;
                T = T * atten;
            }
        }
    }

    results[id] = vec4<f32>(L, T);
    rays[id].counts = vec4u(subBase, singles, overBase, 0x40000000u);
}
)WGSL";

int main(int argc, char** argv) {
    std::string outputPath = argc > 1 ? argv[1] : "";

    std::ifstream in("saves/zones/Northern Veil/zone.ecform", std::ios::binary);
    std::vector<uint8_t> b((std::istreambuf_iterator<char>(in)), {});
    J zone = J::parse(J::from_msgpack(b).at("MigrationRoot").get<std::string>());

    double clock = std::stod(std::getenv("EC_POSE_CLOCK"));
    std::vector<Medium> media;
    const float alphas[4] = {2.0f/15.0f, 9.0f/65.0f, 8.0f/55.0f, 4.0f/25.0f};
    const glm::vec3 colors[4] = {
        {0.0747842f, 0.688014f, 0.239309f},
        {0.0391309f, 0.547833f, 0.641747f},
        {0.680411f,  0.103093f, 0.701029f},
        {0.612595f,  0.108105f, 0.198192f}
    };
    const float freqs[4] = {0.08f, 0.09f, 0.07f, 0.10f};

    double coefficientBindingMs=0,coefficientPreparationMs=0;
    std::vector<OntoMath::CommonScalarFactor> coefficientRecipes;
    std::vector<float> globalParamPool;
    int idx = 0;
    for (auto& j : zone.at("spatialFields")) {
        auto field = geom::FieldNode::fromJson(j);
        Rendering::VolumeDensityBinding bnd;
        if (!field || !Rendering::readVolumeDensity(*field, 0, 0, bnd)) continue;
        Medium m;
        m.owner = field;
        m.id = bnd.producerId;
        m.origin = glm::dvec3(bnd.origin);
        m.half = glm::abs(glm::dvec3(bnd.scale));
        m.density = single(bnd.densityExpr);
        m.sigma = single(bnd.extinctionExpr);
        m.emission = single(bnd.emissionExpr);
        {auto begin=std::chrono::steady_clock::now();coefficientRecipes.push_back(deriveOriginalCoefficients(m));coefficientBindingMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();begin=std::chrono::steady_clock::now();prepareOriginalCoefficients(m,coefficientRecipes.back(),clock);coefficientPreparationMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();}
        m.noiseFreq = freqs[idx];
        m.envAST = cloneEnvelope(*m.density);

        auto res = OntoMath::restrictAlgebraicToLine(*m.envAST, false, "p");
        if (res) {
            m.envForm = std::move(*res.form);
            m.hasEnv = true;
        }

        auto pb = sdfwgsl::collectVolumeParams(bnd.densityExpr);
        m.paramOffset = static_cast<uint32_t>(globalParamPool.size());
        globalParamPool.insert(globalParamPool.end(), pb.values.begin(), pb.values.end());

        media.push_back(std::move(m));
        ++idx;
    }

    J rays;
    { std::ifstream rin(std::getenv("EC_POSE_RAYS")); rin >> rays; }

    const auto& R = rays.at("rays");
    const glm::dvec3 ro(rays["origin"][0], rays["origin"][1], rays["origin"][2]);
    size_t count = std::getenv("EC_GPU_GEOMETRY_CASE")?16:R.size();
    // SURVEYOR: data-driven tile layout (sonnet_surveyor_layout.py); replaces the 2304-tile pin.
    std::vector<uint32_t> baseTileOffsets;
    std::vector<uint32_t> baseTileRayIndices;
    {
        const char* layoutPath = std::getenv("EC_SURVEYOR_LAYOUT");
        if (!layoutPath) throw std::runtime_error("EC_SURVEYOR_LAYOUT required");
        J layout; { std::ifstream lin(layoutPath); lin >> layout; }
        baseTileOffsets = layout.at("tile_offsets").get<std::vector<uint32_t>>();
        baseTileRayIndices = layout.at("tile_ray_indices").get<std::vector<uint32_t>>();
        if (baseTileOffsets.size() < 2 || baseTileOffsets.size() - 1 != layout.at("tile_count").get<size_t>())
            throw std::runtime_error("surveyor layout: tile_count framing");
        if (baseTileOffsets.front() != 0 || baseTileOffsets.back() != baseTileRayIndices.size() || baseTileRayIndices.size() != count)
            throw std::runtime_error("surveyor layout: offsets do not cover exactly the captured rays");
        std::vector<uint8_t> seen(count, 0);
        for (size_t t = 0; t + 1 < baseTileOffsets.size(); ++t) {
            if (baseTileOffsets[t] > baseTileOffsets[t + 1]) throw std::runtime_error("surveyor layout: offsets not monotone");
            if (baseTileOffsets[t + 1] - baseTileOffsets[t] > 16u) throw std::runtime_error("surveyor layout: tile over 16-ray capacity");
        }
        for (uint32_t r : baseTileRayIndices) {
            if (r >= count || seen[r]) throw std::runtime_error("surveyor layout: index out of range or repeated");
            seen[r] = 1;
        }
    }

    uint32_t scaleK = 1;
    if (const char* envK = std::getenv("EC_GPU_SCALE")) {
        scaleK = uint32_t(std::atoi(envK));
        if (scaleK == 0) scaleK = 1;
    }
    uint32_t baseRayCount = count;
    uint32_t baseTileCount = uint32_t(baseTileOffsets.size() - 1);
    if (scaleK != 1) throw std::runtime_error("surveyor: distinct native rays are never replicated (EC_GPU_SCALE must be 1)");
    count = baseRayCount * scaleK;
    uint32_t numTiles = baseTileCount * scaleK;

    std::cerr << "§6el Clean Scale K=" << scaleK << " -> Rays=" << count << " (" << count * sizeof(GpuRayHeader) / 1048576.0 << " MB), Tiles=" << numTiles << std::endl;

    // Schedule buffers
    std::vector<GpuRayHeader> gpuRays(count);
    std::vector<GpuSubpanel> gpuSubpanels;
    std::vector<GpuOverlap> gpuOverlaps;
    uint32_t maxSubpanelsPerRay = 0;
    std::vector<uint32_t> producerFlags(count, 0);

    std::vector<uint32_t> tileOffsets(numTiles + 1, 0);
    std::vector<uint32_t> tileRayIndices;
    tileRayIndices.reserve(count);

    for (uint32_t c = 0; c < scaleK; ++c) {
        for (uint32_t i = 0; i < baseRayCount; ++i) {
            uint32_t rIdx = c * baseRayCount + i;
            const auto& row = R[i];
            auto& ray = gpuRays[rIdx];
            for (int k = 0; k < 3; ++k) {
                ray.ro[k] = float(ro[k]);
                ray.rd[k] = row[2 + k];
            }
            ray.clipA = row[5];
            ray.clipB = row[6];
        }
        for (uint32_t t = 0; t < baseTileCount; ++t) {
            uint32_t tId = c * baseTileCount + t;
            tileOffsets[tId] = uint32_t(tileRayIndices.size());
            uint32_t rStart = baseTileOffsets[t];
            uint32_t rEnd = baseTileOffsets[t + 1];
            for (uint32_t r = rStart; r < rEnd; ++r) {
                tileRayIndices.push_back(c * baseRayCount + baseTileRayIndices[r]);
            }
        }
    }
    tileOffsets[numTiles] = uint32_t(tileRayIndices.size());
    std::vector<GpuMediumParams> gpuMedia(media.size());
    for (size_t m = 0; m < media.size(); ++m) {
        gpuMedia[m].origin[0] = float(media[m].origin.x);
        gpuMedia[m].origin[1] = float(media[m].origin.y);
        gpuMedia[m].origin[2] = float(media[m].origin.z);
        gpuMedia[m].origin[3] = 0.0f;

        gpuMedia[m].color[0] = media[m].color.r;
        gpuMedia[m].color[1] = media[m].color.g;
        gpuMedia[m].color[2] = media[m].color.b;
        gpuMedia[m].color[3] = media[m].alpha;

        gpuMedia[m].freq[0] = media[m].noiseFreq;
        gpuMedia[m].freq[1] = float(media[m].paramOffset);
        gpuMedia[m].freq[2] = 0.0f;
        gpuMedia[m].freq[3] = 0.0f;
    }

    // Workload accounting
    size_t rayBytes = gpuRays.size() * sizeof(GpuRayHeader);
    
    const uint32_t maxSubPerRay = std::getenv("EC_GPU_SUB_CAP")?std::stoul(std::getenv("EC_GPU_SUB_CAP")):64;
    const uint32_t maxOverPerRay = std::getenv("EC_GPU_OVER_CAP")?std::stoul(std::getenv("EC_GPU_OVER_CAP")):16;
    const size_t totalSub = count * maxSubPerRay;
    const size_t totalOver = count * maxOverPerRay;
    size_t subpanelBytes = totalSub * sizeof(GpuSubpanel);
    size_t overlapBytes = totalOver * sizeof(GpuOverlap);

    // Sized above for GPU producer
    size_t mediaBytes = gpuMedia.size() * sizeof(GpuMediumParams);
    size_t paramBytes = globalParamPool.size() * sizeof(float);
    size_t totalScheduleBytes = rayBytes + subpanelBytes + overlapBytes + mediaBytes + paramBytes;

    std::cout << "Schedule exported:\n"
              << "  Rays: " << count << " (" << rayBytes << " bytes)\n"
              << "  Subpanels: " << gpuSubpanels.size() << " (" << subpanelBytes << " bytes, max " << maxSubpanelsPerRay << "/ray)\n"
              << "  Overlaps: " << gpuOverlaps.size() << " (" << overlapBytes << " bytes)\n"
              << "  Total Schedule Size: " << totalScheduleBytes << " bytes (" << (totalScheduleBytes / 1024.0) << " KB)\n";


    struct alignas(16) CurrentUniforms {
        glm::mat4 viewProj{1},invViewProj{1};
        glm::vec4 eyePos,viewport,incidentSource,incidentColor,sourceTime,volumeControl,volumeOutputError;
    };
    struct alignas(16) CurrentInstance {
        glm::vec4 origin,halfExtent,time;
        uint32_t paramOffset=0,zeroProofOffset=0,zeroProofDims=0,zeroProofPresent=0;
        uint32_t supportCertOffset=0,supportCertCount=0,supportClosedOffset=0,supportClosedCount=0;
    };
    static_assert(sizeof(CurrentUniforms)==240&&sizeof(CurrentInstance)==80);
    const int repeatFactor=std::getenv("EC_MATCH_REPEAT")?std::atoi(std::getenv("EC_MATCH_REPEAT")):1;
    if(repeatFactor<1||repeatFactor>128)throw std::runtime_error("repeat outside 1..128");
    const size_t executionRays=count*size_t(repeatFactor);
    CurrentUniforms currentU{};
    currentU.eyePos=glm::vec4(ro,1);currentU.viewport={2560,1440,float(executionRays),1};
    currentU.incidentSource={0,0,0,1};currentU.incidentColor=glm::vec4(1);currentU.sourceTime={float(clock),0,0,0};
    currentU.volumeControl={24,1,0,96};currentU.volumeOutputError=glm::vec4(0);
    auto rootLight=geom::FieldNode::fromJson(zone.at("spatialRoot"));
    if(!rootLight||!rootLight->field)throw std::runtime_error("missing authored source");
    auto light=single(&rootLight->field->astDefinition);
    if(!light||light->op!=M::Op::ScalarLeaf)throw std::runtime_error("source is not admitted zero literal");
    for(const auto& term:light->scalarForm.terms)if(term.coefficient!=0)throw std::runtime_error("not zero source");
    std::vector<sdfwgsl::VolumeProgramInput> currentInputs;
    std::vector<sdfwgsl::KernelVolumeEvaluator> currentEvaluators;
    std::vector<CurrentInstance> currentInstances(media.size()+1);
    uint32_t offset=0;bool trim=true;
    for(size_t id=0;id<media.size();++id) {
        Rendering::VolumeDensityBinding b;
        if(!Rendering::readVolumeDensity(*media[id].owner,0,0,b))throw std::runtime_error("binding refusal");
        sdfwgsl::VolumeProgramInput in;
        in.densityExpr=b.densityExpr;in.extinctionExpr=b.extinctionExpr;in.scatteringExpr=b.scatteringExpr;
        in.volumeChromaExpr=b.volumeChromaExpr;in.phaseExpr=b.phaseExpr;in.emissionExpr=b.emissionExpr;
        in.occluderSdf=b.occluderSdf;in.lightRadianceExpr=&rootLight->field->astDefinition;
        currentInputs.push_back(in);currentEvaluators.push_back(sdfwgsl::lowerVolumeEvaluator(in));
        if(!currentEvaluators.back().program.ok)throw std::runtime_error(currentEvaluators.back().program.error);
        auto& inst=currentInstances[id+1];inst.origin=glm::vec4(media[id].origin,0);inst.halfExtent=glm::vec4(media[id].half,0);
        inst.time={float(clock),0,0,0};inst.paramOffset=offset;offset+=currentEvaluators.back().program.params.size();
        if(glm::all(glm::lessThanEqual(glm::abs(ro-media[id].origin),media[id].half)))trim=false;
    }
    auto currentProgram=sdfwgsl::composeVolumeSet(currentInputs,currentEvaluators,trim);
    if(!currentProgram.ok)throw std::runtime_error(currentProgram.error);
    auto currentParams=currentProgram.params;
    for(size_t id=0;id<media.size();++id) {
        auto proof=Rendering::buildVolumeZeroProof(*currentInputs[id].densityExpr,glm::vec3(media[id].half));
        if(!proof.any())continue;
        auto& inst=currentInstances[id+1];inst.zeroProofOffset=currentParams.size();
        inst.zeroProofDims=proof.dims.x|(proof.dims.y<<10u)|(proof.dims.z<<20u);
        inst.zeroProofPresent=trim?1u|((proof.supportAxis+1u)<<1u):1u;
        currentParams.insert(currentParams.end(),proof.words.begin(),proof.words.end());
        const auto lo=proof.supportMin,hi=proof.supportMax;
        currentParams.insert(currentParams.end(),{lo.x,lo.y,lo.z,hi.x,hi.y,hi.z});
        if(trim)for(const auto& band:proof.supportBands)currentParams.insert(currentParams.end(),{band.x,band.y,band.z,band.w});
    }
    // Retain the production compiler's generated evaluator and marching body.
    // Only entrypoint/ray inputs and raw output are adapted to compute.
    const auto fs=currentProgram.wgsl.find("@fragment\nfn fs(");
    const auto begin=currentProgram.wgsl.find("    var transmittance = 1.0;",fs);
    const auto end=currentProgram.wgsl.find("    let alpha = 1.0 - transmittance;",begin);
    if(fs==std::string::npos||begin==std::string::npos||end==std::string::npos)throw std::runtime_error("current shader hooks changed");
    const std::string originalMarchingBody=currentProgram.wgsl.substr(begin,end-begin);
    std::string marchingBody=originalMarchingBody;unsigned emptySupportDiscardAdaptations=0;
    const std::string emptySupportDiscard="if (supportEnd <= supportStart) { discard; }";
    auto emptyExit=marchingBody.find(emptySupportDiscard);
    if(emptyExit!=std::string::npos){
        if(marchingBody.find(emptySupportDiscard,emptyExit+1)!=std::string::npos)throw std::runtime_error("duplicate empty support hook");
        marchingBody.replace(emptyExit,emptySupportDiscard.size(),
            "if (supportEnd <= supportStart) { capturedOutput[idx]=vec4<f32>(0.0,0.0,0.0,1.0);return; }");
        emptySupportDiscardAdaptations=1;
    }
    if(marchingBody.find("discard;")!=std::string::npos)throw std::runtime_error("unadmitted fragment-only operation in compute adapter");
    auto adaptBindings=[](std::string text) {
        auto replace=[&](const std::string& a,const std::string& b){auto pos=text.find(a);if(pos==std::string::npos)throw std::runtime_error("current binding hook");text.replace(pos,a.size(),b);};
        replace("@group(0) @binding(2) var sceneDepthTex: texture_depth_2d;","");
        replace("@group(1) @binding(0)","@group(0) @binding(2)");
        return text;
    };
    const std::string extra=R"WGSL(
struct CapturedRay { ro_clipA:vec4<f32>,rd_clipB:vec4<f32>,counts:vec4<u32> };
@group(0) @binding(3) var<storage,read> capturedRays:array<CapturedRay>;
@group(0) @binding(4) var<storage,read_write> capturedOutput:array<vec4<f32>>;
)WGSL";
    std::string currentShader=adaptBindings(currentProgram.wgsl.substr(0,fs))+extra+R"WGSL(
@compute @workgroup_size(64)
fn rayMain(@builtin(global_invocation_id) gid:vec3<u32>) {
 let idx=gid.x;if(idx>=u32(u.viewport.z)){return;}
 let ray=capturedRays[idx%arrayLength(&capturedRays)];
 let ro=ray.ro_clipA.xyz;let rd=ray.rd_clipB.xyz;
 let t0=ray.ro_clipA.w;let t1=ray.rd_clipB.w;g_instIdx=0u;
)WGSL"+marchingBody+R"WGSL(
 capturedOutput[idx]=vec4<f32>(integratedRadiance,transmittance);
}
)WGSL";
    auto prepShader=adaptBindings(currentProgram.kernelVolumePreparationWgsl)+extra;
    if(currentProgram.kernelVolumePreparationWgsl.empty())throw std::runtime_error("expected native clock preparation");
    auto brace=prepShader.find('{',prepShader.find("fn volumeTimePrepare"));
    prepShader.insert(brace+1,"\n if(u.viewport.w<0.0){capturedOutput[0]=vec4<f32>(f32(capturedRays[0].counts.x));return;}\n");
    if(!outputPath.empty()) {
        std::ofstream a(outputPath+"-current.wgsl");a<<currentShader;
        std::ofstream b(outputPath+"-current-march-body.wgsl");b<<marchingBody;
    }

    // --- WebGPU / Metal Initialization ---
    wgpu::Device gpu;
    gpu.instance = wgpuCreateInstance(nullptr);
    {
        wgpu::detail::AdapterR ar;
        WGPURequestAdapterCallbackInfo acb{};
        acb.mode = WGPUCallbackMode_AllowProcessEvents;
        acb.callback = wgpu::detail::onAdapter;
        acb.userdata1 = &ar;
        wgpuInstanceRequestAdapter(gpu.instance, nullptr, acb);
        while (!ar.done) wgpuInstanceProcessEvents(gpu.instance);
        gpu.adapter = ar.a;

        WGPULimits supportedLimits{};
        wgpuAdapterGetLimits(gpu.adapter, &supportedLimits);

        WGPUDeviceDescriptor dd{};
        dd.requiredLimits = &supportedLimits;

        wgpu::detail::DeviceR dr;
        WGPURequestDeviceCallbackInfo dcb{};
        dcb.mode = WGPUCallbackMode_AllowProcessEvents;
        dcb.callback = wgpu::detail::onDevice;
        dcb.userdata1 = &dr;
        wgpuAdapterRequestDevice(gpu.adapter, &dd, dcb);
        while (!dr.done) wgpuInstanceProcessEvents(gpu.instance);
        gpu.device = dr.d;
        gpu.queue = wgpuDeviceGetQueue(gpu.device);
    }
    std::cout << "WebGPU device initialized successfully on Metal." << std::endl;

    auto makeBuffer = [&](WGPUBufferUsage usage, uint64_t size, const void* data) -> WGPUBuffer {
        WGPUBufferDescriptor desc = {};
        desc.usage = usage;
        desc.size = size;
        WGPUBuffer b = wgpuDeviceCreateBuffer(gpu.device, &desc);
        if (data) wgpuQueueWriteBuffer(gpu.queue, b, 0, data, size);
        return b;
    };

    struct UniformData { float clock; uint32_t rayCount; uint32_t pad0, pad1; };
    UniformData udata{float(clock), (uint32_t)executionRays, 0, 0};

    {   // SURVEYOR: validated capacities against the actual device limits (device was created with adapter limits).
        WGPULimits lim{};
        if (wgpuDeviceGetLimits(gpu.device, &lim) != WGPUStatus_Success) throw std::runtime_error("surveyor: device limits unavailable");
        const uint64_t perBuffer[] = {uint64_t(rayBytes), uint64_t(subpanelBytes), uint64_t(overlapBytes),
                                      uint64_t(count) * sizeof(GpuResult), uint64_t(count) * 4u};
        for (uint64_t b : perBuffer)
            if (b > lim.maxStorageBufferBindingSize || b > lim.maxBufferSize)
                throw std::runtime_error("surveyor: buffer of " + std::to_string(b) + " B exceeds device limits");
        if ((uint64_t(count)+63u)/64u > lim.maxComputeWorkgroupsPerDimension ||
            (uint64_t(numTiles)+63u)/64u > lim.maxComputeWorkgroupsPerDimension ||
            (uint64_t(numTiles)+3u)/4u > lim.maxComputeWorkgroupsPerDimension)
            throw std::runtime_error("surveyor: dispatch workgroups exceed device limits");
        if (uint64_t(count) * std::max(maxSubPerRay, maxOverPerRay) > 0xFFFFFFFFull) throw std::runtime_error("surveyor: u32 ray-slot index overflow");
        std::cerr << "SURVEYOR budget ok: rays=" << count << " tiles=" << numTiles << " subpanelBytes=" << subpanelBytes
                  << " maxStorageBufferBindingSize=" << lim.maxStorageBufferBindingSize << std::endl;
    }
    WGPUBuffer uBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_CopyDst, sizeof(udata), &udata);
    WGPUBuffer mBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, mediaBytes, gpuMedia.data());
    WGPUBuffer pBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, paramBytes, globalParamPool.data());
    WGPUBuffer rBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst | WGPUBufferUsage_CopySrc, rayBytes, gpuRays.data());
    WGPUBuffer sBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst | WGPUBufferUsage_CopySrc, subpanelBytes, nullptr);
    WGPUBuffer oBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst | WGPUBufferUsage_CopySrc, overlapBytes > 0 ? overlapBytes : 16, nullptr);

    size_t outBytes = executionRays * sizeof(GpuResult);
    WGPUBuffer outBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, outBytes, nullptr);
    WGPUBuffer readBuf = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, outBytes, nullptr);

    // Helper to build pipeline
    auto buildPipeline = [&](const std::string& shaderCode) -> WGPUComputePipeline {
        std::string fullCode = std::string(kCommonWgslHeader) + "\n" + kOverlapWgsl + "\n" + shaderCode;
        wgpuDevicePushErrorScope(gpu.device, WGPUErrorFilter_Validation);

        WGPUShaderSourceWGSL src = {};
        src.chain.sType = WGPUSType_ShaderSourceWGSL;
        src.code = wgpu::Device::str(fullCode.c_str());
        WGPUShaderModuleDescriptor smd = {};
        smd.nextInChain = &src.chain;
        WGPUShaderModule sm = wgpuDeviceCreateShaderModule(gpu.device, &smd);

        WGPUComputePipelineDescriptor cpd = {};
        cpd.compute.module = sm;
        cpd.compute.entryPoint = wgpu::Device::str("rayMain");
        WGPUComputePipeline cp = wgpuDeviceCreateComputePipeline(gpu.device, &cpd);

        PopContext compile;
        WGPUPopErrorScopeCallbackInfo pcb = {};
        pcb.mode = WGPUCallbackMode_AllowProcessEvents;
        pcb.callback = onPopError;
        pcb.userdata1 = &compile;
        wgpuDevicePopErrorScope(gpu.device, pcb);
        while (!compile.done) wgpuDevicePoll(gpu.device, true, nullptr);

        wgpuShaderModuleRelease(sm);
        if (compile.type != WGPUErrorType_NoError) {
            std::cerr << "Failed to compile shader module" << std::endl;
            return nullptr;
        }
        return cp;
    };

    std::cout << "Compiling Unfused A* Metal Compute Pipeline..." << std::endl;
    WGPUComputePipeline cpUnfused = buildPipeline(kUnfusedShader);
    std::cout << "Compiling Fused A* Metal Compute Pipeline..." << std::endl;
    WGPUComputePipeline cpFused = buildPipeline(kFusedShader);

    if (!cpUnfused || !cpFused) {
        std::cerr << "Pipeline creation failed!" << std::endl;
        return 1;
    }

    // Helper to create bind group
    auto makeBindGroup = [&](WGPUComputePipeline cp) -> WGPUBindGroup {
        WGPUBindGroupLayout bgl = wgpuComputePipelineGetBindGroupLayout(cp, 0);
        WGPUBindGroupEntry entries[7] = {};
        entries[0].binding = 0; entries[0].buffer = uBuf; entries[0].size = sizeof(udata);
        entries[1].binding = 1; entries[1].buffer = mBuf; entries[1].size = mediaBytes;
        entries[2].binding = 2; entries[2].buffer = pBuf; entries[2].size = paramBytes;
        entries[3].binding = 3; entries[3].buffer = rBuf; entries[3].size = rayBytes;
        entries[4].binding = 4; entries[4].buffer = sBuf; entries[4].size = subpanelBytes;
        entries[5].binding = 5; entries[5].buffer = oBuf; entries[5].size = overlapBytes > 0 ? overlapBytes : 16;
        entries[6].binding = 6; entries[6].buffer = outBuf; entries[6].size = outBytes;

        WGPUBindGroupDescriptor bgd = {};
        bgd.layout = bgl;
        bgd.entryCount = 7;
        bgd.entries = entries;
        WGPUBindGroup bg = wgpuDeviceCreateBindGroup(gpu.device, &bgd);
        wgpuBindGroupLayoutRelease(bgl);
        return bg;
    };

    WGPUBindGroup bgUnfused = makeBindGroup(cpUnfused);
    WGPUBindGroup bgFused = makeBindGroup(cpFused);

    std::vector<GpuCurtainSpec> curtainSpecs;
    if (!extractCurtainSpecs(zone, curtainSpecs)) {
        throw std::runtime_error("Failed to dynamically extract curtain specs from zone");
    }

    struct GpuProducerConfig {
        uint32_t rayCount;
        uint32_t maxSubPerRay;
        uint32_t maxOverPerRay;
        uint32_t pad;
    } cfg{static_cast<uint32_t>(count), maxSubPerRay, maxOverPerRay, std::getenv("EC_GPU_BUDGET")?uint32_t(std::stoul(std::getenv("EC_GPU_BUDGET"))):1024u};


    const std::string geometryCase=std::getenv("EC_GPU_GEOMETRY_CASE")?std::getenv("EC_GPU_GEOMETRY_CASE"):"";
    if(!geometryCase.empty()){
        for(auto& spec:curtainSpecs){spec.origin=glm::vec4(1000,1000,1000,0);spec.half=glm::vec4(1);}
        auto& spec=curtainSpecs[0];spec.origin=glm::vec4(0);spec.half=glm::vec4(100);
        spec.amps=glm::vec4(0);spec.freqs=glm::vec4(0);spec.phases=glm::vec4(0);
        if(geometryCase=="near-parallel"){
            spec.limits={1,10,0,30};spec.curv={0,.001f,0,0};
            for(auto& ray:gpuRays){ray.ro[0]=1.000001f;ray.ro[1]=ray.ro[2]=0;ray.rd[0]=-1e-7f;ray.rd[1]=0;ray.rd[2]=1;ray.clipA=0;ray.clipB=20;}
        }else{
            spec.limits={2,2,0,geometryCase=="narrow-lobe"?5e-6f:.2f};
            spec.curv={geometryCase=="narrow-lobe"?10000.f:40000.f,.001f,0,0};
            if(geometryCase=="narrow-lobe"){spec.amps.y=1;spec.freqs.y=100;spec.phases.y=-.7f;}
            else {spec.amps.x=1;spec.freqs.x=200;}
            for(auto& ray:gpuRays){ray.ro[0]=ray.ro[1]=0;ray.ro[2]=geometryCase=="narrow-lobe"?-.99999f:0.f;
                ray.rd[0]=1;ray.rd[1]=ray.rd[2]=0;ray.clipA=0;ray.clipB=1;}
        }
        wgpuQueueWriteBuffer(gpu.queue,rBuf,0,gpuRays.data(),rayBytes);
    }

    auto cfgBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_CopyDst, sizeof(cfg), &cfg);
    auto specBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, curtainSpecs.size() * sizeof(GpuCurtainSpec), curtainSpecs.data());

    auto buildCompute = [&](const std::string& text, const char* entry) {
        wgpuDevicePushErrorScope(gpu.device, WGPUErrorFilter_Validation);
        WGPUShaderSourceWGSL code = {}; code.chain.sType = WGPUSType_ShaderSourceWGSL;
        code.code = wgpu::Device::str(text.c_str());
        WGPUShaderModuleDescriptor md = {}; md.nextInChain = &code.chain;
        auto module = wgpuDeviceCreateShaderModule(gpu.device, &md);
        WGPUComputePipelineDescriptor pd = {}; pd.compute.module = module;
        pd.compute.entryPoint = wgpu::Device::str(entry);
        auto pipeline = wgpuDeviceCreateComputePipeline(gpu.device, &pd);
        wgpuShaderModuleRelease(module);
        PopContext error;
        WGPUPopErrorScopeCallbackInfo cb = {}; cb.mode = WGPUCallbackMode_AllowProcessEvents;
        cb.callback = onPopError; cb.userdata1 = &error;
        wgpuDevicePopErrorScope(gpu.device, cb);
        while (!error.done) wgpuDevicePoll(gpu.device, true, nullptr);
        if (error.type != WGPUErrorType_NoError || !pipeline)
            throw std::runtime_error("compute pipeline creation failed");
        return pipeline;
    };

static const char* kFastPathFullShader = R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<storage,read> curtains:array<CurtainSpec,4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;
fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}
fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 // Bands describe uncertainty sets, not distinct roots. Merge only
 // intersecting/touching bands; never bridge an unrepresented gap.
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}
// The curvature/endpoint model is explicit. A bin must be monotone before
// bisection can resolve it. Exhaustion never becomes an isolated midpoint.

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}
fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  stack[0] = vec4f(a, b, phi_a0, phi_b0); setDepth(&depthBits, 0u, 0u); top = 1u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if ((va > error && vb < -error) || (va < -error && vb > error)) {
     var l = a; var r = b; var left = va;
     for (var iter = 0u; iter < 32u; iter++) {
      if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
      let mid = l + 0.5 * (r - l);
      if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
      let v = evalPhi(m, o, d, mid) - c;
      if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
      if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
     }
     putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
    }
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

@compute @workgroup_size(64)
fn producerFastMain(@builtin(global_invocation_id) gid: vec3u) {
 let id = gid.x; if (id >= cfg.rayCount) { return; }
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 4u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   // Reuse exactly the affine-knot arithmetic used when inserting knots above.
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
  var ne = 0u;
 var head = vec4u(0u);
 let totalKnots = (memCount.x + memCount.y + memCount.z + memCount.w) * 2u;
 loop {
  if (ne >= totalKnots) { break; }
  var bestM = 4u;
  var bestVal = 0.0;
  for (var m = 0u; m < 4u; m++) {
   let h = head[m];
   if (h < memCount[m] * 2u) {
    let pIdx = memStart[m] + (h >> 1u);
    let isY = (h & 1u) != 0u;
    let val = select(pieces[pIdx].x, pieces[pIdx].y, isY);
    if (bestM == 4u || val < bestVal) {
     bestVal = val;
     bestM = m;
    }
   }
  }
  knots[ne] = bestVal;
  ne++;
  head[bestM]++;
 }
 var singles = 0u; var overs = 0u;
 var pIdx = vec4u(0u);
 for (var i = 1u; i < ne && reason == 0u; i++) {
  let a = knots[i - 1u]; let b = knots[i]; if (!(b > a)) { continue; }
  let mid = a + 0.5 * (b - a);
  var mask = 0u;
  for (var m = 0u; m < 4u; m++) {
   let start = memStart[m];
   let numPieces = memCount[m];
   var cur = pIdx[m];
   loop {
    if (cur >= numPieces || pieces[start + cur].y >= mid) { break; }
    cur++;
   }
   pIdx[m] = cur;
   if (cur < numPieces) {
    let p = pieces[start + cur];
    if (mid >= p.x && mid <= p.y) {
     mask |= (1u << m);
    }
   }
  }
  if (mask == 0u) { continue; }
  if (countOneBits(mask) == 1u) {
   let n = max(1u, u32(ceil((b - a) / 4.0)));
   if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
   let member = firstTrailingBit(mask);
   for (var k = 0u; k < n; k++) {
    let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
    let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
    subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(member, 0)); singles++;
   }
  } else {
   if (overs >= cfg.maxOverPerRay) { reason |= 32u; break; }
   overlaps[overBase + overs] = Overlap(vec2f(a, b), vec2u(mask, 0)); overs++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, overs); }
}
)WGSL";

static const char* kFastPathCompactShader = R"WGSL(
struct CurtainSpec {origin:vec4f,half:vec4f,limits:vec4f,curv:vec4f,amps:vec4f,freqs:vec4f,phases:vec4f};
struct Ray {ro_clipA:vec4f,rd_clipB:vec4f,counts:vec4u};
struct Subpanel {span:vec2f,info:vec2u};
struct Overlap {span:vec2f,info:vec2u};
struct Config {rayCount:u32,maxSubPerRay:u32,maxOverPerRay:u32,budget:u32};
@group(0) @binding(0) var<uniform> cfg:Config;
@group(0) @binding(1) var<storage,read> curtains:array<CurtainSpec,4>;
@group(0) @binding(2) var<storage,read_write> rays:array<Ray>;
@group(0) @binding(3) var<storage,read_write> subpanels:array<Subpanel>;
@group(0) @binding(4) var<storage,read_write> overlaps:array<Overlap>;
const FALLBACK:u32=0x80000000u;
fn evalWave(m:CurtainSpec,x:f32)->f32 {
 return m.amps.x*sin(m.freqs.x*x+m.phases.x)+m.amps.y*cos(m.freqs.y*x+m.phases.y)+m.amps.z*sin(m.freqs.z*x+m.phases.z);
}
fn evalPhi(m:CurtainSpec,o:vec3f,d:vec3f,s:f32)->f32{return o.z+s*d.z+evalWave(m,o.x+s*d.x);}
fn putBand(lo:f32,hi:f32,bounds:ptr<function,array<f32,96>>,nb:ptr<function,u32>,
 bands:ptr<function,array<vec2f,32>>,nr:ptr<function,u32>,reason:ptr<function,u32>){
 // Bands describe uncertainty sets, not distinct roots. Merge only
 // intersecting/touching bands; never bridge an unrepresented gap.
 if(*nr>0u){
  let last=(*bands)[*nr-1u];
  if(lo<=last.y && hi>=last.x){
   let merged=vec2f(min(lo,last.x),max(hi,last.y));
   (*bands)[*nr-1u]=merged;
   (*bounds)[*nb-2u]=merged.x;(*bounds)[*nb-1u]=merged.y;return;
  }
 }
 if(*nb+2u>92u || *nr>=32u){*reason|=2u;return;}
 (*bounds)[*nb]=lo;(*bounds)[*nb+1u]=hi;*nb+=2u;
 (*bands)[*nr]=vec2f(lo,hi);*nr+=1u;
}
// The curvature/endpoint model is explicit. A bin must be monotone before
// bisection can resolve it. Exhaustion never becomes an isolated midpoint.

fn mayAbsorb(previous: vec2f, current: vec2f, previousShortBand: bool,
 previousPositive: bool, currentUncertain: bool, protectedBoundary: bool) -> bool {
 if (protectedBoundary || previous.y != current.x) { return false; }
 let currentShortBand = currentUncertain && current.y - current.x <= 0.02;
 return (previousShortBand && !currentUncertain) || (previousPositive && currentShortBand);
}

fn putBandTagged(lo: f32, hi: f32, bounds: ptr<function, array<f32, 96>>,
 nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>,
 zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 putBand(lo, hi, bounds, nb, bands, nr, reason);
 if (*reason == 0u && isZeroLevel && *nr > 0u) { *zeroBands |= 1u << (*nr - 1u); }
}
fn getDepth(bits: vec3u, idx: u32) -> u32 {
 return (bits[idx >> 3u] >> ((idx & 7u) << 2u)) & 15u;
}
fn setDepth(bits: ptr<function, vec3u>, idx: u32, d: u32) {
 let w = idx >> 3u; let s = (idx & 7u) << 2u;
 (*bits)[w] = ((*bits)[w] & ~(15u << s)) | ((d & 15u) << s);
}

fn roots(m: CurtainSpec, o: vec3f, d: vec3f, lo: f32, hi: f32, c: f32,
 bounds: ptr<function, array<f32, 96>>, nb: ptr<function, u32>, bands: ptr<function, array<vec2f, 32>>,
 nr: ptr<function, u32>, reason: ptr<function, u32>, work: ptr<function, u32>,
 phi_knots: ptr<function, array<f32, 9>>, zeroBands: ptr<function, u32>, isZeroLevel: bool) {
 let M = m.curv.x * d.x * d.x * 1.00002;
 let err = m.curv.y;
 var stack: array<vec4f, 20>; var depthBits = vec3u(0u); var top = 0u;
 for (var bin = 0u; bin < 8u; bin++) {
  var a = lo + (hi - lo) * f32(bin) / 8.0; var b = lo + (hi - lo) * f32(bin + 1u) / 8.0;
  if (bin == 0u) { a = lo; } if (bin == 7u) { b = hi; }
  let phi_a0 = (*phi_knots)[bin]; let phi_b0 = (*phi_knots)[bin + 1u];
  // Exact existing level-specific depth0 predicate, before private stack use.
        if (*work >= cfg.budget) { *reason |= 1u; break; }
        let coarseH = b - a;
        if (!(coarseH > 0.0)) { *work += 1u; *reason |= 4u; break; }
        let coarseVa = phi_a0 - c; let coarseVb = phi_b0 - c;
        let coarseScale = 1.0 + abs(coarseVa) + abs(coarseVb) + abs(a) + abs(b);
        let coarseArithmetic = 0.000001 * coarseScale;
        let coarseError = err + coarseArithmetic;
        let coarseBow = 0.125 * M * coarseH * coarseH + coarseError;
        if (min(coarseVa, coarseVb) > coarseBow || max(coarseVa, coarseVb) < -coarseBow) { *work += 1u; continue; }
        stack[0] = vec4f(a, b, phi_a0, phi_b0); setDepth(&depthBits, 0u, 0u); top = 1u;
  loop {
   if (top == 0u || *reason != 0u) { break; }
   top--; let cell = stack[top]; a = cell.x; b = cell.y; let h = b - a;
   let depth = getDepth(depthBits, top);
   if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
   if (!(h > 0.0)) { *reason |= 4u; break; }
   let va = cell.z - c; let vb = cell.w - c;
   let scale = 1.0 + abs(va) + abs(vb) + abs(a) + abs(b);
   let arithmetic = 0.000001 * scale;
   let error = err + arithmetic;
   let bow = 0.125 * M * h * h + error;
   if (min(va, vb) > bow || max(va, vb) < -bow) { continue; }
   let slope = (vb - va) / h; let radius = 0.5 * M * h + 2.0 * error / h;
   let minSlope = abs(slope) - radius;
   if (minSlope > 0.0) {
    if (abs(va) <= error) { let w = 2.0 * error / minSlope; putBandTagged(a, min(b, a + w), bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if (abs(vb) <= error) { let w = 2.0 * error / minSlope; putBandTagged(max(a, b - w), b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); }
    if ((va > error && vb < -error) || (va < -error && vb > error)) {
     var l = a; var r = b; var left = va;
     for (var iter = 0u; iter < 32u; iter++) {
      if (*work >= cfg.budget) { *reason |= 1u; break; } *work += 1u;
      let mid = l + 0.5 * (r - l);
      if (mid <= l || mid >= r || r - l <= 0.0001) { break; }
      let v = evalPhi(m, o, d, mid) - c;
      if (abs(v) <= error) { let w = 2.0 * error / minSlope; l = max(l, mid - w); r = min(r, mid + w); break; }
      if ((left < 0.0 && v > 0.0) || (left > 0.0 && v < 0.0)) { r = mid; } else { l = mid; left = v; }
     }
     putBandTagged(l, r, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel);
    }
    continue;
   }
   if (0.125 * M * h * h <= error) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   if (f32(depth) >= 14.0 || top + 2u > 20u) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let mid = a + 0.5 * h; if (mid <= a || mid >= b) { putBandTagged(a, b, bounds, nb, bands, nr, reason, zeroBands, isZeroLevel); continue; }
   let phi_mid = evalPhi(m, o, d, mid);
   stack[top] = vec4f(mid, b, phi_mid, cell.w); setDepth(&depthBits, top, depth + 1u);
   stack[top + 1u] = vec4f(a, mid, cell.z, phi_mid); setDepth(&depthBits, top + 1u, depth + 1u);
   top += 2u;
  }
  if (*reason != 0u) { break; }
 }
}

fn getMember(pm: vec3u, k: u32) -> u32 {
 return (pm[k >> 4u] >> ((k & 15u) << 1u)) & 3u;
}
fn setMember(pm: ptr<function, vec3u>, k: u32, m: u32) {
 let w = k >> 4u; let s = (k & 15u) << 1u;
 (*pm)[w] = ((*pm)[w] & ~(3u << s)) | ((m & 3u) << s);
}

@compute @workgroup_size(64)
fn producerFastMain(@builtin(global_invocation_id) gid: vec3u) {
 let id = gid.x; if (id >= cfg.rayCount) { return; }
 let input = rays[id]; let ro = input.ro_clipA.xyz; let d = input.rd_clipB.xyz;
 let subBase = id * cfg.maxSubPerRay; let overBase = id * cfg.maxOverPerRay;
 var reason = 0u; var work = 0u; var count = 0u;
 var pieces: array<vec2f, 48>; var pieceMembers = vec3u(0u);
 var knots: array<f32, 96>;
 var memStart = vec4u(0u); var memCount = vec4u(0u);
 if (cfg.budget == 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | 1u); return; }
 for (var member = 0u; member < 4u; member++) {
  memStart[member] = count;
  let m = curtains[member]; let o = ro - m.origin.xyz;
  var a = input.ro_clipA.w; var b = input.rd_clipB.w; var hit = true;
  for (var axis = 0u; axis < 3u; axis++) {
   var half = m.half[axis];
   if (axis == 0u) { half = min(half, m.limits.x); } if (axis == 1u) { half = min(half, m.limits.y); }
   if (d[axis] == 0.0) { if (abs(o[axis]) > half + m.curv.y) { hit = false; break; } }
   else {
    let q0 = (-half - m.curv.y - o[axis]) / d[axis]; let q1 = (half + m.curv.y - o[axis]) / d[axis];
    a = max(a, min(q0, q1)); b = min(b, max(q0, q1));
   }
  }
  if (!hit || !(b > a)) { continue; }
  var nb = 1u; knots[0] = a;
  var bands: array<vec2f, 32>; var nr = 0u; var zeroBands = 0u;
  var phi_knots: array<f32, 9>;
  for (var k = 0u; k < 9u; k++) {
   var s = a + (b - a) * f32(k) / 8.0;
   if (k == 0u) { s = a; } if (k == 8u) { s = b; }
   phi_knots[k] = evalPhi(m, o, d, s);
  }
  roots(m, o, d, a, b, -m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, 0.0, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, true);
  if (reason != 0u) { break; }
  roots(m, o, d, a, b, m.limits.w, &knots, &nb, &bands, &nr, &reason, &work, &phi_knots, &zeroBands, false);
  if (reason != 0u) { break; }
  if (d.x != 0.0) { let x = -o.x / d.x; if (x > a && x < b) { knots[nb] = x; nb++; } }
  if (d.y != 0.0) {
   let y = -o.y / d.y; if (y > a && y < b) { knots[nb] = y; nb++; }
   let k = (m.limits.z - o.y) / d.y; if (k > a && k < b) { knots[nb] = k; nb++; }
  }
  knots[nb] = b; nb++;
  for (var i = 1u; i < nb; i++) {
   let v = knots[i]; var j = i; loop { if (j == 0u || knots[j - 1u] <= v) { break; } knots[j] = knots[j - 1u]; j--; }
   knots[j] = v;
  }
  let memberStart = count; var previousShortBand = false; var previousPositive = false;
  for (var i = 1u; i < nb; i++) {
   let l = knots[i - 1u]; let r = knots[i]; if (!(r > l)) { continue; }
   let mid = l + 0.5 * (r - l); var uncertain = false; var protectedBoundary = false;
   // Reuse exactly the affine-knot arithmetic used when inserting knots above.
   if (d.x != 0.0) { protectedBoundary = l == -o.x / d.x; }
   if (d.y != 0.0) { protectedBoundary = protectedBoundary || l == -o.y / d.y || l == (m.limits.z - o.y) / d.y; }
   for (var k = 0u; k < nr; k++) {
    uncertain = uncertain || (l < bands[k].y && r > bands[k].x);
    if ((zeroBands & (1u << k)) != 0u && (l == bands[k].x || l == bands[k].y)) { protectedBoundary = true; }
   }
   if (uncertain || abs(evalPhi(m, o, d, mid)) <= m.limits.w + m.curv.y) {
    if (count > memberStart && mayAbsorb(pieces[count - 1u], vec2f(l, r),
         previousShortBand, previousPositive, uncertain, protectedBoundary)) {
     pieces[count - 1u].y = r; previousShortBand = false; previousPositive = true;
    } else {
     if (count >= 48u) { reason |= 8u; break; }
     pieces[count] = vec2f(l, r);
     setMember(&pieceMembers, count, member);
     count++; previousShortBand = uncertain && r - l <= 0.02; previousPositive = !uncertain;
    }
   }
  }
  memCount[member] = count - memStart[member];
  if (reason != 0u) { break; }
 }
  var ne = 0u;
 var head = vec4u(0u);
 let totalKnots = (memCount.x + memCount.y + memCount.z + memCount.w) * 2u;
 loop {
  if (ne >= totalKnots) { break; }
  var bestM = 4u;
  var bestVal = 0.0;
  for (var m = 0u; m < 4u; m++) {
   let h = head[m];
   if (h < memCount[m] * 2u) {
    let pIdx = memStart[m] + (h >> 1u);
    let isY = (h & 1u) != 0u;
    let val = select(pieces[pIdx].x, pieces[pIdx].y, isY);
    if (bestM == 4u || val < bestVal) {
     bestVal = val;
     bestM = m;
    }
   }
  }
  knots[ne] = bestVal;
  ne++;
  head[bestM]++;
 }
 var singles = 0u; var overs = 0u;
 var pIdx = vec4u(0u);
 for (var i = 1u; i < ne && reason == 0u; i++) {
  let a = knots[i - 1u]; let b = knots[i]; if (!(b > a)) { continue; }
  let mid = a + 0.5 * (b - a);
  var mask = 0u;
  for (var m = 0u; m < 4u; m++) {
   let start = memStart[m];
   let numPieces = memCount[m];
   var cur = pIdx[m];
   loop {
    if (cur >= numPieces || pieces[start + cur].y >= mid) { break; }
    cur++;
   }
   pIdx[m] = cur;
   if (cur < numPieces) {
    let p = pieces[start + cur];
    if (mid >= p.x && mid <= p.y) {
     mask |= (1u << m);
    }
   }
  }
  if (mask == 0u) { continue; }
  if (countOneBits(mask) == 1u) {
   let n = max(1u, u32(ceil((b - a) / 4.0)));
   if (singles + n > cfg.maxSubPerRay) { reason |= 16u; break; }
   let member = firstTrailingBit(mask);
   for (var k = 0u; k < n; k++) {
    let l = select(a + f32(k) * (b - a) / f32(n), a, k == 0u);
    let r = select(a + f32(k + 1u) * (b - a) / f32(n), b, k + 1u == n);
    subpanels[subBase + singles] = Subpanel(vec2f(l, r), vec2u(member, 0)); singles++;
   }
  } else {
   if (overs >= cfg.maxOverPerRay) { reason |= 32u; break; }
   overlaps[overBase + overs] = Overlap(vec2f(a, b), vec2u(mask, 0)); overs++;
  }
 }
 if (reason != 0u) { rays[id].counts = vec4u(subBase, 0, overBase, FALLBACK | reason); }
 else { rays[id].counts = vec4u(subBase, singles, overBase, overs); }
}
)WGSL";

    auto cpProducer = buildCompute(kGpuProducerWgsl, "producerMain");
    auto cpFastFull = buildCompute(kFastPathFullShader, "producerFastMain");
    auto cpFastCompact = buildCompute(kFastPathCompactShader, "producerFastMain");
    // §6du True Terminal S1 & Mode 2 Frozen §6dr Routed Unfused Buffers & Pipelines
    auto offBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, tileOffsets.size() * sizeof(uint32_t), tileOffsets.data());
    auto idxBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst, tileRayIndices.size() * sizeof(uint32_t), tileRayIndices.data());

    std::vector<uint32_t> initList(numTiles, 0u);
    auto s1TileBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, numTiles * sizeof(uint32_t), initList.data());
    auto s2TileBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, numTiles * sizeof(uint32_t), initList.data());
    auto fbTileBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, numTiles * sizeof(uint32_t), initList.data());

    struct alignas(16) DispatchCounters { uint32_t s1, s2, fb, pad; };
    DispatchCounters initCnt{0, 0, 0, 0};
    auto cntBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, sizeof(initCnt), &initCnt);
    auto argsBuf = makeBuffer(WGPUBufferUsage_Storage | WGPUBufferUsage_Indirect | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst, 36, nullptr);

    decltype(cfg) forcedCfg = cfg;
    forcedCfg.pad = 0;
    auto forcedCfgBuf = makeBuffer(WGPUBufferUsage_Uniform | WGPUBufferUsage_CopyDst, sizeof(forcedCfg), &forcedCfg);

    auto cpReset = buildCompute(kResetCountersWgsl, "resetCountersMain");
    auto cpClassify = buildCompute(kClassifyWgsl, "classifyTilesMain");
    auto cpArgs = buildCompute(kRouteArgsWgsl, "routeArgs");
    auto cpS1Unfused = buildCompute(kS1UnfusedProducerWgsl, "s1ProducerMain");
    auto cpS1Terminal = buildCompute(kS1TerminalProducerWgsl, "s1ProducerMain");
    auto cpS2 = buildCompute(kS2ProducerWgsl, "s2ProducerMain");
    auto cpFallback = buildCompute(kFallbackProducerWgsl, "fallbackProducerMain");
    auto cpS2Terminal = buildCompute(kS2TerminalProducerWgsl, "s2TerminalProducerMain");
    auto cpFallbackConsumer = buildCompute(std::string(kCommonWgslHeader) + "\n" + kOverlapWgsl + "\n" + kFallbackConsumerWgsl, "fallbackConsumerMain");

    auto makeEntry = [](uint32_t binding, WGPUBuffer buffer, uint64_t offset, uint64_t size) -> WGPUBindGroupEntry {
        WGPUBindGroupEntry e{};
        e.binding = binding; e.buffer = buffer; e.offset = offset; e.size = size;
        return e;
    };
    auto makeGroup = [&](WGPUComputePipeline cp, const std::vector<WGPUBindGroupEntry>& entries) -> WGPUBindGroup {
        auto layout = wgpuComputePipelineGetBindGroupLayout(cp, 0);
        WGPUBindGroupDescriptor d{};
        d.layout = layout;
        d.entryCount = entries.size();
        d.entries = entries.data();
        auto bg = wgpuDeviceCreateBindGroup(gpu.device, &d);
        wgpuBindGroupLayoutRelease(layout);
        if (!bg) throw std::runtime_error("bind group creation failed");
        return bg;
    };

    auto bgReset = makeGroup(cpReset, { makeEntry(0, cntBuf, 0, sizeof(initCnt)) });
    auto bgClassify = makeGroup(cpClassify, {
        makeEntry(0, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(1, rBuf, 0, rayBytes),
        makeEntry(2, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(3, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(4, s1TileBuf, 0, numTiles * 4),
        makeEntry(5, s2TileBuf, 0, numTiles * 4),
        makeEntry(6, fbTileBuf, 0, numTiles * 4),
        makeEntry(7, cntBuf, 0, sizeof(initCnt))
    });
    auto bgArgs = makeGroup(cpArgs, {
        makeEntry(0, cntBuf, 0, sizeof(initCnt)),
        makeEntry(1, argsBuf, 0, 36)
    });

    // Mode 2: Unfused S1 Producer Bind Groups (writes subpanels to sBuf)
    auto bgS1Unfused = makeGroup(cpS1Unfused, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s1TileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });
    auto bgS1UnfusedForced = makeGroup(cpS1Unfused, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s1TileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });

    // Mode 3: Terminal S1 Producer Bind Groups (evaluates quadrature in-producer, writes results[id])
    auto bgS1Terminal = makeGroup(cpS1Terminal, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(4, outBuf, 0, outBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s1TileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt)),
        makeEntry(9, mBuf, 0, mediaBytes),
        makeEntry(10, pBuf, 0, paramBytes)
    });
    auto bgS1TerminalForced = makeGroup(cpS1Terminal, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(4, outBuf, 0, outBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s1TileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt)),
        makeEntry(9, mBuf, 0, mediaBytes),
        makeEntry(10, pBuf, 0, paramBytes)
    });

    auto bgS2 = makeGroup(cpS2, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s2TileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });
    auto bgS2Forced = makeGroup(cpS2, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s2TileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });

    auto bgFallback = makeGroup(cpFallback, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(4, oBuf, 0, overlapBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, fbTileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });
    auto bgFallbackForced = makeGroup(cpFallback, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(3, sBuf, 0, subpanelBytes),
        makeEntry(4, oBuf, 0, overlapBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, fbTileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt))
    });
    auto bgS2Terminal = makeGroup(cpS2Terminal, {
        makeEntry(0, cfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(4, outBuf, 0, outBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s2TileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt)),
        makeEntry(9, mBuf, 0, mediaBytes),
        makeEntry(10, pBuf, 0, paramBytes)
    });
    auto bgS2TerminalForced = makeGroup(cpS2Terminal, {
        makeEntry(0, forcedCfgBuf, 0, sizeof(cfg)),
        makeEntry(1, specBuf, 0, curtainSpecs.size() * sizeof(GpuCurtainSpec)),
        makeEntry(2, rBuf, 0, rayBytes),
        makeEntry(4, outBuf, 0, outBytes),
        makeEntry(5, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(6, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(7, s2TileBuf, 0, numTiles * 4),
        makeEntry(8, cntBuf, 0, sizeof(initCnt)),
        makeEntry(9, mBuf, 0, mediaBytes),
        makeEntry(10, pBuf, 0, paramBytes)
    });
    auto bgFallbackConsumer = makeGroup(cpFallbackConsumer, {
        makeEntry(0, uBuf, 0, sizeof(udata)),
        makeEntry(1, mBuf, 0, mediaBytes),
        makeEntry(2, pBuf, 0, paramBytes),
        makeEntry(3, rBuf, 0, rayBytes),
        makeEntry(4, sBuf, 0, subpanelBytes),
        makeEntry(5, oBuf, 0, overlapBytes > 0 ? overlapBytes : 16),
        makeEntry(6, outBuf, 0, outBytes),
        makeEntry(8, offBuf, 0, tileOffsets.size() * sizeof(uint32_t)),
        makeEntry(9, idxBuf, 0, tileRayIndices.size() * sizeof(uint32_t)),
        makeEntry(10, fbTileBuf, 0, numTiles * 4),
        makeEntry(11, cntBuf, 0, sizeof(initCnt))
    });




    WGPUBindGroupEntry bgpEntries[5] = {};
    bgpEntries[0].binding = 0; bgpEntries[0].buffer = cfgBuf; bgpEntries[0].size = sizeof(cfg);
    bgpEntries[1].binding = 1; bgpEntries[1].buffer = specBuf; bgpEntries[1].size = curtainSpecs.size() * sizeof(GpuCurtainSpec);
    bgpEntries[2].binding = 2; bgpEntries[2].buffer = rBuf; bgpEntries[2].size = rayBytes;
    bgpEntries[3].binding = 3; bgpEntries[3].buffer = sBuf; bgpEntries[3].size = subpanelBytes;
    bgpEntries[4].binding = 4; bgpEntries[4].buffer = oBuf; bgpEntries[4].size = overlapBytes;

    WGPUBindGroupDescriptor bgpd = {};
    bgpd.layout = wgpuComputePipelineGetBindGroupLayout(cpProducer, 0);
    bgpd.entryCount = 5;
    bgpd.entries = bgpEntries;
    WGPUBindGroup bgProducer = wgpuDeviceCreateBindGroup(gpu.device, &bgpd);

    // Initial dispatch of GPU producer to populate sBuf, oBuf, and rBuf
    {
        auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        auto pass = wgpuCommandEncoderBeginComputePass(enc, nullptr);
        wgpuComputePassEncoderSetPipeline(pass, cpProducer);
        wgpuComputePassEncoderSetBindGroup(pass, 0, bgProducer, 0, nullptr);
        wgpuComputePassEncoderDispatchWorkgroups(pass, (count + 63) / 64, 1, 1);
        wgpuComputePassEncoderEnd(pass);
        wgpuComputePassEncoderRelease(pass);
        auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuCommandEncoderRelease(enc);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device, true, nullptr);
    }

    // Read back GPU producer schedule to CPU for independent AST arithmetic comparison
    {
        auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        auto readSub = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, subpanelBytes, nullptr);
        auto readOver = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, overlapBytes, nullptr);
        auto readRay = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, rayBytes, nullptr);
        wgpuCommandEncoderCopyBufferToBuffer(enc, sBuf, 0, readSub, 0, subpanelBytes);
        wgpuCommandEncoderCopyBufferToBuffer(enc, oBuf, 0, readOver, 0, overlapBytes);
        wgpuCommandEncoderCopyBufferToBuffer(enc, rBuf, 0, readRay, 0, rayBytes);
        auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuCommandEncoderRelease(enc);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device, true, nullptr);

        MapContext mc1, mc2, mc3;
        WGPUBufferMapCallbackInfo mci1 = {}, mci2 = {}, mci3 = {};
        mci1.mode = WGPUCallbackMode_AllowProcessEvents; mci1.callback = onMapped; mci1.userdata1 = &mc1;
        mci2.mode = WGPUCallbackMode_AllowProcessEvents; mci2.callback = onMapped; mci2.userdata1 = &mc2;
        mci3.mode = WGPUCallbackMode_AllowProcessEvents; mci3.callback = onMapped; mci3.userdata1 = &mc3;

        wgpuBufferMapAsync(readRay, WGPUMapMode_Read, 0, rayBytes, mci1);
        wgpuBufferMapAsync(readSub, WGPUMapMode_Read, 0, subpanelBytes, mci2);
        wgpuBufferMapAsync(readOver, WGPUMapMode_Read, 0, overlapBytes, mci3);
        while (!mc1.done || !mc2.done || !mc3.done) wgpuDevicePoll(gpu.device, true, nullptr);
        if(!mc1.ok||!mc2.ok||!mc3.ok)throw std::runtime_error("producer readback mapping failed");

        auto* mappedRays = static_cast<const GpuRayHeader*>(wgpuBufferGetConstMappedRange(readRay, 0, rayBytes));
        auto* mappedSubs = static_cast<const GpuSubpanel*>(wgpuBufferGetConstMappedRange(readSub, 0, subpanelBytes));
        auto* mappedOvers = static_cast<const GpuOverlap*>(wgpuBufferGetConstMappedRange(readOver, 0, overlapBytes));

        gpuSubpanels.clear();
        gpuOverlaps.clear();
        maxSubpanelsPerRay = 0;

        for (size_t i = 0; i < count; ++i) {
            gpuRays[i].ro[0] = mappedRays[i].ro[0];
            gpuRays[i].ro[1] = mappedRays[i].ro[1];
            gpuRays[i].ro[2] = mappedRays[i].ro[2];
            gpuRays[i].clipA = mappedRays[i].clipA;
            gpuRays[i].rd[0] = mappedRays[i].rd[0];
            gpuRays[i].rd[1] = mappedRays[i].rd[1];
            gpuRays[i].rd[2] = mappedRays[i].rd[2];
            gpuRays[i].clipB = mappedRays[i].clipB;

            uint32_t sBase = mappedRays[i].subpanelOffset;

            producerFlags[i]=mappedRays[i].overlapCount;
            const bool refused=(producerFlags[i]&0x80000000u)!=0;
            uint32_t sCount = mappedRays[i].subpanelCount;
            if(refused&&sCount!=0)throw std::runtime_error("partial fallback schedule");

            uint32_t oBase = mappedRays[i].overlapOffset;

            uint32_t oCount = refused?0:mappedRays[i].overlapCount;
            if(sCount>maxSubPerRay||oCount>maxOverPerRay||sBase+sCount>totalSub||oBase+oCount>totalOver)
                throw std::runtime_error("producer output exceeds allocated bounds");


            gpuRays[i].subpanelOffset = gpuSubpanels.size();
            gpuRays[i].subpanelCount = sCount;
            gpuRays[i].overlapOffset = gpuOverlaps.size();
            gpuRays[i].overlapCount = oCount;
            maxSubpanelsPerRay = std::max(maxSubpanelsPerRay, sCount);

            for (uint32_t s = 0; s < sCount; ++s) {
                gpuSubpanels.push_back(mappedSubs[sBase + s]);
            }
            for (uint32_t o = 0; o < oCount; ++o) {
                gpuOverlaps.push_back(mappedOvers[oBase + o]);
            }
        }

        wgpuBufferUnmap(readRay);
        wgpuBufferUnmap(readSub);
        wgpuBufferUnmap(readOver);
        wgpuBufferRelease(readRay);
        wgpuBufferRelease(readSub);
        wgpuBufferRelease(readOver);

        std::cout << "Read back GPU Producer schedule to CPU:\n"
                  << "  Total Subpanels: " << gpuSubpanels.size() << " (max " << maxSubpanelsPerRay << "/ray)\n"
                  << "  Total Overlaps:  " << gpuOverlaps.size() << "\n";
    }


    uint32_t workgroups = (uint32_t(executionRays) + 63u) / 64u;



    if(!geometryCase.empty()){
        unsigned positiveChecks=0,fallbacks=0;
        const auto& spec=curtainSpecs[0];
        for(size_t i=0;i<count;++i){
            const auto& ray=gpuRays[i];bool refused=(producerFlags[i]&0x80000000u)!=0;fallbacks+=refused;
            auto check=[&](double t){
                const glm::dvec3 p=glm::dvec3(ray.ro[0],ray.ro[1],ray.ro[2])+t*glm::dvec3(ray.rd[0],ray.rd[1],ray.rd[2]);
                const double phi=p.z+double(spec.amps.x)*std::sin(double(spec.freqs.x)*p.x+spec.phases.x)+
                    double(spec.amps.y)*std::cos(double(spec.freqs.y)*p.x+spec.phases.y);
                if(std::abs(p.x)>=spec.limits.x||std::abs(p.y)>=spec.limits.y||std::abs(phi)>=spec.limits.w)return;
                ++positiveChecks;bool kept=refused;
                for(unsigned k=0;k<ray.subpanelCount;++k){const auto& q=gpuSubpanels[ray.subpanelOffset+k];kept=kept||(q.mediumIndex==0&&q.s0<=t&&q.s1>=t);}
                for(unsigned k=0;k<ray.overlapCount;++k){const auto& q=gpuOverlaps[ray.overlapOffset+k];kept=kept||((q.activeMask&1u)&&q.s0<=t&&q.s1>=t);}
                if(!kept)throw std::runtime_error("native geometry witness dropped positive support");
            };
            for(unsigned k=0;k<4096;++k)check(ray.clipA+(ray.clipB-ray.clipA)*(k+.5)/4096);
            if(geometryCase=="narrow-lobe"){check(.007-.00004);check(.007+.00004);}
        }
        if(!positiveChecks)throw std::runtime_error("geometry control never exercised positive support");
        if(geometryCase=="near-parallel"&&fallbacks==count)throw std::runtime_error("near-parallel unexpectedly all refused");
        J q={{"scope","Native producer geometry control only; no transport/accuracy/speed qualification"},
            {"case",geometryCase},{"rays",count},{"positive_support_checks",positiveChecks},{"fallback_rays",fallbacks},{"pass",true}};
        std::ofstream f(outputPath);f<<q.dump(2)<<"\n";std::cout<<q.dump(2)<<std::endl;return 0;
    }

    WGPUComputePipeline fallbackCP=nullptr;WGPUBindGroup fallbackBG=nullptr;
    auto runBatch=[&](WGPUComputePipeline cp,WGPUBindGroup bg,int n)->double {
        auto enc=wgpuDeviceCreateCommandEncoder(gpu.device,nullptr);
        auto pass=wgpuCommandEncoderBeginComputePass(enc,nullptr);
        wgpuComputePassEncoderSetPipeline(pass,cp);
        if(bg)wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);
        for(int k=0;k<n;++k){
            wgpuComputePassEncoderSetPipeline(pass,cp);
            if(bg)wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass,workgroups,1,1);
            if(fallbackCP&&(cp==cpUnfused||cp==cpFused)){
                wgpuComputePassEncoderSetPipeline(pass,fallbackCP);
                wgpuComputePassEncoderSetBindGroup(pass,0,fallbackBG,0,nullptr);
                wgpuComputePassEncoderDispatchWorkgroups(pass,workgroups,1,1);
            }
        }
        wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);
        auto cmd=wgpuCommandEncoderFinish(enc,nullptr);wgpuCommandEncoderRelease(enc);
        auto t0=std::chrono::steady_clock::now();wgpuQueueSubmit(gpu.queue,1,&cmd);wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device,true,nullptr);
        return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();
    };
    auto runPass=[&](WGPUComputePipeline cp,WGPUBindGroup bg){return runBatch(cp,bg,1);};

    auto runBatchConnected = [&](int n) -> double {
        auto enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        for (int k = 0; k < n; ++k) {
            auto pass1 = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(pass1, cpProducer);
            wgpuComputePassEncoderSetBindGroup(pass1, 0, bgProducer, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass1, (count + 63) / 64, 1, 1);
            wgpuComputePassEncoderEnd(pass1);
            wgpuComputePassEncoderRelease(pass1);

            auto pass2 = wgpuCommandEncoderBeginComputePass(enc, nullptr);
            wgpuComputePassEncoderSetPipeline(pass2, cpUnfused);
            wgpuComputePassEncoderSetBindGroup(pass2, 0, bgUnfused, 0, nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass2, (count + 63) / 64, 1, 1);
            wgpuComputePassEncoderEnd(pass2);
            wgpuComputePassEncoderRelease(pass2);
            auto pass3=wgpuCommandEncoderBeginComputePass(enc,nullptr);
            wgpuComputePassEncoderSetPipeline(pass3,fallbackCP);
            wgpuComputePassEncoderSetBindGroup(pass3,0,fallbackBG,0,nullptr);
            wgpuComputePassEncoderDispatchWorkgroups(pass3,(count+63)/64,1,1);
            wgpuComputePassEncoderEnd(pass3);wgpuComputePassEncoderRelease(pass3);

        }
        auto cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuCommandEncoderRelease(enc);
        auto t0 = std::chrono::steady_clock::now();
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device, true, nullptr);
        return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    };

    // Helper for readback

    auto readBackBuffer = [&](WGPUBuffer src, uint64_t size) -> std::vector<uint8_t> {
        auto rb = makeBuffer(WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead, size, nullptr);
        WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        wgpuCommandEncoderCopyBufferToBuffer(enc, src, 0, rb, 0, size);
        WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuCommandEncoderRelease(enc);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);

        MapContext mc;
        WGPUBufferMapCallbackInfo cbInfo = {};
        cbInfo.mode = WGPUCallbackMode_AllowProcessEvents;
        cbInfo.callback = onMapped;
        cbInfo.userdata1 = &mc;
        wgpuBufferMapAsync(rb, WGPUMapMode_Read, 0, size, cbInfo);
        while (!mc.done) wgpuDevicePoll(gpu.device, true, nullptr);
        if (!mc.ok) throw std::runtime_error("buffer mapping failed");

        const uint8_t* ptr = static_cast<const uint8_t*>(wgpuBufferGetConstMappedRange(rb, 0, size));
        std::vector<uint8_t> data(ptr, ptr + size);
        wgpuBufferUnmap(rb);
        wgpuBufferRelease(rb);
        return data;
    };

    auto readResults = [&]() -> std::vector<GpuResult> {
        WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        wgpuCommandEncoderCopyBufferToBuffer(enc, outBuf, 0, readBuf, 0, outBytes);
        WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuCommandEncoderRelease(enc);

        MapContext mc;
        WGPUBufferMapCallbackInfo mci = {};
        mci.mode = WGPUCallbackMode_AllowProcessEvents;
        mci.callback = onMapped;
        mci.userdata1 = &mc;
        wgpuBufferMapAsync(readBuf, WGPUMapMode_Read, 0, outBytes, mci);
        while (!mc.done) wgpuDevicePoll(gpu.device, true, nullptr);
        if(!mc.ok)throw std::runtime_error("result mapping failed");

        const auto* ptr = static_cast<const GpuResult*>(wgpuBufferGetConstMappedRange(readBuf, 0, outBytes));
        std::vector<GpuResult> res(ptr, ptr + executionRays);
        wgpuBufferUnmap(readBuf);
        return res;
    };

    auto cuBuf=makeBuffer(WGPUBufferUsage_Uniform|WGPUBufferUsage_CopyDst,sizeof(currentU),&currentU);
    auto cparamsBuf=makeBuffer(WGPUBufferUsage_Storage|WGPUBufferUsage_CopyDst,currentParams.size()*4,currentParams.data());
    auto ciBuf=makeBuffer(WGPUBufferUsage_Storage|WGPUBufferUsage_CopyDst,currentInstances.size()*sizeof(CurrentInstance),currentInstances.data());
    auto buildRaw=[&](const std::string& text,const char* entry) {
        wgpuDevicePushErrorScope(gpu.device,WGPUErrorFilter_Validation);
        WGPUShaderSourceWGSL code={};code.chain.sType=WGPUSType_ShaderSourceWGSL;code.code=wgpu::Device::str(text.c_str());
        WGPUShaderModuleDescriptor md={};md.nextInChain=&code.chain;auto module=wgpuDeviceCreateShaderModule(gpu.device,&md);
        WGPUComputePipelineDescriptor pd={};pd.compute.module=module;pd.compute.entryPoint=wgpu::Device::str(entry);
        auto pipeline=wgpuDeviceCreateComputePipeline(gpu.device,&pd);wgpuShaderModuleRelease(module);
        PopContext error;WGPUPopErrorScopeCallbackInfo cb={};cb.mode=WGPUCallbackMode_AllowProcessEvents;cb.callback=onPopError;cb.userdata1=&error;
        wgpuDevicePopErrorScope(gpu.device,cb);while(!error.done)wgpuDevicePoll(gpu.device,true,nullptr);
        if(error.type!=WGPUErrorType_NoError||!pipeline)throw std::runtime_error("production compute pipeline validation failed");
        return pipeline;
    };
    auto currentCP=buildRaw(currentShader,"rayMain"),prepCP=buildRaw(prepShader,"volumeTimePrepare");
    auto bindCurrent=[&](WGPUComputePipeline cp) {
        WGPUBindGroupEntry entries[5]={};
        WGPUBuffer buffers[5]={cuBuf,cparamsBuf,ciBuf,rBuf,outBuf};
        uint64_t sizes[5]={sizeof(currentU),currentParams.size()*4,currentInstances.size()*sizeof(CurrentInstance),rayBytes,outBytes};
        for(uint32_t k=0;k<5;++k){entries[k].binding=k;entries[k].buffer=buffers[k];entries[k].size=sizes[k];}
        auto layout=wgpuComputePipelineGetBindGroupLayout(cp,0);WGPUBindGroupDescriptor d={};d.layout=layout;d.entryCount=5;d.entries=entries;
        auto bg=wgpuDeviceCreateBindGroup(gpu.device,&d);wgpuBindGroupLayoutRelease(layout);return bg;
    };
    auto currentBG=bindCurrent(currentCP),prepBG=bindCurrent(prepCP);
    std::string fallbackShader=currentShader;
    const std::string rayHook=" let ray=capturedRays[idx%arrayLength(&capturedRays)];";
    auto where=fallbackShader.find(rayHook);if(where==std::string::npos)throw std::runtime_error("fallback ray hook");
    fallbackShader.insert(where+rayHook.size(),"\n if((ray.counts.w & 0x80000000u)==0u){return;}\n");
    fallbackCP=buildRaw(fallbackShader,"rayMain");fallbackBG=bindCurrent(fallbackCP);

    {
        auto enc=wgpuDeviceCreateCommandEncoder(gpu.device,nullptr);auto pass=wgpuCommandEncoderBeginComputePass(enc,nullptr);
        wgpuComputePassEncoderSetPipeline(pass,prepCP);wgpuComputePassEncoderSetBindGroup(pass,0,prepBG,0,nullptr);
        wgpuComputePassEncoderDispatchWorkgroups(pass,media.size(),1,1);wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);
        auto cmd=wgpuCommandEncoderFinish(enc,nullptr);wgpuCommandEncoderRelease(enc);wgpuQueueSubmit(gpu.queue,1,&cmd);wgpuCommandBufferRelease(cmd);
        wgpuDevicePoll(gpu.device,true,nullptr);
    }
    J report;
    J streamingCases=J::array();

    { // No obsolete tile allocations/bind groups. Actual modes0/1/2 use whole buffers.
        // mode 0 current marcher, 1 retained bulk connected, 2 streamed connected.
        // Both command encoding and submit-to-completion are separately observed.
        int waitStyle = std::getenv("EC_GPU_WAIT_STYLE") ? std::atoi(std::getenv("EC_GPU_WAIT_STYLE")) : 1;
        uint64_t lastPolls = 0;
        auto execute=[&](int mode,int repeats,bool forced){
            auto begin=std::chrono::steady_clock::now();auto enc=wgpuDeviceCreateCommandEncoder(gpu.device,nullptr);
            auto dispatch=[&](WGPUComputePipeline cp,WGPUBindGroup bg,uint32_t n){
                auto pass=wgpuCommandEncoderBeginComputePass(enc,nullptr);
                wgpuComputePassEncoderSetPipeline(pass,cp);wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);
                wgpuComputePassEncoderDispatchWorkgroups(pass,(n+63u)/64u,1,1);
                wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);
            };
            for(int k=0;k<repeats;++k){
                if(mode==0)dispatch(currentCP,currentBG,count);
                else if(mode==1){dispatch(cpProducer,bgProducer,count);dispatch(cpUnfused,bgUnfused,count);dispatch(fallbackCP,fallbackBG,count);}
                else if(mode==2){
                    // Mode 2: Frozen §6dr Canonical Routed Unfused Control
                    // Pass 0: Reset Counters
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpReset);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgReset, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 1, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 1: Classify Tiles
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpClassify);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgClassify, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, (numTiles + 63u) / 64u, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 2: Route Args
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpArgs);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgArgs, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 3, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 3: S1 Producer Unfused (writes subpanels to sBuf)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS1Unfused);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS1UnfusedForced : bgS1Unfused, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 4: S2 Producer (Indirect)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS2);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS2Forced : bgS2, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 5: Fallback Producer (Indirect)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpFallback);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgFallbackForced : bgFallback, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 6: Canonical Unfused A* Consumer (processes S1 subpanels from sBuf)
                    if(!std::getenv("EC_ET_OMIT_CONSUMER"))dispatch(cpUnfused, bgUnfused, count);
                    // Pass 7: Production-Generated Current Marcher Fallback (only for refused rays)
                    dispatch(fallbackCP, fallbackBG, count);
                }
                else if(mode==3){
                    // Mode 3: §6dt/§6du True Terminal S1
                    // Pass 0: Reset Counters
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpReset);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgReset, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 1, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 1: Classify Tiles
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpClassify);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgClassify, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, (numTiles + 63u) / 64u, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 2: Route Args
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpArgs);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgArgs, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 3, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 3: S1 Producer Terminal (evaluates quadrature in-producer, writes results[id], marks counts.w |= 0x40000000u)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS1Terminal);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS1TerminalForced : bgS1Terminal, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 4: S2 Producer (Indirect)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS2);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS2Forced : bgS2, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 5: Fallback Producer (Indirect)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpFallback);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgFallbackForced : bgFallback, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 6: Canonical Unfused A* Consumer (skips completed S1 rays and refused rays)
                    dispatch(cpUnfused, bgUnfused, count);
                    // Pass 7: Production-Generated Current Marcher Fallback (only for refused rays)
                    dispatch(fallbackCP, fallbackBG, count);
                }
                else if(mode==4){
                    // Mode 4: §6ej Candidate Terminal S1 + Terminal S2 (Unchanged Bisection Only)
                    // Pass 0: Reset Counters
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpReset);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgReset, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 1, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 1: Classify Tiles
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpClassify);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgClassify, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, (numTiles + 63u) / 64u, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 2: Route Args
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpArgs);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgArgs, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 3, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 3: S1 Terminal Producer
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS1Terminal);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS1TerminalForced : bgS1Terminal, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 4: S2 Terminal Producer (Candidate!)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS2Terminal);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS2TerminalForced : bgS2Terminal, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 5: Fallback Producer
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpFallback);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgFallbackForced : bgFallback, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 6: Canonical Unfused Consumer (skips completed S1 & S2 rays)
                    dispatch(cpUnfused, bgUnfused, count);
                    // Pass 7: Current Marcher Fallback (runs only on refused rays)
                    dispatch(fallbackCP, fallbackBG, count);
                }
                else if(mode==5){
                    // Mode 5: Terminal S1 + Terminal S2 + Indirect Fallback Consumer (§6el Clean Candidate)
                    // Pass 0: Reset Counters
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpReset);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgReset, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 1, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 1: Classify Tiles
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpClassify);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgClassify, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, (numTiles + 63u) / 64u, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 2: Route Args
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpArgs);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgArgs, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroups(p, 3, 1, 1);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 3: S1 Terminal Producer
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS1Terminal);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS1TerminalForced : bgS1Terminal, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 0);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 4: S2 Terminal Producer
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpS2Terminal);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgS2TerminalForced : bgS2Terminal, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 12);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 5: Fallback Producer
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpFallback);
                        wgpuComputePassEncoderSetBindGroup(p, 0, forced ? bgFallbackForced : bgFallback, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 6: Indirect Fallback Consumer (dispatches over fallbackTileList only!)
                    {
                        auto p = wgpuCommandEncoderBeginComputePass(enc, nullptr);
                        wgpuComputePassEncoderSetPipeline(p, cpFallbackConsumer);
                        wgpuComputePassEncoderSetBindGroup(p, 0, bgFallbackConsumer, 0, nullptr);
                        wgpuComputePassEncoderDispatchWorkgroupsIndirect(p, argsBuf, 24);
                        wgpuComputePassEncoderEnd(p);
                        wgpuComputePassEncoderRelease(p);
                    }
                    // Pass 7: Current Marcher Fallback (runs only on refused rays)
                    dispatch(fallbackCP, fallbackBG, count);
                }
            }
            auto cmd=wgpuCommandEncoderFinish(enc,nullptr);wgpuCommandEncoderRelease(enc);
            auto submitted=std::chrono::steady_clock::now();wgpuQueueSubmit(gpu.queue,1,&cmd);wgpuCommandBufferRelease(cmd);
            lastPolls = 0;
            if (waitStyle == 0) {
                wgpuDevicePoll(gpu.device, true, nullptr);
                lastPolls = 1;
            } else {
                while (!wgpuDevicePoll(gpu.device, false, nullptr)) {
                    ++lastPolls;
                    if (std::chrono::steady_clock::now() - submitted > std::chrono::seconds(30)) {
                        throw std::runtime_error("active completion timeout");
                    }
                }
                ++lastPolls;
            }
            auto end = std::chrono::steady_clock::now();
            return std::array<double,3>{std::chrono::duration<double,std::milli>(submitted-begin).count(),
                std::chrono::duration<double,std::milli>(end-submitted).count(),std::chrono::duration<double,std::milli>(end-begin).count()};
        };
        if(count!=230400u||numTiles!=14400u||scaleK!=1u)throw std::runtime_error("6et distinct capture extent");
        auto poisonAll=[&](){
            auto headers=gpuRays;
            for(auto& r:headers){r.subpanelOffset=r.subpanelCount=r.overlapOffset=r.overlapCount=0xcdcdcdcdu;}
            std::vector<uint32_t> scratch(subpanelBytes/4,0xcdcdcdcdu);
            wgpuQueueWriteBuffer(gpu.queue,rBuf,0,headers.data(),rayBytes);
            wgpuQueueWriteBuffer(gpu.queue,sBuf,0,scratch.data(),subpanelBytes);
            scratch.assign(overlapBytes/4,0xcdcdcdcdu);
            wgpuQueueWriteBuffer(gpu.queue,oBuf,0,scratch.data(),overlapBytes);
            std::vector<GpuResult> output(executionRays);
            for(auto& row:output)for(float& f:row.rgb_T)f=NAN;
            wgpuQueueWriteBuffer(gpu.queue,outBuf,0,output.data(),outBytes);
        };
        std::vector<GpuResult> baseline;J preflight=J::array();
        for(int mode:{0,1,2}){
            poisonAll();execute(mode,1,false);auto rows=readResults();
            for(size_t i=0;i<count;++i)for(float f:rows[i].rgb_T)
                if(!std::isfinite(f))throw std::runtime_error("6et nonfinite/unpublished mode="+std::to_string(mode)+" ray="+std::to_string(i));
            uint64_t different=0;
            if(mode==1)baseline=rows;
            if(mode==2)for(size_t i=0;i<count;++i)different+=std::memcmp(&rows[i],&baseline[i],sizeof(GpuResult))!=0;
            if(different)throw std::runtime_error("6et full distinct parity failure: "+std::to_string(different));
            const auto path=outputPath+".mode"+std::to_string(mode)+".bin";
            std::ofstream(path,std::ios::binary).write(reinterpret_cast<const char*>(rows.data()),outBytes);
            uint32_t refused=0;
            if(mode!=0){
                auto hb=readBackBuffer(rBuf,rayBytes);auto headers=reinterpret_cast<const GpuRayHeader*>(hb.data());
                for(size_t i=0;i<count;++i)refused+=bool(headers[i].overlapCount&0x80000000u);
                std::ofstream(outputPath+".headers"+std::to_string(mode)+".bin",std::ios::binary).write(reinterpret_cast<const char*>(hb.data()),hb.size());
            }
            preflight.push_back({{"mode",mode},{"rays",count},{"finite",true},{"different_from_bulk",different},{"refused",refused}});
            std::cerr<<"6ET PREFLIGHT mode="<<mode<<" rays="<<count<<" different="<<different<<" refused="<<refused<<std::endl;
        }
        J result={{"rays",count},{"tiles",numTiles},{"scale",scaleK},{"preflight",preflight},{"wait_style",waitStyle},
            {"scope","complete resident captured-ray chain; setup/uploads/time preparation/Screen/reference outside timing"},
            {"preflight_full_schedule_poison",true},{"obsolete_stream_allocations",false},
            {"bytes",{{"rays",rayBytes},{"subpanels",subpanelBytes},{"overlaps",overlapBytes},{"outputs",outBytes}}}};
        if(std::string(std::getenv("EC_ET_PHASE")?std::getenv("EC_ET_PHASE"):"preflight")=="timing"){
            for(int k=0;k<4;++k)for(int mode:{0,1,2})execute(mode,1,false);
            J observations=J::array();
            for(int block=0;block<8;++block){
                const std::vector<int> order=(block%4==1||block%4==2)?std::vector<int>{2,1,0,0,1,2}:std::vector<int>{0,1,2,2,1,0};
                for(int position=0;position<int(order.size());++position){
                    const int mode=order[position];const auto t=execute(mode,1,false);
                    observations.push_back({{"block",block},{"position",position},{"mode",mode},{"encode_ms",t[0]},{"completion_ms",t[1]},{"total_ms",t[2]},{"polls",lastPolls}});
                }
            }
            result["observations"]=observations;
        }
        std::ofstream(outputPath)<<result.dump(2)<<std::endl;return 0;
    }
}
