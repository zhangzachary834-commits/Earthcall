
#include "Singularity/Screen/WebGPU/VolumeRoutedTransport.hpp"
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <json.hpp>
using J=nlohmann::json;
static uint64_t nextId=100, bindingLimit=128ull*1024*1024;
static J groups=J::array(), passes=J::array(), allocations=J::array();
static uint64_t bytesAllocated=0;
template<class T> T handle(){return reinterpret_cast<T>(++nextId);}
template<class T> uint64_t id(T p){return reinterpret_cast<uintptr_t>(p);}
extern "C" {
WGPUStatus wgpuDeviceGetLimits(WGPUDevice,WGPULimits* out){*out={};out->maxStorageBufferBindingSize=bindingLimit;return WGPUStatus_Success;}
void wgpuBufferRelease(WGPUBuffer){}
WGPUBindGroup wgpuDeviceCreateBindGroup(WGPUDevice,const WGPUBindGroupDescriptor* d){
 auto g=handle<WGPUBindGroup>();J entries=J::array();
 for(size_t i=0;i<d->entryCount;++i){auto& e=d->entries[i];entries.push_back({{"binding",e.binding},{"buffer",id(e.buffer)},{"offset",e.offset},{"size",e.size}});}
 groups.push_back({{"id",id(g)},{"layout",id(d->layout)},{"entries",entries}});return g;
}
WGPUBindGroupLayout wgpuComputePipelineGetBindGroupLayout(WGPUComputePipeline p,uint32_t){return reinterpret_cast<WGPUBindGroupLayout>(p);}
void wgpuBindGroupLayoutRelease(WGPUBindGroupLayout){}
void wgpuBindGroupRelease(WGPUBindGroup){}
WGPUComputePassEncoder wgpuCommandEncoderBeginComputePass(WGPUCommandEncoder,const WGPUComputePassDescriptor*){passes.push_back({{"groups",J::array()}});return handle<WGPUComputePassEncoder>();}
void wgpuComputePassEncoderSetPipeline(WGPUComputePassEncoder,WGPUComputePipeline p){passes.back()["pipeline"]=id(p);}
void wgpuComputePassEncoderSetBindGroup(WGPUComputePassEncoder,uint32_t index,WGPUBindGroup g,size_t,const uint32_t*){passes.back()["groups"].push_back({{"index",index},{"id",id(g)}});}
void wgpuComputePassEncoderDispatchWorkgroups(WGPUComputePassEncoder,uint32_t x,uint32_t y,uint32_t z){passes.back()["direct"]={x,y,z};}
void wgpuComputePassEncoderDispatchWorkgroupsIndirect(WGPUComputePassEncoder,WGPUBuffer b,uint64_t offset){passes.back()["indirect"]={{"buffer",id(b)},{"offset",offset}};}
void wgpuComputePassEncoderEnd(WGPUComputePassEncoder){}
void wgpuComputePassEncoderRelease(WGPUComputePassEncoder){}
}
namespace kernel_routed_detail {
inline WGPUBuffer buffer(WGPUDevice,WGPUQueue,uint64_t size,WGPUBufferUsage=0,const void* =nullptr){auto b=handle<WGPUBuffer>();bytesAllocated+=size;allocations.push_back({{"buffer",id(b)},{"bytes",size}});return b;}
inline WGPUComputePipeline pipeline(WGPUDevice,const std::string&,const char*,WGPUPipelineLayout=nullptr){throw std::runtime_error("mock must not compile a shader");}
}
namespace routed_wgsl {
const char* kResetCountersWgsl="";const char* kClassifyWgsl="";const char* kRouteArgsWgsl="";
const char* kS1UnfusedProducerWgsl="";const char* kS2ProducerWgsl="";const char* kFallbackProducerWgsl="";
}
KernelRoutedTransport::~KernelRoutedTransport(){}

namespace kernel_routed_detail {
inline WGPUBindGroupEntry entry(uint32_t i,WGPUBuffer b,uint64_t size,uint64_t offset=0){WGPUBindGroupEntry e={};e.binding=i;e.buffer=b;e.offset=offset;e.size=size;return e;}
inline WGPUBindGroup group(WGPUDevice d,WGPUBindGroupLayout layout,std::vector<WGPUBindGroupEntry> entries){WGPUBindGroupDescriptor x={};x.layout=layout;x.entryCount=entries.size();x.entries=entries.data();return wgpuDeviceCreateBindGroup(d,&x);}
inline WGPUBindGroup group(WGPUDevice d,WGPUComputePipeline p,std::vector<WGPUBindGroupEntry> entries){auto l=wgpuComputePipelineGetBindGroupLayout(p,0);auto out=group(d,l,std::move(entries));wgpuBindGroupLayoutRelease(l);return out;}

}
void KernelRoutedTransport::releaseBuffers(){
 for(auto* p:{&publication,&rays,&singles,&overlaps,&offsets,&indices,&counts,&args})if(*p){wgpuBufferRelease(*p);*p=nullptr;}
 for(auto& p:lists)if(p){wgpuBufferRelease(p);p=nullptr;}width=height=capacity=tiles=stripRows=0;
}
bool KernelRoutedTransport::ensure(WGPUDevice d,WGPUQueue q,uint32_t w,uint32_t h){
 using namespace kernel_routed_detail;device=d;queue=q;WGPULimits limits={};
 if(wgpuDeviceGetLimits(d,&limits)!=WGPUStatus_Success||!w||!h||uint64_t(w)*h*16>std::min<uint64_t>(64ull*1024*1024,limits.maxStorageBufferBindingSize))return false;
 if(width==w&&height==h&&publication)return std::all_of(common.begin(),common.end(),[](auto p){return p!=nullptr;});releaseBuffers();
 // 64 intervals/ray retained; partition work, never lower accuracy to fit.
 const auto maxRows=std::min<uint64_t>(48,limits.maxStorageBufferBindingSize/(uint64_t(w)*64*16));
 const uint32_t rows=static_cast<uint32_t>(maxRows/4*4);if(rows<4)return false;
 width=w;height=h;stripRows=rows;capacity=w*rows;tiles=((w+3)/4)*(rows/4);
 std::vector<uint32_t> off,idx;off.reserve(tiles+1);idx.reserve(capacity);
 for(uint32_t y=0;y<rows;y+=4)for(uint32_t x=0;x<w;x+=4){off.push_back(idx.size());for(uint32_t dy=0;dy<4;++dy)for(uint32_t dx=0;dx<4&&x+dx<w;++dx)idx.push_back((y+dy)*w+x+dx);}
 off.push_back(idx.size());publication=buffer(d,q,uint64_t(w)*h*16);rays=buffer(d,q,uint64_t(capacity)*48);singles=buffer(d,q,uint64_t(capacity)*64*16);overlaps=buffer(d,q,uint64_t(capacity)*16*16);
 offsets=buffer(d,q,off.size()*4,0,off.data());indices=buffer(d,q,idx.size()*4,0,idx.data());counts=buffer(d,q,16);args=buffer(d,q,36,WGPUBufferUsage_Indirect);
 for(auto& b:lists)b=buffer(d,q,uint64_t(tiles)*4);
 if(!publication||!rays||!singles||!overlaps||!offsets||!indices||!counts||!args||!lists[0]||!lists[1]||!lists[2]){releaseBuffers();return false;}
 if(!common[0]){
  const char* codes[]={routed_wgsl::kResetCountersWgsl,routed_wgsl::kClassifyWgsl,routed_wgsl::kRouteArgsWgsl,routed_wgsl::kS1UnfusedProducerWgsl,routed_wgsl::kS2ProducerWgsl,routed_wgsl::kFallbackProducerWgsl};
  const char* entries[]={"resetCountersMain","classifyTilesMain","routeArgs","s1ProducerMain","s2ProducerMain","fallbackProducerMain"};
  for(int i=0;i<6;++i){common[i]=pipeline(d,codes[i],entries[i]);if(!common[i])return false;}
 }
 return true;
}
bool KernelRoutedTransport::encode(Program& p,WGPUCommandEncoder encoder,const KernelRoutedRange& globals,const KernelRoutedRange& params,const KernelRoutedRange& instances,WGPUTextureView depth,const KernelRoutedRange& specs,const KernelRoutedRange& uniformSpecs,const std::function<KernelRoutedRange(const void*,size_t)>& uniform){
 using namespace kernel_routed_detail;
 auto g=std::vector<WGPUBindGroupEntry>{entry(0,globals.buffer,globals.size,globals.offset),entry(1,params.buffer,params.size,params.offset),{},entry(3,publication,uint64_t(width)*height*16)};g[2].binding=2;g[2].textureView=depth;
 auto globalGroup=group(device,p.globals,g),instanceGroup=group(device,p.instances,{entry(0,instances.buffer,instances.size,instances.offset)});
 auto resetGroup=group(device,common[0],{entry(0,counts,16)});
 auto classifyGroup=group(device,common[1],{entry(0,specs.buffer,specs.size,specs.offset),entry(1,rays,uint64_t(capacity)*48),entry(2,offsets,uint64_t(tiles+1)*4),entry(3,indices,uint64_t(capacity)*4),entry(4,lists[0],uint64_t(tiles)*4),entry(5,lists[1],uint64_t(tiles)*4),entry(6,lists[2],uint64_t(tiles)*4),entry(7,counts,16)});
 auto argsGroup=group(device,common[2],{entry(0,counts,16),entry(1,args,36)});
 for(uint32_t start=0;start<height;start+=stripRows){
  std::array<uint32_t,8> config{capacity,64,16,workLimit,width,height,start,stripRows};const auto u=uniform(config.data(),sizeof(config));
  auto localGroup=group(device,p.local,{entry(0,u.buffer,u.size,u.offset),entry(1,rays,uint64_t(capacity)*48),entry(2,singles,uint64_t(capacity)*64*16),entry(3,overlaps,uint64_t(capacity)*16*16)});
  auto dispatch=[&](WGPUComputePipeline cp,WGPUBindGroup bg,uint32_t n){auto pass=wgpuCommandEncoderBeginComputePass(encoder,nullptr);wgpuComputePassEncoderSetPipeline(pass,cp);wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);wgpuComputePassEncoderDispatchWorkgroups(pass,n,1,1);wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);};
  auto withContext=[&](WGPUComputePipeline cp){auto pass=wgpuCommandEncoderBeginComputePass(encoder,nullptr);wgpuComputePassEncoderSetPipeline(pass,cp);wgpuComputePassEncoderSetBindGroup(pass,0,globalGroup,0,nullptr);wgpuComputePassEncoderSetBindGroup(pass,1,instanceGroup,0,nullptr);wgpuComputePassEncoderSetBindGroup(pass,2,localGroup,0,nullptr);wgpuComputePassEncoderDispatchWorkgroups(pass,(capacity+63)/64,1,1);wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);};
  withContext(p.setup);dispatch(common[0],resetGroup,1);dispatch(common[1],classifyGroup,(tiles+63)/64);dispatch(common[2],argsGroup,3);
  for(unsigned i=0;i<3;++i){auto entries=std::vector<WGPUBindGroupEntry>{entry(0,u.buffer,u.size,u.offset),entry(1,uniformSpecs.buffer,uniformSpecs.size,uniformSpecs.offset),entry(2,rays,uint64_t(capacity)*48),entry(3,singles,uint64_t(capacity)*64*16)};if(i==2)entries.push_back(entry(4,overlaps,uint64_t(capacity)*16*16));entries.push_back(entry(5,offsets,uint64_t(tiles+1)*4));entries.push_back(entry(6,indices,uint64_t(capacity)*4));entries.push_back(entry(7,lists[i],uint64_t(tiles)*4));entries.push_back(entry(8,counts,16));
   auto bg=group(device,common[i+3],entries);auto pass=wgpuCommandEncoderBeginComputePass(encoder,nullptr);wgpuComputePassEncoderSetPipeline(pass,common[i+3]);wgpuComputePassEncoderSetBindGroup(pass,0,bg,0,nullptr);wgpuComputePassEncoderDispatchWorkgroupsIndirect(pass,args,i*12);wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);wgpuBindGroupRelease(bg);
  }
  withContext(p.consumer);wgpuBindGroupRelease(localGroup);
 }
 for(auto g:{globalGroup,instanceGroup,resetGroup,classifyGroup,argsGroup})wgpuBindGroupRelease(g);return true;
}

int main(int argc,char** argv){
 try{
  if(argc!=4)throw std::runtime_error("width height binding-limit");
  uint32_t w=std::stoul(argv[1]),h=std::stoul(argv[2]);bindingLimit=std::stoull(argv[3]);
  KernelRoutedTransport k;for(auto& p:k.common)p=handle<WGPUComputePipeline>();
  bool ok=k.ensure(handle<WGPUDevice>(),handle<WGPUQueue>(),w,h);
  J output={{"eligible",ok},{"width",w},{"height",h},{"binding_limit",bindingLimit},{"rows",k.stripRows},{"allocations",allocations},{"bytes",bytesAllocated}};
  if(ok){
   KernelRoutedTransport::Program p;p.setup=handle<WGPUComputePipeline>();p.consumer=handle<WGPUComputePipeline>();p.globals=handle<WGPUBindGroupLayout>();p.instances=handle<WGPUBindGroupLayout>();p.local=handle<WGPUBindGroupLayout>();
   auto range=[](){return KernelRoutedRange{handle<WGPUBuffer>(),0,112*4};};
   auto globals=range(),params=range(),instances=range(),specs=range(),uniformSpecs=range();J windows=J::array();uint64_t offset=0;auto ubo=handle<WGPUBuffer>();
   bool encoded=k.encode(p,handle<WGPUCommandEncoder>(),globals,params,instances,handle<WGPUTextureView>(),specs,uniformSpecs,[&](const void* raw,size_t size){
    if(size!=32)throw std::runtime_error("window size");auto* v=static_cast<const uint32_t*>(raw);windows.push_back(J::array({v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7]}));auto out=KernelRoutedRange{ubo,offset,size};offset+=256;return out;
   });
   output["encoded"]=encoded;output["windows"]=windows;output["groups"]=groups;output["passes"]=passes;
   output["pipelines"]={{"setup",id(p.setup)},{"consumer",id(p.consumer)}};
   output["common"]=J::array();for(auto c:k.common)output["common"].push_back(id(c));
   output["shared"]={{"rays",id(k.rays)},{"singles",id(k.singles)},{"overlaps",id(k.overlaps)},{"counts",id(k.counts)},{"args",id(k.args)}};
  }
  std::cout<<output.dump(2)<<'\n';return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
