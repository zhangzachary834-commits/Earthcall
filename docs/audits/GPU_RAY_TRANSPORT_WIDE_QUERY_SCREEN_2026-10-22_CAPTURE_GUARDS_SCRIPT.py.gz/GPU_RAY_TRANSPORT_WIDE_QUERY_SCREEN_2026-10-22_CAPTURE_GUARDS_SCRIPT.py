import importlib.util,json,subprocess,tempfile,types
from pathlib import Path
from unittest.mock import patch
root=Path('/Users/zacharyzhang/.gemini/antigravity/worktrees/Earthcall/ourverse_navigator_prototype_loop');path=root/'scratch/probes/ray_transport_cf4_trial.py'
spec=importlib.util.spec_from_file_location('capture_current',path);current=importlib.util.module_from_spec(spec);spec.loader.exec_module(current)
parent=types.ModuleType('capture_parent');parent.__file__=str(path);exec(subprocess.check_output(['git','show','d9c9b3f3f:scratch/probes/ray_transport_cf4_trial.py'],cwd=root,text=True),parent.__dict__)
class StopCompile(Exception):pass
def stop(*args,**kwargs):raise StopCompile()
with tempfile.TemporaryDirectory(prefix='earthcall-wide-capture-guards-') as td:
 t=Path(td)
 for label,module,kwargs in [('old',parent,{}),('default',current,{}),('wide',current,{'capture_grid':(256,144)})]:
  try:
   with patch('subprocess.run',stop):module.build(root,t/label,capture=True,**kwargs)
  except StopCompile:pass
  else:raise AssertionError('compile boundary not reached')
 a=(t/'old/cf4-renderer.cpp').read_bytes();b=(t/'default/cf4-renderer.cpp').read_bytes();assert a==b
 s=(t/'wide/cf4-renderer.cpp').read_text();assert '256u * 144u * ' in s and 'dc.x+256u*dc.y' in s
 for kwargs in [{'capture_grid':(1024,1024)},{'capture_storage_multiplier':5}]:
  try:current.build(root,t/'invalid',capture=True,**kwargs)
  except AssertionError:pass
  else:raise AssertionError('unbounded capture accepted')
  assert not (t/'invalid').exists()
 result={'pass':True,'checks':['default generated renderer byte-identical to pre-pass HEAD','wide buffer/slot grid emitted','unbounded grid refused before output','unbounded storage refused before output'],'parent':'d9c9b3f3f','scope':'generated source/guards; no GPU execution or production change'}
 Path('/private/tmp/earthcall-wide-pass/capture-guards.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',len(result['checks']),'capture source/guard controls')
