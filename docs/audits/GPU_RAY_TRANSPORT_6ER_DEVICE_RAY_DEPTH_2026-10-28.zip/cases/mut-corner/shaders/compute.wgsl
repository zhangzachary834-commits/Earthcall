struct VolumeGlobals {
    viewProj: mat4x4<f32>,
    invViewProj: mat4x4<f32>,
    eyePos: vec4<f32>,
    viewport: vec4<f32>,
    // xyz = the one admitted direct source position; w=1 iff such a source exists.
    incidentSource: vec4<f32>,
    // xyz = source color / diffuse radiance; w = source intensity / multiplier.
    incidentColor: vec4<f32>,
    // xy = the admitted source's own relative Timeline coordinate/delta.
    // Source t must never borrow a participating medium's instance time.
    sourceTime: vec4<f32>,
    // x = max shadow steps, y = local volumetric visibility enabled,
    // z deliberately unused: it once carried a hardcoded HG phase g (removed in
    // b1d16c41; sdf_wgsl_parameter_refresh_test forbids reading it),
    // w = samples per medium chord (ScreenChannel volumeSamplesPerChord: the
    // quadrature resolution a medium gets along a ray; a runtime value, so
    // changing it never recompiles).
    volumeControl: vec4<f32>,
    // x = final-output budget, y = opt-in (also for subnormal budgets).
    // Positive mode uses the entire accepted lattice when no certified tail
    // bound exists. The opacity heuristic cannot certify late bright emission.
    volumeOutputError: vec4<f32>,
}
struct VolumeInstanceData {
    origin: vec4<f32>,
    halfExtent: vec4<f32>,
    time: vec4<f32>,
    paramOffset: u32,
    // Zero-density proof (Rendering::VolumeZeroProof): absolute offset of its
    // bit words in P (then six support bounds, then four bounds per column),
    // cell dims packed 10 bits per axis, and presence/column-axis bits.
    // All are Kernel-derived proof data, never authored parameter slots.
    zeroProofOffset: u32,
    zeroProofDims: u32,
    zeroProofPresent: u32,
    // Support certificates (Rung 2f-native, VolumeSupportKillerProgram):
    // absolute offset of the header block in P and the enabled candidate
    // count; 0 = none. Kernel-derived from authored density × box.
    supportCertOffset: u32,
    supportCertCount: u32,
    supportClosedOffset: u32,
    supportClosedCount: u32,
}
@group(0) @binding(0) var<uniform> u:VolumeGlobals;
@group(0) @binding(2) var sceneDepthTex:texture_depth_2d;
@group(1) @binding(0) var<storage,read> instances:array<VolumeInstanceData>;
@group(0) @binding(4) var<storage,read_write> computeFacts:array<vec4<u32>>;
var<private> g_instIdx:u32;
var<private> ecTraceValue:vec4<f32>;
const RAY_START:u32=0u;
const RAY_ROWS:u32=190u;
fn rayAabbWorld(ro: vec3<f32>, rd: vec3<f32>,
                bmin: vec3<f32>, bmax: vec3<f32>) -> vec2<f32> {
    let safeRd = select(rd, vec3<f32>(1e-8), abs(rd) < vec3<f32>(1e-8));
    let a = (bmin - ro) / safeRd;
    let b = (bmax - ro) / safeRd;
    let lo = min(a, b);
    let hi = max(a, b);
    return vec2<f32>(
        max(max(lo.x, lo.y), lo.z),
        min(min(hi.x, hi.y), hi.z));
}
fn worldAtDepth(pixel: vec2<f32>, depth: f32) -> vec3<f32> {
    let ndc = vec4<f32>(
        (pixel.x / u.viewport.x) * 2.0 - 1.0,
        (1.0 - pixel.y / u.viewport.y) * 2.0 - 1.0,
        depth,
        1.0);
    let h = u.invViewProj * ndc;
    return h.xyz / h.w;
}
fn ecComputeRecord(position: vec4<f32>, ro: vec3<f32>, rd: vec3<f32>, t0: f32, t1: f32,
        depth: f32, bounds: vec2<f32>, status: u32) {
    let x=u32(position.x);let y=u32(position.y);
    if(y<RAY_START || y>=RAY_START+RAY_ROWS){return;}
    let at=((y-RAY_START)*u32(u.viewport.x)+x)*4u;
computeFacts[at]=bitcast<vec4<u32>>(vec4<f32>(ro,t0));
computeFacts[at+1u]=bitcast<vec4<u32>>(vec4<f32>(rd,t1));
computeFacts[at+2u]=vec4<u32>(1u,status,bitcast<u32>(depth),0u);
computeFacts[at+3u]=bitcast<vec4<u32>>(vec4<f32>(bounds,position.xy));
}
fn deviceSetup(position:vec4<f32>){
    // V5: instance 0 is a union-bounds header used only by the proxy vertex/ray
    // interval. Projected media begin at instance 1 and keep their own
    // origin/halfExtent/time/paramOffset.
    g_instIdx = 0u;
    let setInst = instances[0];

    let ro = u.eyePos.xyz;
    let farNdc = vec4<f32>(
        (position.x / u.viewport.x) * 2.0 - 1.0,
        (1.0 - position.y / u.viewport.y) * 2.0 - 1.0,
        1.0,
        1.0);
    let farH = u.invViewProj * farNdc;
    let farWorld = farH.xyz / farH.w;
    let rd = normalize(farWorld - ro);

    let bounds = rayAabbWorld(
        ro, rd,
        setInst.origin.xyz - setInst.halfExtent.xyz,
        setInst.origin.xyz + setInst.halfExtent.xyz);

    var t0 = max(bounds.x, 0.0);
    var t1 = bounds.y;
    if(t1<=t0){ecComputeRecord(position,ro,rd,t0,t1,-1.0,bounds,1u); return; }

    let maxX = max(i32(u.viewport.x), 1) - 1;
    let maxY = max(i32(u.viewport.y), 1) - 1;
    let px = vec2<i32>(
        clamp(i32(floor(position.x)), 0, maxX),
        clamp(i32(floor(position.y)), 0, maxY));
    let sceneDepth = textureLoad(sceneDepthTex, px, 0);

    if (sceneDepth < 0.999999) {
        let opaqueWorld = worldAtDepth(position.xy, sceneDepth);
        let opaqueT = dot(opaqueWorld - ro, rd);
        t1 = min(t1, max(opaqueT, 0.0));
    }
    if(t1<=t0){ecComputeRecord(position,ro,rd,t0,t1,sceneDepth,bounds,2u); return; }

    ecComputeRecord(position,ro,rd,t0,t1,sceneDepth,bounds,3u);
}
@compute @workgroup_size(64) fn cs(@builtin(global_invocation_id) id:vec3<u32>){
let width=u32(u.viewport.x);if(id.x>=width*RAY_ROWS){return;}
let x=id.x%width;let y=id.x/width+RAY_START;deviceSetup(vec4<f32>(f32(x)+0.0,f32(y)+0.0,0.0,1.0));}
