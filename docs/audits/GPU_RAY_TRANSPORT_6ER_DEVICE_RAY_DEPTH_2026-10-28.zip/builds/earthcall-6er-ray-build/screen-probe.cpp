// Read-only frozen-volume capture and isolated completion-fenced cost fixture.
// Derived from northern_veil_fragment_demand_probe_2026_10_11.cpp; that original
// stays unchanged. Native correctness and cost are separate invocations.
// Cost mode performs no image readback or shader instrumentation. No save writes.
// Codex / GPT-6.1 Sol / 01a122d7 / 2026-10-15.
#include "ConstructedBeing/Singular/Object/Geometry/FieldNode.hpp"
#include "Singularity/Screen/AuthorableLight.hpp"
#include "Singularity/Screen/VolumeDensity.hpp"
#include "Singularity/Screen/VolumeZeroProof.hpp"
#include "Singularity/Screen/WebGPU/WebGpuRenderer.hpp"
#include "Singularity/Screen/WebGPU/SdfWgsl.hpp"
#include "Singularity/Screen/WebGPU/WgpuDevice.hpp"

#include <webgpu/wgpu.h>
#include <glm/glm.hpp>
#include <glm/ext/matrix_clip_space.hpp>
#include <glm/ext/matrix_transform.hpp>
#include "json.hpp"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <memory>
#include <vector>

#ifdef EC_FRAGMENT_CENSUS
extern "C" bool dumpFragmentCensus(WGPUDevice,WGPUInstance,WGPUQueue,const char*);
#else
static bool dumpFragmentCensus(WGPUDevice,WGPUInstance,WGPUQueue,const char*) { return false; }
#endif
namespace {
template<class Proof> auto hierarchyWords(const Proof& proof,int) -> decltype(proof.macroWords.size()) { return proof.macroWords.size(); }
template<class Proof> size_t hierarchyWords(const Proof&,long) { return 0; }
using Clock = std::chrono::steady_clock;
double ms(Clock::time_point a, Clock::time_point b) {
    return std::chrono::duration<double, std::milli>(b - a).count();
}
struct MapResult { bool done = false; bool ok = false; };
void mapped(WGPUMapAsyncStatus s, WGPUStringView, void* u, void*) {
    auto* r = static_cast<MapResult*>(u);
    r->ok = s == WGPUMapAsyncStatus_Success;
    r->done = true;
}
#define REQUIRE(c) do { if (!(c)) { std::printf("FAIL: %s\n", #c); return 1; } } while (0)
}


// Scratch Kernel-only device buffers/pipelines and capture counters. No authored
// state or cross-frame cache. Immutable capture window/mutation for each job.
static WGPUDevice rayDevice=nullptr;
static WGPUQueue rayQueue=nullptr;
static WGPUInstance rayInstance=nullptr;
static WGPUBuffer rayFrag=nullptr,rayCompute=nullptr;
static uint32_t rayWidth=0,rayHeight=0,rayStart=0,rayRows=0,rayDispatches=0;
static uint64_t rayBytes=0;
static std::string rayMode,rayScene,rayMutation,rayComputeCode;
static glm::mat4 rayInvViewProj(1);
bool ecRayEnabled(){return rayMutation!="control";}
WGPUBuffer ecRayBuffer(){return rayFrag;}
uint64_t ecRayBytes(){return rayBytes;}
static void ecRayInit(wgpu::Device& gpu,uint32_t w,uint32_t h){
    rayDevice=gpu.device;rayQueue=gpu.queue;rayInstance=gpu.instance;rayWidth=w;rayHeight=h;
    rayMode=std::getenv("EC_SCREEN_BRIDGE")?std::getenv("EC_SCREEN_BRIDGE"):"none:normal:0:190";
    char scene[40]={},mutation[40]={};
    if(std::sscanf(rayMode.c_str(),"%39[^:]:%39[^:]:%u:%u",scene,mutation,&rayStart,&rayRows)!=4)std::abort();
    rayScene=scene;rayMutation=mutation;
    if(!rayRows||rayStart+rayRows>h)std::abort();
    if(!ecRayEnabled())return;
    rayBytes=uint64_t(w)*rayRows*64;
    if(rayBytes>64ull*1024*1024)std::abort();
    WGPUBufferDescriptor d={};d.size=rayBytes;d.usage=WGPUBufferUsage_Storage|WGPUBufferUsage_CopyDst|WGPUBufferUsage_CopySrc;
    rayFrag=wgpuDeviceCreateBuffer(gpu.device,&d);rayCompute=wgpuDeviceCreateBuffer(gpu.device,&d);
    if(!rayFrag||!rayCompute)std::abort();
}
static void ecRayOpaque(WebGpuRenderer& renderer){
    if(rayScene=="none")return;
    float d=.97f;
    if(rayScene=="threshold-lo")d=.9999985f;
    if(rayScene=="threshold-hi")d=.9999995f;
    auto point=[&](float x,float y){const auto p=rayInvViewProj*glm::vec4(x,y,d,1);return glm::vec3(p)/p.w;};
    const auto a=point(-1,-1),b=point(0,-1),c=point(0,1),e=point(-1,1);
    renderer.drawSolid({a,b,c,a,c,e},glm::vec4(.1f,.2f,.3f,1),Blend::Opaque,true);
}
static std::string rayBlock(const std::string& s,const std::string& name){
    const auto p=s.find(name);if(p==std::string::npos||s.find(name,p+name.size())!=std::string::npos)std::abort();
    const auto a=s.find('{',p);int depth=1;size_t q=a+1;
    for(;q<s.size()&&depth;++q){if(s[q]=='{')++depth;if(s[q]=='}')--depth;}
    if(depth)std::abort();return s.substr(p,q-p)+"\n";
}
static std::string rayRecorder(const char* fn,const char* buffer){
    return "fn "+std::string(fn)+R"WGSL((position: vec4<f32>, ro: vec3<f32>, rd: vec3<f32>, t0: f32, t1: f32,
        depth: f32, bounds: vec2<f32>, status: u32) {
    let x=u32(position.x);let y=u32(position.y);
    if(y<RAY_START || y>=RAY_START+RAY_ROWS){return;}
    let at=((y-RAY_START)*u32(u.viewport.x)+x)*4u;
)WGSL"+std::string(buffer)+"[at]=bitcast<vec4<u32>>(vec4<f32>(ro,t0));\n"+
      std::string(buffer)+"[at+1u]=bitcast<vec4<u32>>(vec4<f32>(rd,t1));\n"+
      std::string(buffer)+"[at+2u]=vec4<u32>(1u,status,bitcast<u32>(depth),0u);\n"+
      std::string(buffer)+"[at+3u]=bitcast<vec4<u32>>(vec4<f32>(bounds,position.xy));\n}\n";
}
std::string ecRayShader(std::string s){
    const std::string start="fn fs(in: VolumeVSOut) -> @location(0) vec4<f32> {";
    const auto a=s.find(start);const auto b=s.find("    var transmittance = 1.0;",a);
    if(a==std::string::npos||b==std::string::npos)std::abort();
    const auto p=a+start.size();const std::string original=s.substr(p,b-p);
    const std::string discard="    if (t1 <= t0) { discard; }";
    auto recordPrefix=[&](std::string t,const char* fn,bool fragment){
        const auto first=t.find(discard),second=t.find(discard,first+discard.size());
        if(first==std::string::npos||second==std::string::npos||t.find(discard,second+discard.size())!=std::string::npos)std::abort();
        std::string tail=fragment?" discard; }":" return; }";
        t.replace(second,discard.size(),"    if(t1<=t0){"+std::string(fn)+"(in.position,ro,rd,t0,t1,sceneDepth,bounds,2u);"+tail);
        t.replace(first,discard.size(),"    if(t1<=t0){"+std::string(fn)+"(in.position,ro,rd,t0,t1,-1.0,bounds,1u);"+tail);
        t+="    "+std::string(fn)+"(in.position,ro,rd,t0,t1,sceneDepth,bounds,3u);\n";
        if(fragment&&rayMutation=="no-fragment")t=original;
        if(!fragment){
            size_t i=0;while((i=t.find("in.position",i))!=std::string::npos){t.replace(i,11,"position");i+=8;}
            if(rayMutation=="ignore-depth"){
                const std::string load="let sceneDepth = textureLoad(sceneDepthTex, px, 0);";
                const auto q=t.find(load);if(q==std::string::npos)std::abort();t.replace(q,load.size(),"let sceneDepth = 1.0;");
            }
        }
        return t;
    };
    const auto constants="const RAY_START:u32="+std::to_string(rayStart)+"u;\nconst RAY_ROWS:u32="+std::to_string(rayRows)+"u;\n";
    std::string cs=rayBlock(s,"struct VolumeGlobals {")+rayBlock(s,"struct VolumeInstanceData {")+
       "@group(0) @binding(0) var<uniform> u:VolumeGlobals;\n@group(0) @binding(2) var sceneDepthTex:texture_depth_2d;\n"
       "@group(1) @binding(0) var<storage,read> instances:array<VolumeInstanceData>;\n"
       "@group(0) @binding(4) var<storage,read_write> computeFacts:array<vec4<u32>>;\nvar<private> g_instIdx:u32;\n"+
       constants+rayBlock(s,"fn rayAabbWorld(")+rayBlock(s,"fn worldAtDepth(")+rayRecorder("ecComputeRecord","computeFacts")+
       "fn deviceSetup(position:vec4<f32>){"+recordPrefix(original,"ecComputeRecord",false)+"}\n";
    const std::string centre=rayMutation=="pixel-corner"?"0.0":"0.5";
    cs+="@compute @workgroup_size(64) fn cs(@builtin(global_invocation_id) id:vec3<u32>){\n"
        "let width=u32(u.viewport.x);if(id.x>=width*RAY_ROWS){return;}\n"
        "let x=id.x%width;let y=id.x/width+RAY_START;deviceSetup(vec4<f32>(f32(x)+"+centre+",f32(y)+"+centre+",0.0,1.0));}\n";
    if(!rayComputeCode.empty()&&rayComputeCode!=cs)std::abort();rayComputeCode=cs;
    s.replace(p,b-p,recordPrefix(original,"ecFragmentRecord",true));
    const auto fp=s.find("@fragment\n");if(fp==std::string::npos)std::abort();
    s.insert(fp,constants+"@group(0) @binding(3) var<storage,read_write> fragmentFacts:array<vec4<u32>>;\n"+rayRecorder("ecFragmentRecord","fragmentFacts"));
    if(const char* path=std::getenv("EC_SCREEN_SHADER_DIR")){
        std::ofstream(std::string(path)+"/fragment.wgsl")<<s;std::ofstream(std::string(path)+"/compute.wgsl")<<cs;
    }
    return s;
}
void ecRayDispatch(WGPUDevice device,WGPUCommandEncoder encoder,WGPUBuffer uniforms,uint64_t offset,uint64_t bytes,
                   WGPUTextureView depth,WGPUBindGroupLayout instanceLayout,WGPUBindGroup instances){
    if(rayComputeCode.empty())std::abort();
    std::vector<uint32_t> poison(rayBytes/4,0xcdcdcdcdu);
    wgpuQueueWriteBuffer(rayQueue,rayFrag,0,poison.data(),rayBytes);wgpuQueueWriteBuffer(rayQueue,rayCompute,0,poison.data(),rayBytes);
    if(rayMutation=="no-compute")return;
    WGPUShaderSourceWGSL ws={};ws.chain.sType=WGPUSType_ShaderSourceWGSL;ws.code=wgpu::Device::str(rayComputeCode.c_str());
    WGPUShaderModuleDescriptor sd={};sd.nextInChain=&ws.chain;auto shader=wgpuDeviceCreateShaderModule(device,&sd);
    WGPUBindGroupLayoutEntry e[3]={};e[0].binding=0;e[0].visibility=WGPUShaderStage_Compute;e[0].buffer.type=WGPUBufferBindingType_Uniform;
    e[1].binding=2;e[1].visibility=WGPUShaderStage_Compute;e[1].texture.sampleType=WGPUTextureSampleType_Depth;e[1].texture.viewDimension=WGPUTextureViewDimension_2D;
    e[2].binding=4;e[2].visibility=WGPUShaderStage_Compute;e[2].buffer.type=WGPUBufferBindingType_Storage;
    WGPUBindGroupLayoutDescriptor ld={};ld.entryCount=3;ld.entries=e;auto globals=wgpuDeviceCreateBindGroupLayout(device,&ld);
    WGPUBindGroupLayout layouts[2]={globals,instanceLayout};WGPUPipelineLayoutDescriptor pl={};pl.bindGroupLayoutCount=2;pl.bindGroupLayouts=layouts;
    auto layout=wgpuDeviceCreatePipelineLayout(device,&pl);WGPUComputePipelineDescriptor pd={};pd.layout=layout;pd.compute.module=shader;pd.compute.entryPoint=wgpu::Device::str("cs");
    auto pipeline=wgpuDeviceCreateComputePipeline(device,&pd);
    WGPUBindGroupEntry ge[3]={};ge[0].binding=0;ge[0].buffer=uniforms;ge[0].offset=offset;ge[0].size=bytes;
    ge[1].binding=2;ge[1].textureView=depth;ge[2].binding=4;ge[2].buffer=rayCompute;ge[2].size=rayBytes;
    WGPUBindGroupDescriptor gd={};gd.layout=globals;gd.entryCount=3;gd.entries=ge;auto group=wgpuDeviceCreateBindGroup(device,&gd);
    auto pass=wgpuCommandEncoderBeginComputePass(encoder,nullptr);wgpuComputePassEncoderSetPipeline(pass,pipeline);
    wgpuComputePassEncoderSetBindGroup(pass,0,group,0,nullptr);wgpuComputePassEncoderSetBindGroup(pass,1,instances,0,nullptr);
    wgpuComputePassEncoderDispatchWorkgroups(pass,(rayWidth*rayRows+63)/64,1,1);wgpuComputePassEncoderEnd(pass);wgpuComputePassEncoderRelease(pass);++rayDispatches;
    wgpuBindGroupRelease(group);wgpuComputePipelineRelease(pipeline);wgpuPipelineLayoutRelease(layout);wgpuBindGroupLayoutRelease(globals);wgpuShaderModuleRelease(shader);
}
static void ecRayDump(WGPUBuffer source,const std::string& path){
    WGPUBufferDescriptor d={};d.size=rayBytes;d.usage=WGPUBufferUsage_CopyDst|WGPUBufferUsage_MapRead;auto buffer=wgpuDeviceCreateBuffer(rayDevice,&d);
    auto e=wgpuDeviceCreateCommandEncoder(rayDevice,nullptr);wgpuCommandEncoderCopyBufferToBuffer(e,source,0,buffer,0,rayBytes);
    auto command=wgpuCommandEncoderFinish(e,nullptr);wgpuQueueSubmit(rayQueue,1,&command);wgpuCommandBufferRelease(command);wgpuCommandEncoderRelease(e);
    MapResult result;WGPUBufferMapCallbackInfo cb={};cb.mode=WGPUCallbackMode_AllowProcessEvents;cb.callback=mapped;cb.userdata1=&result;
    wgpuBufferMapAsync(buffer,WGPUMapMode_Read,0,rayBytes,cb);while(!result.done)wgpuInstanceProcessEvents(rayInstance);if(!result.ok)std::abort();
    const auto* p=static_cast<const char*>(wgpuBufferGetConstMappedRange(buffer,0,rayBytes));std::ofstream(path,std::ios::binary).write(p,rayBytes);
    wgpuBufferUnmap(buffer);wgpuBufferRelease(buffer);
}
static void ecRayFinish(const char* path){
    if(ecRayEnabled()){ecRayDump(rayFrag,std::string(path)+".fragment.bin");ecRayDump(rayCompute,std::string(path)+".compute.bin");}
    nlohmann::json j={{"mode",rayMode},{"scene",rayScene},{"mutation",rayMutation},{"enabled",ecRayEnabled()},
       {"width",rayWidth},{"height",rayHeight},{"row_start",rayStart},{"rows",rayRows},{"bytes_per_stage",rayBytes},{"dispatches",rayDispatches}};
    std::printf("BRIDGE_JSON %s\n",j.dump().c_str());if(rayFrag)wgpuBufferRelease(rayFrag);if(rayCompute)wgpuBufferRelease(rayCompute);
}

int main(int argc, char** argv) {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    if (argc < 3) { std::fprintf(stderr, "usage: probe <zone.ecform> 0123 [width] [height] [fixed-time] [output.rgba] 1\n"); return 2; }
    const char* mask = argv[2];
    const uint32_t width = argc > 3 ? std::atoi(argv[3]) : 640;
    const uint32_t height = argc > 4 ? std::atoi(argv[4]) : 360;
    const double fixedT = argc > 5 ? std::atof(argv[5]) : 0.0;
    const char* outPath = argc > 6 ? argv[6] : nullptr;
    const int frames = argc > 7 ? std::atoi(argv[7]) : 1;
    REQUIRE(width >= 64 && height >= 36 && frames >= 1);

    std::ifstream in(argv[1], std::ios::binary);
    REQUIRE(in);
    // One startup decode of the existing MsgPack migration envelope. No save
    // writes and no serialization/lowering in the sample or frame loops.
    const std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(in)), {});
    REQUIRE(!bytes.empty());
    const auto saved = bytes.front() == '{' ? nlohmann::json::parse(bytes) : nlohmann::json::parse(nlohmann::json::from_msgpack(bytes).at("MigrationRoot").get<std::string>());

    auto root = geom::FieldNode::fromJson(saved.at("spatialRoot"));
    REQUIRE(root);
    std::vector<std::shared_ptr<geom::FieldNode>> curtains;
    for (const auto& f : saved.at("spatialFields")) curtains.push_back(geom::FieldNode::fromJson(f));
    REQUIRE(!curtains.empty());
    std::vector<geom::FieldNode*> active;
    for (const char* c = mask; *c; ++c) {
        const int i = *c - '0';
        if (i >= 0 && i < static_cast<int>(curtains.size())) active.push_back(curtains[i].get());
    }

    Rendering::AuthorableLightState light;
    REQUIRE(Rendering::readAuthorableLight(*root, light));

    if (const char* dir = std::getenv("EC_VOLUME_CODEGEN_DIR")) {
        for (size_t i=0;i<active.size();++i) {
            auto* f=active[i];
            const auto p=sdfwgsl::compileVolume(f->volumeDensity.get(),f->volumeExtinction.get(),
                f->volumeScattering.get(),f->volumeChroma.get(),f->volumePhase.get(),f->volumeEmission.get());
            REQUIRE(p.ok);
            const auto stem=std::string(dir)+"/"+std::to_string(i);
            std::ofstream(stem+".wgsl") << p.wgsl;
            std::ofstream(stem+"-params.json") << nlohmann::json(p.params).dump(2);
        }
        return 0;
    }

    if (std::getenv("EC_PROOF_COST")) {
        const auto* metadataText=std::getenv("EC_PROOF_METADATA_FLOATS");
        if(!metadataText || std::atoi(metadataText)<0) {
            std::fprintf(stderr,"proof-cost mode requires explicit nonnegative EC_PROOF_METADATA_FLOATS\n");return 2;
        }
        const size_t metadata=std::atoi(metadataText);
        for (auto* f : active) {
            if (!f->volumeDensity || f->volumeDensity->pieces.empty()) continue;
            for (int repeat=0; repeat<3; ++repeat) {
                const auto start=Clock::now();
                const auto proof=Rendering::buildVolumeZeroProof(*f->volumeDensity,glm::abs(f->scale));
                const auto end=Clock::now();
                std::printf("PROOF id=%s repeat=%d ms=%.9f cells=%u proven=%u ranges=%u inside_bytes=%zu outside_bytes=%zu\n",
                    f->getIdentifier().c_str(),repeat,ms(start,end),proof.totalCells,proof.provenCells,proof.rangeEvaluations,
                    (proof.words.size()+hierarchyWords(proof,0)+metadata)*4,(proof.words.size()+hierarchyWords(proof,0)+metadata+4*proof.supportBands.size())*4);
            }
        }
        return 0;
    }

    wgpu::Device gpu;
    if (!gpu.init()) { std::puts("FAIL: no WebGPU device"); return 1; }
    ecRayInit(gpu,width,height);
    WebGpuRenderer renderer;
    if (!renderer.init(gpu)) { std::puts("FAIL: renderer init"); return 1; }
    setCurrentRenderer(&renderer);
    if (std::getenv("EC_FULL_LATTICE")) renderer.setVolumeOutputErrorBudget(1.0 / 255.0);

    WGPUTextureDescriptor td = {};
    td.usage = WGPUTextureUsage_RenderAttachment | WGPUTextureUsage_CopySrc;
    td.dimension = WGPUTextureDimension_2D;
    td.size = {width, height, 1};
    td.format = WGPUTextureFormat_RGBA8Unorm;
    td.mipLevelCount = 1;
    td.sampleCount = 1;
    WGPUTexture target = wgpuDeviceCreateTexture(gpu.device, &td);
    WGPUTextureView view = wgpuTextureCreateView(target, nullptr);
    const uint32_t stride = (width * 4 + 255) & ~255u;
    WGPUBufferDescriptor bd = {};
    bd.usage = WGPUBufferUsage_CopyDst | WGPUBufferUsage_MapRead;
    bd.size = static_cast<uint64_t>(stride) * height;
    WGPUBuffer readback = wgpuDeviceCreateBuffer(gpu.device, &bd);

    Rendering::RadianceSourceBinding source;
    source.producerId = root->getIdentifier();
    source.position = light.position;
    source.ambientRadiance = Rendering::lightAmbientRadiance(light);
    source.diffuseRadiance = Rendering::lightDiffuseRadiance(light);
    source.specularRadiance = Rendering::lightSpecularRadiance(light);
    source.coefficients = glm::vec4(light.intensity, light.ambient, light.diffuse, light.specular);
    source.enabled = light.enabled;
    source.temporalCoordinate = fixedT;
    source.temporalDelta = 1.0 / 60.0;
    // Mirror EngineRender's authored source projection. The pre-2026-10-21
    // fixture omitted these expressions and exercised compatibility lighting;
    // preserve that workload only as an explicitly labelled counterfactual.
    const char* sourceMode = std::getenv("EC_VOLUME_SOURCE_MODE");
    const bool compatibilitySource = sourceMode && std::strcmp(sourceMode, "compatibility") == 0;
    REQUIRE(!sourceMode || compatibilitySource || std::strcmp(sourceMode, "authored") == 0);
    if (!compatibilitySource) {
        root->verifyAuthoredMath();
        if (root->field && root->field->mode == OntoMath::ScalarField::EvaluationMode::AST &&
            !root->field->astDefinition.pieces.empty()) {
            source.radianceExpr = &root->field->astDefinition;
            source.radianceRevision = root->authoredMathRevision(geom::FieldNode::kMathFieldAst);
        }
        if (root->lightChroma && !root->lightChroma->pieces.empty()) {
            source.chromaExpr = root->lightChroma.get();
            source.chromaRevision = root->authoredMathRevision(geom::FieldNode::kMathLightChroma);
        }
        if (root->lightAngular && !root->lightAngular->pieces.empty()) {
            source.angularExpr = root->lightAngular.get();
            source.angularRevision = root->authoredMathRevision(geom::FieldNode::kMathLightAngular);
        }
    }
    std::printf("SOURCE mode=%s radiance=%d chroma=%d angular=%d clock=%.9f\n",
        compatibilitySource ? "compatibility-counterfactual" : "authored",
        source.radianceExpr != nullptr, source.chromaExpr != nullptr,
        source.angularExpr != nullptr, source.temporalCoordinate);
    renderer.setRadianceSources({source}, 1);
    renderer.setLight(source.position, source.ambientRadiance, source.diffuseRadiance, source.specularRadiance);
    renderer.setLightingEnabled(light.enabled);

    // Spawn dais, looking up and out at the curtains (y 48-78, z 68-140).
    glm::vec3 eye(0.0f, 2.0f, 0.0f);
    glm::vec3 look(0.0f, 60.0f, 90.0f);
    if (const char* cam = std::getenv("EC_CAM")) {   // "ex,ey,ez,lx,ly,lz"
        std::sscanf(cam, "%f,%f,%f,%f,%f,%f", &eye.x, &eye.y, &eye.z, &look.x, &look.y, &look.z);
    }
    rayInvViewProj=glm::inverse(glm::perspectiveZO(glm::radians(60.0f),float(width)/height,.1f,1000.f)*glm::lookAt(eye,look,glm::vec3(0,1,0)));
    renderer.setCamera(glm::lookAt(eye, look, glm::vec3(0, 1, 0)),
                       glm::perspectiveZO(glm::radians(60.0f), float(width) / height, 0.1f, 1000.0f), eye);

    auto syncImage = [&] {
        WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        WGPUTexelCopyTextureInfo src = {}; src.texture = target; src.aspect = WGPUTextureAspect_All;
        WGPUTexelCopyBufferInfo dst = {}; dst.buffer = readback;
        dst.layout.bytesPerRow = stride; dst.layout.rowsPerImage = height;
        WGPUExtent3D ext = {width, height, 1};
        wgpuCommandEncoderCopyTextureToBuffer(enc, &src, &dst, &ext);
        WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd); wgpuCommandEncoderRelease(enc);
        MapResult r; WGPUBufferMapCallbackInfo cb = {};
        cb.mode = WGPUCallbackMode_AllowProcessEvents; cb.callback = mapped; cb.userdata1 = &r;
        wgpuBufferMapAsync(readback, WGPUMapMode_Read, 0, bd.size, cb);
        while (!r.done) wgpuInstanceProcessEvents(gpu.instance);
        const auto* px = static_cast<const unsigned char*>(wgpuBufferGetConstMappedRange(readback, 0, bd.size));
        uint64_t lum = 0, lit = 0;
        for (uint32_t y = 0; y < height; ++y)
            for (uint32_t x = 0; x < width; ++x) {
                const size_t at = size_t(y) * stride + x * 4;
                const unsigned s = px[at] + px[at + 1] + px[at + 2];
                lum += s; lit += s > 6;
            }
        wgpuBufferUnmap(readback);
        return std::pair<uint64_t, uint64_t>{lum, lit};
    };

    double t = fixedT;
    auto frame = [&](double& projMs, double& submitMs) {
        const auto t0 = Clock::now();
        std::vector<Rendering::VolumeDensityBinding> media;
        std::string identity;
        for (auto* f : active) {
            Rendering::VolumeDensityBinding m;
            if (Rendering::readVolumeDensity(*f, t, 1.0 / 60.0, m)) {
                Rendering::appendVolumeSetIdentity(identity, m.producerId, m);
                media.push_back(m);
            }
        }
        renderer.setVolumeDensitySources(std::move(media), std::hash<std::string>{}(identity));
        const auto t1 = Clock::now();
        renderer.setModel(glm::mat4(1));
        renderer.beginFrameOffscreen(view, width, height, glm::vec4(0, 0, 0, 1));
        ecRayOpaque(renderer);
        renderer.composeVolumes();
        renderer.endFrame();
        const auto t2 = Clock::now();
        projMs += ms(t0, t1); submitMs += ms(t1, t2);
    };

    if (outPath && std::strcmp(outPath, "cost") == 0) {
        auto fence = [&] {
            struct Done { bool done=false, ok=false; } result;
            WGPUQueueWorkDoneCallbackInfo cb = {}; cb.mode = WGPUCallbackMode_AllowProcessEvents;
            cb.userdata1 = &result;
            cb.callback = [](WGPUQueueWorkDoneStatus s, WGPUStringView, void* p, void*) {
                auto* r=static_cast<Done*>(p);r->ok=s==WGPUQueueWorkDoneStatus_Success;r->done=true;
            };
            wgpuQueueOnSubmittedWorkDone(gpu.queue,cb);
            while(!result.done) wgpuInstanceProcessEvents(gpu.instance);
            return result.ok;
        };
        for(int i=0;i<4;++i) {
            double p=0,q=0;frame(p,q);
            if(i==0) {
                const auto cold=renderer.frameStats();
                std::printf("ADMISSION cpu_ms=%.9f compiles=%u lowerings=%u proof_builds=%u parameters=%zu proofs=%zu\n",
                    p+q,cold.volumeProgramCompiles,cold.volumeLowerings,cold.volumeZeroProofBuilds,
                    cold.volumeParameterBytesUploaded,cold.volumeProofBytesUploaded);
            }
        }
        REQUIRE(fence());
        const auto start=Clock::now();double prep=0,submit=0;
        for(int i=0;i<frames;++i) frame(prep,submit);
        REQUIRE(fence());
        const auto end=Clock::now();
        const auto stats=renderer.frameStats();
        std::printf("COST frames=%d total_ms=%.9f prep_ms=%.9f submit_ms=%.9f compiles=%u lowerings=%u parameters=%zu proofs=%zu\n", frames,ms(start,end)/frames,prep/frames,submit/frames,stats.volumeProgramCompiles,stats.volumeLowerings,stats.volumeParameterBytesUploaded,stats.volumeProofBytesUploaded);
        wgpuBufferRelease(readback);wgpuTextureViewRelease(view);wgpuTextureRelease(target);setCurrentRenderer(nullptr);return 0;
    }
    { double p = 0, q = 0; frame(p, q); }
    syncImage();
    for (int i = 0; i < frames; ++i) { double p = 0, q = 0; frame(p, q); }
    syncImage();
    { double p = 0, q = 0; frame(p, q); }
    // final readback, tightly packed, written raw
    {
        WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(gpu.device, nullptr);
        WGPUTexelCopyTextureInfo src = {}; src.texture = target; src.aspect = WGPUTextureAspect_All;
        WGPUTexelCopyBufferInfo dst = {}; dst.buffer = readback;
        dst.layout.bytesPerRow = stride; dst.layout.rowsPerImage = height;
        WGPUExtent3D ext = {width, height, 1};
        wgpuCommandEncoderCopyTextureToBuffer(enc, &src, &dst, &ext);
        WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuQueueSubmit(gpu.queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd); wgpuCommandEncoderRelease(enc);
        MapResult r; WGPUBufferMapCallbackInfo cb = {};
        cb.mode = WGPUCallbackMode_AllowProcessEvents; cb.callback = mapped; cb.userdata1 = &r;
        wgpuBufferMapAsync(readback, WGPUMapMode_Read, 0, bd.size, cb);
        while (!r.done) wgpuInstanceProcessEvents(gpu.instance);
        const auto* px = static_cast<const unsigned char*>(wgpuBufferGetConstMappedRange(readback, 0, bd.size));
        if (outPath) {
            FILE* f = std::fopen(outPath, "wbx");
            REQUIRE(f);
            for (uint32_t y = 0; y < height; ++y) std::fwrite(px + size_t(y) * stride, 1, width * 4, f);
            std::fclose(f);
        }
        wgpuBufferUnmap(readback);
    }
    if (const char* path=std::getenv("EC_CENSUS")) REQUIRE(dumpFragmentCensus(gpu.device,gpu.instance,gpu.queue,path));
    std::printf("IMAGE mask=%s %ux%u t=%.2f out=%s; NOT PERFORMANCE TIMING\n", mask, width, height, fixedT, outPath ? outPath : "-");
    wgpuBufferRelease(readback); wgpuTextureViewRelease(view); wgpuTextureRelease(target);
    setCurrentRenderer(nullptr);
    ecRayFinish(outPath);
    return 0;
}
