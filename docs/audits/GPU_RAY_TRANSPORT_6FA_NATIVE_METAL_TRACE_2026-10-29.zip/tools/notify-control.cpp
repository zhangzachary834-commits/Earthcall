#include <notify.h>
#include <poll.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <iostream>
#include <stdexcept>
#include <string>
int main(){try{
 auto need=[](bool ok,const char* s){if(!ok)throw std::runtime_error(s);};
 std::string name="org.earthcall.trace-notify-control."+std::to_string(getpid());
 int fd=-1,token=-1;need(notify_register_file_descriptor(name.c_str(),&fd,0,&token)==0,"register");
 pollfd ev{fd,POLLIN,0};need(poll(&ev,1,30)==0,"no event before actual notification");
 need(notify_post(name.c_str())==0,"post");need(poll(&ev,1,2000)==1&&(ev.revents&POLLIN),"actual event delivered");
 uint32_t raw=0;need(read(fd,&raw,sizeof(raw))==sizeof(raw),"complete event payload");
 need(ntohl(raw)==uint32_t(token)||raw==uint32_t(token),"matching delivered token");
 need(poll(&ev,1,30)==0,"no duplicate event without a new post");need(notify_cancel(token)==0,"cancel");
 std::cout<<"PASS no initial event; actual posted event; matching token; no duplicate event. token="<<token<<" raw="<<raw<<'\n';
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
